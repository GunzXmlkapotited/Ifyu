// ============================================================
//  🚀 GUNZ SERVER — Full Auto-Install PHP (All Platforms)
//  Support: Termux, Linux (Debian/Alpine/RedHat/Arch/SUSE),
//           macOS, Windows, GitHub Actions
//  🎵 ROOT → music.html (Landing Page)
// ============================================================

const express = require('express');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { spawn, execSync } = require('child_process');

// ============================================================
//  📦 AUTO-INSTALL NODE_MODULES
// ============================================================
if (!fs.existsSync(path.join(__dirname, 'node_modules'))) {
  console.log('📦 node_modules belum ada, installing dependencies...');
  try {
    execSync('npm install', { stdio: 'inherit', cwd: __dirname });
    console.log('✅ Dependencies installed');
  } catch (err) {
    console.log('❌ npm install gagal:', err.message);
    process.exit(1);
  }
}

// ============================================================
//  🐙 DETEKSI ENVIRONMENT
// ============================================================
function isGitHubActions() {
  return process.env.GITHUB_ACTIONS === 'true' || process.env.CI === 'true';
}

function isTermux() {
  return (
    os.platform() === 'android' ||
    (process.env.PREFIX && process.env.PREFIX.includes('com.termux')) ||
    fs.existsSync('/data/data/com.termux')
  );
}

function isRoot() {
  return typeof process.getuid === 'function' && process.getuid() === 0;
}

function commandExists(cmd) {
  try {
    const check = os.platform() === 'win32'
      ? `where ${cmd}`
      : `command -v ${cmd}`;
    execSync(check, { stdio: 'ignore' });
    return true;
  } catch {
    return false;
  }
}

function detectPlatform() {
  if (isTermux()) return 'termux';

  if (isGitHubActions()) {
    const runnerOS = (process.env.RUNNER_OS || '').toLowerCase();
    if (runnerOS === 'linux')   return 'linux';
    if (runnerOS === 'macos')   return 'macos';
    if (runnerOS === 'windows') return 'windows';
  }

  const platform = os.platform();
  if (platform === 'linux')  return 'linux';
  if (platform === 'darwin') return 'macos';
  if (platform === 'win32')  return 'windows';
  return 'unknown';
}

function buildCmd(cmd) {
  if (isGitHubActions()) return `sudo ${cmd}`;
  if (isTermux()) return cmd;
  if (isRoot()) return cmd;
  if (commandExists('sudo')) return `sudo ${cmd}`;
  return cmd;
}

function detectLinuxDistro() {
  try {
    const release = fs.readFileSync('/etc/os-release', 'utf-8');
    if (/ubuntu|debian|linuxmint|pop|kali/i.test(release))        return 'debian';
    if (/alpine/i.test(release))                                    return 'alpine';
    if (/centos|rhel|fedora|rocky|almalinux|oracle/i.test(release)) return 'redhat';
    if (/arch|manjaro|endeavour/i.test(release))                    return 'arch';
    if (/opensuse|suse|sles/i.test(release))                        return 'suse';
    if (/void/i.test(release))                                      return 'void';
  } catch {}
  return 'unknown';
}

// ============================================================
//  🐘 AUTO-INSTALL PHP — ALL PLATFORMS
// ============================================================
function autoInstallPHP() {
  if (commandExists('php-cgi')) {
    console.log('✅ PHP-CGI sudah terinstall');
    return true;
  }
  if (commandExists('php')) {
    console.log('✅ PHP sudah terinstall (pakai php CLI)');
    return true;
  }

  const platform = detectPlatform();
  const inGH = isGitHubActions();
  const inTermux = isTermux();

  console.log('╔══════════════════════════════════════════════════╗');
  console.log('║  🐘 PHP BELUM TERINSTALL — AUTO-INSTALL START   ║');
  console.log('╚══════════════════════════════════════════════════╝');
  console.log(`   Platform  : ${platform}`);
  console.log(`   GitHub CI : ${inGH ? 'yes' : 'no'}`);
  console.log(`   Termux    : ${inTermux ? 'yes' : 'no'}`);
  console.log(`   Root      : ${isRoot() ? 'yes' : 'no'}`);
  console.log(`   OS Info   : ${os.type()} ${os.release()} ${os.arch()}`);
  console.log('');

  try {
    // ==========================================================
    //  📱 TERMUX (Android)
    // ==========================================================
    if (platform === 'termux') {
      console.log('📱 Installing PHP via pkg (Termux)...');
      execSync('pkg update -y', { stdio: 'inherit' });
      execSync('pkg install -y php', { stdio: 'inherit' });
    }

    // ==========================================================
    //  🐧 LINUX
    // ==========================================================
    else if (platform === 'linux') {
      const distro = detectLinuxDistro();
      console.log(`🐧 Linux distro: ${distro}`);

      if (distro === 'debian') {
        execSync(buildCmd('apt-get update -y'), {
          stdio: 'inherit',
          env: { ...process.env, DEBIAN_FRONTEND: 'noninteractive' }
        });
        execSync(buildCmd(
          'apt-get install -y --no-install-recommends ' +
          'php-cgi php-cli php-curl php-mbstring php-xml php-json php-zip'
        ), {
          stdio: 'inherit',
          env: { ...process.env, DEBIAN_FRONTEND: 'noninteractive' }
        });

      } else if (distro === 'alpine') {
        execSync(
          'apk add --no-cache php82 php82-cgi php82-curl php82-mbstring php82-openssl php82-json php82-xml php82-phar',
          { stdio: 'inherit' }
        );
        try {
          execSync('ln -sf /usr/bin/php82 /usr/local/bin/php', { stdio: 'ignore' });
          execSync('ln -sf /usr/bin/php-cgi82 /usr/local/bin/php-cgi', { stdio: 'ignore' });
        } catch {}

      } else if (distro === 'redhat') {
        execSync(buildCmd('dnf install -y php-cli php-curl php-mbstring php-xml php-json php-zip'), { stdio: 'inherit' });

      } else if (distro === 'arch') {
        execSync(buildCmd('pacman -Sy --noconfirm php php-cgi'), { stdio: 'inherit' });

      } else if (distro === 'suse') {
        execSync(buildCmd('zypper --non-interactive install php8 php8-cgi php8-curl php8-mbstring php8-zip'), { stdio: 'inherit' });

      } else if (distro === 'void') {
        execSync(buildCmd('xbps-install -Sy php php-cgi'), { stdio: 'inherit' });

      } else {
        console.log('⚠️  Distro tidak dikenali. Coba fallback apt/apk/dnf...');
        if (commandExists('apt-get')) {
          execSync(buildCmd('apt-get update -y && apt-get install -y php-cgi php-cli php-curl php-mbstring'), { stdio: 'inherit' });
        } else if (commandExists('apk')) {
          execSync('apk add --no-cache php82 php82-cgi php82-curl php82-mbstring', { stdio: 'inherit' });
        } else if (commandExists('dnf')) {
          execSync(buildCmd('dnf install -y php-cli php-curl php-mbstring'), { stdio: 'inherit' });
        } else {
          console.log('❌ Tidak ada package manager yang dikenali.');
          return false;
        }
      }
    }

    // ==========================================================
    //  🍎 macOS
    // ==========================================================
    else if (platform === 'macos') {
      if (commandExists('brew')) {
        console.log('🍎 Installing PHP via Homebrew...');
        execSync('brew install php', { stdio: 'inherit' });
      } else {
        console.log('📦 Homebrew belum ada, install dulu...');
        try {
          execSync(
            '/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"',
            { stdio: 'inherit' }
          );
          const brewPaths = ['/opt/homebrew/bin/brew', '/usr/local/bin/brew'];
          for (const p of brewPaths) {
            if (fs.existsSync(p)) {
              process.env.PATH = `${path.dirname(p)}:${process.env.PATH}`;
              break;
            }
          }
          execSync('brew install php', { stdio: 'inherit' });
        } catch (err) {
          console.log('❌ Gagal install Homebrew:', err.message);
          return false;
        }
      }
    }

    // ==========================================================
    //  🪟 WINDOWS
    // ==========================================================
    else if (platform === 'windows') {
      if (commandExists('choco')) {
        console.log('🪟 Installing PHP via Chocolatey...');
        execSync('choco install php -y --no-progress', { stdio: 'inherit' });
        try {
          const machinePath = execSync(
            'powershell -NoProfile -Command "[System.Environment]::GetEnvironmentVariable(\'Path\',\'Machine\')"',
            { encoding: 'utf-8' }
          ).trim();
          process.env.PATH = `${machinePath};${process.env.PATH}`;
        } catch {}
      }
      else if (commandExists('scoop')) {
        console.log('🪟 Installing PHP via Scoop...');
        execSync('scoop install php', { stdio: 'inherit' });
      }
      else if (commandExists('winget')) {
        console.log('🪟 Installing PHP via Winget...');
        execSync('winget install --id PHP.PHP -e --accept-source-agreements --accept-package-agreements', { stdio: 'inherit' });
      } else {
        console.log('⚠️  Windows: tidak ada choco/scoop/winget.');
        console.log('💡 Install PHP manual: https://windows.php.net/download/');
        return false;
      }
    }

    else {
      console.log('❌ Platform tidak dikenali:', platform);
      return false;
    }

    // ==========================================================
    //  ✅ VERIFIKASI
    // ==========================================================
    if (commandExists('php-cgi') || commandExists('php')) {
      console.log('╔══════════════════════════════════════════════════╗');
      console.log('║  ✅ PHP BERHASIL TERINSTALL                     ║');
      console.log('╚══════════════════════════════════════════════════╝');
      try {
        execSync('php -v', { stdio: 'inherit' });
      } catch {}
      return true;
    }

    console.log('⚠️  Install selesai tapi PHP belum terdeteksi di PATH.');
    console.log('💡 Restart terminal / shell mungkin diperlukan.');
    return false;

  } catch (err) {
    console.log('❌ Auto-install PHP gagal:', err.message);
    console.log('');
    console.log('💡 INSTALL MANUAL:');
    console.log('   Termux   : pkg install php');
    console.log('   Ubuntu   : sudo apt install php-cgi php-cli php-curl php-mbstring');
    console.log('   Alpine   : apk add php82 php82-cgi php82-curl php82-mbstring');
    console.log('   Fedora   : sudo dnf install php-cli php-curl php-mbstring');
    console.log('   Arch     : sudo pacman -S php php-cgi');
    console.log('   macOS    : brew install php');
    console.log('   Windows  : choco install php');
    console.log('');
    console.log('💡 GitHub Actions: pakai shivammathur/setup-php@v2 untuk hasil paling reliable.');
    return false;
  }
}

autoInstallPHP();

// ============================================================
//  🚀 EXPRESS SETUP
// ============================================================
const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================
//  🌐 CORS — WAJIB PALING ATAS
// ============================================================
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
  res.header('Access-Control-Max-Age', '86400');

  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// ============================================================
//  KONFIGURASI
// ============================================================
const SECRET_KEY = 'GunzSecure2025!@#';
const TARGET_HOST = 'am.dapjisync.my.id';
const TARGET_API_KEY = 'FREE';

const PUBLIC_DIR   = path.join(__dirname, 'public');
const TOOLS_DIR    = path.join(__dirname, 'tools');
const ALLTOOLS_DIR = path.join(__dirname, 'alltools');
const API_DIR      = path.join(__dirname, 'api');

// ============================================================
//  🔒 TOKEN SEKALI PAKAI
// ============================================================
const validTokens = new Map();
const LINKS_TO_REWRITE = [
  'alltools.html', 'alltools', '/alltools',
  'tools-Am-Premium.html', 'tools-Am-Premium', '/tools-Am-Premium',
  'tools-tiktok', '/tools-tiktok', 'docs', '/docs'
];
const TOKEN_TTL = 10 * 60 * 1000;

function createToken() {
  const token = crypto.randomBytes(16).toString('hex');
  validTokens.set(token, { expires: Date.now() + TOKEN_TTL, used: false });
  return token;
}

function validateAndConsumeToken(token) {
  if (!token) return false;
  const data = validTokens.get(token);
  if (!data || data.used || Date.now() > data.expires) {
    validTokens.delete(token);
    return false;
  }
  validTokens.delete(token);
  return true;
}

setInterval(() => {
  const now = Date.now();
  for (const [token, data] of validTokens.entries()) {
    if (now > data.expires) validTokens.delete(token);
  }
}, 5 * 60 * 1000);

// ============================================================
//  🔧 HELPER
// ============================================================
function linkToRegex(link) {
  const cleanLink = link.replace(/^\//, '');
  const escaped = cleanLink.replace(/\./g, '\\.');
  return new RegExp(`href="(\\/?)${escaped}(\\?[^"]*)?"`, 'g');
}

function injectTokenToHtml(html, token) {
  let result = html;
  const seen = new Set();
  LINKS_TO_REWRITE.forEach(link => {
    const cleanLink = link.replace(/^\//, '');
    if (seen.has(cleanLink)) return;
    seen.add(cleanLink);
    result = result.replace(linkToRegex(cleanLink), (m, slash) => {
      return `href="${slash}${cleanLink}?access=${token}"`;
    });
  });
  return result;
}

function redirectIfNotLoggedIn(req, res, next) {
  if (!validateAndConsumeToken(req.query.access)) return res.redirect('/');
  next();
}

function injectTokenMiddleware(req, res, next) {
  const originalSendFile = res.sendFile.bind(res);
  res.sendFile = function (filePath, options, callback) {
    fs.readFile(filePath, 'utf-8', (err, html) => {
      if (err) return originalSendFile(filePath, options, callback);
      const hasProtectedLink = LINKS_TO_REWRITE.some(link => {
        const cleanLink = link.replace(/^\//, '');
        return new RegExp(`href="(\\/?)${cleanLink.replace(/\./g, '\\.')}(\\?[^"]*)?"`).test(html);
      });
      if (!hasProtectedLink) return originalSendFile(filePath, options, callback);
      const newToken = createToken();
      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.type('html').send(injectTokenToHtml(html, newToken));
    });
  };
  next();
}

app.use(injectTokenMiddleware);
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// ============================================================
//  🛡️ PROTEKSI FILE HTML DARI AKSES LANGSUNG
// ============================================================
const PROTECTED_HTML = [
  'alltools.html',
  'tools-Am-Premium.html',
  'tools-tiktok.html',
  'tiktok.html',
  'docs.html'
];

app.use((req, res, next) => {
  const fileName = path.basename(req.path).toLowerCase();
  if (PROTECTED_HTML.map(f => f.toLowerCase()).includes(fileName)) {
    return redirectIfNotLoggedIn(req, res, next);
  }
  next();
});

// ============================================================
//  📚 AUTO-DETECT API DOCS (PHP + JS)
// ============================================================
const CATEGORY_LABELS = {
  'ai': 'AI',
  'ai-image': 'AI Image',
  'downloader': 'Downloader',
  'game': 'Game',
  'informasi': 'Informasi',
  'maker': 'Maker',
  'random': 'Random',
  'search': 'Search',
  'tools': 'Tools',
  'uploader': 'Uploader',
  'videystream': 'Video Stream'
};

function scanApiFolder() {
  const result = [];
  if (!fs.existsSync(API_DIR)) return result;

  const categories = fs.readdirSync(API_DIR).filter(f => {
    try {
      return fs.statSync(path.join(API_DIR, f)).isDirectory();
    } catch { return false; }
  });

  categories.forEach(cat => {
    const catPath = path.join(API_DIR, cat);
    const files = fs.readdirSync(catPath).filter(f => /\.(php|js)$/i.test(f));

    files.forEach(file => {
      const name = file.replace(/\.(php|js)$/i, '');
      const fullPath = path.join(catPath, file);
      const ext = path.extname(file).toLowerCase();

      let params = [];
      let method = 'GET';
      let description = '';
      let outputType = 'json';

      try {
        const content = fs.readFileSync(fullPath, 'utf-8');

        const descMatch = content.match(/\/\/\s*Deskripsi\s*:\s*(.+)/i);
        if (descMatch) description = descMatch[1].trim();

        const hasPost  = /\$_POST\s*\[/.test(content);
        const hasFiles = /\$_FILES\s*\[/.test(content);
        const hasGet   = /\$_GET\s*\[/.test(content);
        if (hasFiles || hasPost) method = 'POST';
        else if (hasGet)         method = 'GET';

        if (/header\s*\(\s*['"]Content-Type:\s*image\//i.test(content)) outputType = 'image';
        else if (/header\s*\(\s*['"]Content-Type:\s*audio\//i.test(content)) outputType = 'audio';
        else if (/header\s*\(\s*['"]Content-Type:\s*text\/html/i.test(content)) outputType = 'html';
        else outputType = 'json';

        const getMatches  = [...content.matchAll(/\$_GET\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);
        const postMatches = [...content.matchAll(/\$_POST\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);
        const fileMatches = [...content.matchAll(/\$_FILES\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);

        const allParams = [...new Set([...getMatches, ...postMatches])];
        const blacklist = ['apikey', 'api_key', 'key', 'token', 'creator'];

        const paramOptions = {};
        const paramBlockRegex = /@param\s+(\w+)\s*\(([^)]+)\)/g;
        let pm;
        while ((pm = paramBlockRegex.exec(content)) !== null) {
          const pName = pm[1];
          const opts = pm[2].split('|').map(s => s.trim()).filter(Boolean);
          if (opts.length) paramOptions[pName] = opts;
        }

        params = allParams
          .filter(p => !blacklist.includes(p.toLowerCase()))
          .map(p => ({
            name: p,
            placeholder: `Masukkan ${p}...`,
            options: paramOptions[p] || null,
            type: 'text'
          }));

        fileMatches.forEach(fname => {
          if (!params.find(p => p.name === fname)) {
            params.push({
              name: fname,
              placeholder: `Upload ${fname}...`,
              options: null,
              type: 'file'
            });
          }
        });
      } catch (err) {}

      result.push({
        category: CATEGORY_LABELS[cat] || cat,
        categoryRaw: cat,
        name: name.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        method,
        path: `/api/${cat}/${name}`,
        params,
        description,
        outputType,
        ext
      });
    });
  });

  return result;
}

// ============================================================
//  📊 ROUTE DOCS
// ============================================================
app.get('/api/config', (req, res) => {
  res.json(scanApiFolder());
});

app.get('/api/stats', (req, res) => {
  const data = scanApiFolder();
  res.json({
    requests: Math.floor(Math.random() * 9000) + 1000,
    latency: '45ms',
    endpoints: data.length,
    categories: [...new Set(data.map(d => d.category))].length
  });
});

// ============================================================
//  🚀 DYNAMIC API ROUTER (JS + PHP)
// ============================================================
app.all('/api/:category/:name', async (req, res) => {
  const { category, name } = req.params;

  const jsPath  = path.join(API_DIR, category, `${name}.js`);
  const phpPath = path.join(API_DIR, category, `${name}.php`);

  if (fs.existsSync(jsPath)) {
    try {
      delete require.cache[require.resolve(jsPath)];
      let handler = require(jsPath);
      if (handler.default) handler = handler.default;
      if (typeof handler !== 'function') return res.status(500).json({ error: 'Handler is not a function' });
      return await handler(req, res);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  if (fs.existsSync(phpPath)) {
    const query = new URLSearchParams(req.query).toString();

    let phpBin = process.env.PHP_BIN;
    if (!phpBin) {
      if (commandExists('php-cgi')) phpBin = 'php-cgi';
      else if (commandExists('php')) phpBin = 'php';
      else phpBin = 'php-cgi';
    }

    const env = {
      ...process.env,
      REQUEST_METHOD: req.method,
      SCRIPT_FILENAME: phpPath,
      SCRIPT_NAME: `/api/${category}/${name}`,
      QUERY_STRING: query,
      CONTENT_TYPE: req.headers['content-type'] || '',
      CONTENT_LENGTH: req.headers['content-length'] || '',
      REMOTE_ADDR: req.ip || '127.0.0.1',
      SERVER_PROTOCOL: 'HTTP/1.1',
      GATEWAY_INTERFACE: 'CGI/1.1',
      REDIRECT_STATUS: '1'
    };

    const child = spawn(phpBin, [], { env });

    let bodyChunks = [];
    req.on('data', c => bodyChunks.push(c));
    req.on('end', () => {
      if (bodyChunks.length) child.stdin.write(Buffer.concat(bodyChunks));
      child.stdin.end();
    });

    let stdout = Buffer.alloc(0);
    let stderr = '';
    child.stdout.on('data', d => { stdout = Buffer.concat([stdout, d]); });
    child.stderr.on('data', d => { stderr += d.toString(); });

    child.on('close', (code) => {
      if (code !== 0 && !stdout.length) {
        return res.status(500).json({ error: 'PHP error', detail: stderr });
      }

      const sep = stdout.indexOf('\r\n\r\n') >= 0
        ? stdout.indexOf('\r\n\r\n')
        : stdout.indexOf('\n\n');

      let headers = '';
      let body = stdout;
      if (sep >= 0) {
        headers = stdout.slice(0, sep).toString('utf-8');
        body = stdout.slice(sep + (stdout.indexOf('\r\n\r\n') >= 0 ? 4 : 2));
      }

      headers.split(/\r?\n/).forEach(line => {
        const idx = line.indexOf(':');
        if (idx > 0) {
          const k = line.slice(0, idx).trim();
          let v = line.slice(idx + 1).trim();

          v = v.replace(/[\r\n\t\v\f\0]/g, ' ').trim();

          if (!k || !v) return;
          if (/^status$/i.test(k)) return;
          if (/^content-disposition$/i.test(k)) return;

          try {
            res.setHeader(k, v);
          } catch (e) {
            console.warn(`⚠️ Skip invalid header [${k}]: ${e.message}`);
          }
        }
      });

      if (!res.getHeader('Content-Type')) res.setHeader('Content-Type', 'application/json');
      res.status(200).send(body);
    });

    child.on('error', (err) => {
      res.status(500).json({
        error: 'PHP binary not found',
        detail: err.message,
        hint: 'Install PHP: pkg install php (Termux) / sudo apt install php-cgi (Linux)',
        phpBin
      });
    });
    return;
  }

  return res.status(404).json({
    error: 'Endpoint not found',
    path: `/api/${category}/${name}`,
    tried: [jsPath, phpPath]
  });
});

// ============================================================
//  🎯 ROUTES
// ============================================================

// 🎵 ROOT → music.html (landing page utama)
app.get('/', (req, res) => {
  const musicPath = path.join(PUBLIC_DIR, 'music.html');
  if (fs.existsSync(musicPath)) {
    return res.sendFile(musicPath);
  }
  // Fallback kalau music.html belum ada
  const indexPath = path.join(PUBLIC_DIR, 'index.html');
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  res.status(404).send('Landing page (music.html) tidak ditemukan.');
});

// 🏠 Portfolio asli (index.html lama) — akses via /home
app.get('/home', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// 📄 Halaman terproteksi (butuh token sekali pakai)
app.get('/docs', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'docs.html'));
});

app.get('/alltools', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(ALLTOOLS_DIR, 'alltools.html'));
});

app.get('/tools-Am-Premium', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'tools-Am-Premium.html'));
});

app.get('/tools-tiktok', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'tiktok.html'));
});

// ============================================================
//  🖼️ STATIC FILES
// ============================================================
app.use(express.static(PUBLIC_DIR, {
  index: false,
  setHeaders: (res, filePath) => {
    const base = path.basename(filePath).toLowerCase();
    if (base === 'index.html' || base === 'music.html') {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    }
  }
}));
app.use(express.static(TOOLS_DIR, { index: false }));
app.use(express.static(ALLTOOLS_DIR, { index: false }));

// ============================================================
//  🔄 PROXY API
// ============================================================
function proxyRequest(targetPath) {
  return (req, res) => {
    const body = JSON.stringify(req.body || {});
    const options = {
      hostname: TARGET_HOST,
      port: 443,
      path: targetPath,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': TARGET_API_KEY,
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': 'GunzProxy/1.0'
      }
    };

    const proxyReq = https.request(options, proxyRes => {
      let data = '';
      proxyRes.on('data', chunk => { data += chunk; });
      proxyRes.on('end', () => {
        res.writeHead(proxyRes.statusCode || 200, {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-API-Key'
        });
        res.end(data);
      });
    });

    proxyReq.on('error', err => {
      res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ error: 'Proxy error: ' + err.message }));
    });

    if (body) proxyReq.write(body);
    proxyReq.end();
  };
}

app.post('/api/send', proxyRequest('/api/send'));
app.post('/api/verif', proxyRequest('/api/verif'));
app.post('/api/bulk', proxyRequest('/api/bulk'));

// ============================================================
//  🚀 JALANKAN
// ============================================================
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║   🚀 Server Gunz (Express): http://localhost:${PORT}           ║
║   🎵 Root /        → music.html (Landing Page)                ║
║   🏠 /home         → index.html (Portfolio)                   ║
║   📁 public | tools | alltools | api                          ║
║   📚 Docs: http://localhost:${PORT}/docs                        ║
║   🔒 Token SEKALI PAKAI (halaman terproteksi)                 ║
║   🐘 PHP auto-install: Termux | Linux | macOS | Windows      ║
║   🐙 GitHub Actions: supported                                ║
║   🌐 CORS: ENABLED ✅                                         ║
╚══════════════════════════════════════════════════════════════╝
  `);
});