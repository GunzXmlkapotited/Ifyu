// ============================================================
//  🚀 GUNZ SERVER — Auto-Install PHP + Audiovault
// ============================================================

const express = require('express');
const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { spawn, execSync } = require('child_process');

// 📦 Auto-install node_modules
if (!fs.existsSync(path.join(__dirname, 'node_modules'))) {
  console.log('📦 Installing dependencies...');
  try {
    execSync('npm install', { stdio: 'inherit', cwd: __dirname });
  } catch (err) {
    console.log('❌ npm install gagal:', err.message);
    process.exit(1);
  }
}

// ============================================================
//  DETEKSI ENV
// ============================================================
function isGitHubActions() {
  return process.env.GITHUB_ACTIONS === 'true' || process.env.CI === 'true';
}
function isTermux() {
  return os.platform() === 'android' ||
    (process.env.PREFIX && process.env.PREFIX.includes('com.termux')) ||
    fs.existsSync('/data/data/com.termux');
}
function isRoot() {
  return typeof process.getuid === 'function' && process.getuid() === 0;
}
function commandExists(cmd) {
  try {
    execSync(os.platform() === 'win32' ? `where ${cmd}` : `command -v ${cmd}`, { stdio: 'ignore' });
    return true;
  } catch { return false; }
}
function detectPlatform() {
  if (isTermux()) return 'termux';
  if (isGitHubActions()) {
    const r = (process.env.RUNNER_OS || '').toLowerCase();
    if (r === 'linux') return 'linux';
    if (r === 'macos') return 'macos';
    if (r === 'windows') return 'windows';
  }
  const p = os.platform();
  if (p === 'linux') return 'linux';
  if (p === 'darwin') return 'macos';
  if (p === 'win32') return 'windows';
  return 'unknown';
}
function buildCmd(cmd) {
  if (isGitHubActions()) return `sudo ${cmd}`;
  if (isTermux() || isRoot()) return cmd;
  if (commandExists('sudo')) return `sudo ${cmd}`;
  return cmd;
}
function detectLinuxDistro() {
  try {
    const r = fs.readFileSync('/etc/os-release', 'utf-8');
    if (/ubuntu|debian|linuxmint|pop|kali/i.test(r)) return 'debian';
    if (/alpine/i.test(r)) return 'alpine';
    if (/centos|rhel|fedora|rocky|almalinux|oracle/i.test(r)) return 'redhat';
    if (/arch|manjaro|endeavour/i.test(r)) return 'arch';
    if (/opensuse|suse|sles/i.test(r)) return 'suse';
    if (/void/i.test(r)) return 'void';
  } catch {}
  return 'unknown';
}

// ============================================================
//  🐘 AUTO-INSTALL PHP
// ============================================================
function autoInstallPHP() {
  if (commandExists('php-cgi') || commandExists('php')) {
    console.log('✅ PHP sudah ada');
    return true;
  }

  const platform = detectPlatform();
  console.log(`🐘 Install PHP (${platform})...`);

  try {
    if (platform === 'termux') {
      execSync('pkg update -y && pkg install -y php', { stdio: 'inherit' });
    } else if (platform === 'linux') {
      const distro = detectLinuxDistro();
      if (distro === 'debian') {
        execSync(buildCmd('apt-get update -y && apt-get install -y --no-install-recommends php-cgi php-cli php-curl php-mbstring php-xml php-json php-zip'),
          { stdio: 'inherit', env: { ...process.env, DEBIAN_FRONTEND: 'noninteractive' } });
      } else if (distro === 'alpine') {
        execSync('apk add --no-cache php82 php82-cgi php82-curl php82-mbstring php82-openssl php82-json php82-xml php82-phar', { stdio: 'inherit' });
        try {
          execSync('ln -sf /usr/bin/php82 /usr/local/bin/php', { stdio: 'ignore' });
          execSync('ln -sf /usr/bin/php-cgi82 /usr/local/bin/php-cgi', { stdio: 'ignore' });
        } catch {}
      } else if (distro === 'redhat') {
        execSync(buildCmd('dnf install -y php-cli php-curl php-mbstring php-xml php-json php-zip'), { stdio: 'inherit' });
      } else if (distro === 'arch') {
        execSync(buildCmd('pacman -Sy --noconfirm php php-cgi'), { stdio: 'inherit' });
      } else if (distro === 'suse') {
        execSync(buildCmd('zypper --non-interactive install php8 php8-cgi php8-curl php8-mbstring php8-zip'), { stdio: 'inherit' });
      } else if (distro === 'void') {
        execSync(buildCmd('xbps-install -Sy php php-cgi'), { stdio: 'inherit' });
      } else if (commandExists('apt-get')) {
        execSync(buildCmd('apt-get update -y && apt-get install -y php-cgi php-cli php-curl php-mbstring'), { stdio: 'inherit' });
      } else if (commandExists('apk')) {
        execSync('apk add --no-cache php82 php82-cgi php82-curl php82-mbstring', { stdio: 'inherit' });
      } else if (commandExists('dnf')) {
        execSync(buildCmd('dnf install -y php-cli php-curl php-mbstring'), { stdio: 'inherit' });
      } else {
        console.log('❌ Package manager tidak dikenali');
        return false;
      }
    } else if (platform === 'macos') {
      if (!commandExists('brew')) {
        console.log('📦 Install Homebrew...');
        execSync('/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"', { stdio: 'inherit' });
        for (const p of ['/opt/homebrew/bin/brew', '/usr/local/bin/brew']) {
          if (fs.existsSync(p)) { process.env.PATH = `${path.dirname(p)}:${process.env.PATH}`; break; }
        }
      }
      execSync('brew install php', { stdio: 'inherit' });
    } else if (platform === 'windows') {
      if (commandExists('choco')) execSync('choco install php -y --no-progress', { stdio: 'inherit' });
      else if (commandExists('scoop')) execSync('scoop install php', { stdio: 'inherit' });
      else if (commandExists('winget')) execSync('winget install --id PHP.PHP -e --accept-source-agreements --accept-package-agreements', { stdio: 'inherit' });
      else { console.log('❌ Tidak ada choco/scoop/winget'); return false; }
    } else {
      console.log('❌ Platform tidak dikenali:', platform);
      return false;
    }

    if (commandExists('php-cgi') || commandExists('php')) {
      console.log('✅ PHP terinstall');
      return true;
    }
    console.log('⚠️  PHP belum terdeteksi, restart shell mungkin perlu');
    return false;
  } catch (err) {
    console.log('❌ Gagal install PHP:', err.message);
    return false;
  }
}
autoInstallPHP();

// ============================================================
//  🎵 AUTO-INSTALL AUDIOVAULT
// ============================================================
function autoInstallAudiovault() {
  const DIR = path.join(__dirname, 'audiovault');
  const REPO = 'https://github.com/Bl4nk44/Audiovault.git';

  if (process.env.SKIP_AUDIOVAULT === '1') {
    console.log('⏭️  Audiovault skip');
    return false;
  }
  if (!commandExists('docker')) {
    console.log('⏭️  Docker tidak ada, skip Audiovault');
    return false;
  }
  if (!commandExists('git')) {
    console.log('❌ git tidak ada, skip Audiovault');
    return false;
  }

  // Cek container kalau folder sudah ada
  if (fs.existsSync(DIR)) {
    try {
      const ps = execSync(`docker ps --filter "name=audiovault" --format "{{.Names}}"`, { encoding: 'utf-8', cwd: DIR }).trim();
      if (ps) { console.log('✅ Audiovault running'); return true; }
      execSync('docker compose up -d', { stdio: 'ignore', cwd: DIR });
      console.log('✅ Audiovault started');
      return true;
    } catch (err) {
      console.log('⚠️  Audiovault error:', err.message);
      return false;
    }
  }

  console.log('🎵 Install Audiovault...');
  try {
    execSync(`git clone ${REPO} "${DIR}"`, { stdio: 'ignore' });

    const envExample = path.join(DIR, '.env.example');
    const envFile = path.join(DIR, '.env');
    const pass = process.env.AUDIOVAULT_PASSWORD || crypto.randomBytes(8).toString('hex');
    if (fs.existsSync(envExample) && !fs.existsSync(envFile)) {
      let c = fs.readFileSync(envExample, 'utf-8');
      c = c.replace(/^ADMIN_PASSWORD=.*$/m, `ADMIN_PASSWORD=${pass}`);
      if (!/^ADMIN_PASSWORD=/m.test(c)) c += `\nADMIN_PASSWORD=${pass}\n`;
      fs.writeFileSync(envFile, c);
    } else if (!fs.existsSync(envFile)) {
      fs.writeFileSync(envFile, `ADMIN_USERNAME=admin\nADMIN_PASSWORD=${pass}\n`);
    }
    console.log(`🔑 Password Audiovault: ${pass}`);

    try { execSync('docker compose pull', { stdio: 'ignore', cwd: DIR }); } catch {}
    execSync('docker compose up -d --build', { stdio: 'inherit', cwd: DIR });
    console.log('✅ Audiovault terinstall');
    return true;
  } catch (err) {
    console.log('❌ Audiovault gagal:', err.message);
    return false;
  }
}
autoInstallAudiovault();

// ============================================================
//  🚀 EXPRESS
// ============================================================
const app = express();
const PORT = process.env.PORT || 3000;

// CORS
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-API-Key');
  res.header('Access-Control-Max-Age', '86400');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  next();
});

// Konfigurasi
const TARGET_HOST = 'am.dapjisync.my.id';
const TARGET_API_KEY = 'FREE';
const PUBLIC_DIR   = path.join(__dirname, 'public');
const TOOLS_DIR    = path.join(__dirname, 'tools');
const ALLTOOLS_DIR = path.join(__dirname, 'alltools');
const API_DIR      = path.join(__dirname, 'api');
const AUDIOVAULT_API = process.env.AUDIOVAULT_API || 'http://127.0.0.1:8000';

// ============================================================
//  🔒 TOKEN SEKALI PAKAI
// ============================================================
const validTokens = new Map();
const LINKS_TO_REWRITE = [
  'alltools.html', 'alltools', '/alltools',
  'tools-Am-Premium.html', 'tools-Am-Premium', '/tools-Am-Premium',
  'tools-tiktok', '/tools-tiktok', 'docs', '/docs'
];
const TOKEN_TTL = 10 * 60 * 1000;

function createToken() {
  const token = crypto.randomBytes(16).toString('hex');
  validTokens.set(token, { expires: Date.now() + TOKEN_TTL, used: false });
  return token;
}
function validateAndConsumeToken(token) {
  if (!token) return false;
  const d = validTokens.get(token);
  if (!d || d.used || Date.now() > d.expires) { validTokens.delete(token); return false; }
  validTokens.delete(token);
  return true;
}
setInterval(() => {
  const now = Date.now();
  for (const [t, d] of validTokens.entries()) if (now > d.expires) validTokens.delete(t);
}, 5 * 60 * 1000);

// ============================================================
//  🔧 HELPER
// ============================================================
function linkToRegex(link) {
  const clean = link.replace(/^\//, '');
  return new RegExp(`href="(\\/?)${clean.replace(/\./g, '\\.')}(\\?[^"]*)?"`, 'g');
}
function injectTokenToHtml(html, token) {
  let r = html;
  const seen = new Set();
  LINKS_TO_REWRITE.forEach(link => {
    const clean = link.replace(/^\//, '');
    if (seen.has(clean)) return;
    seen.add(clean);
    r = r.replace(linkToRegex(clean), (m, s) => `href="${s}${clean}?access=${token}"`);
  });
  return r;
}
function redirectIfNotLoggedIn(req, res, next) {
  if (!validateAndConsumeToken(req.query.access)) return res.redirect('/');
  next();
}
function injectTokenMiddleware(req, res, next) {
  const orig = res.sendFile.bind(res);
  res.sendFile = function (fp, opt, cb) {
    fs.readFile(fp, 'utf-8', (err, html) => {
      if (err) return orig(fp, opt, cb);
      const has = LINKS_TO_REWRITE.some(l => {
        const c = l.replace(/^\//, '');
        return new RegExp(`href="(\\/?)${c.replace(/\./g, '\\.')}(\\?[^"]*)?"`).test(html);
      });
      if (!has) return orig(fp, opt, cb);
      const t = createToken();
      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.type('html').send(injectTokenToHtml(html, t));
    });
  };
  next();
}
app.use(injectTokenMiddleware);
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Proteksi HTML
const PROTECTED_HTML = ['alltools.html', 'tools-Am-Premium.html', 'tools-tiktok.html', 'tiktok.html', 'docs.html'];
app.use((req, res, next) => {
  const f = path.basename(req.path).toLowerCase();
  if (PROTECTED_HTML.map(x => x.toLowerCase()).includes(f)) return redirectIfNotLoggedIn(req, res, next);
  next();
});

// ============================================================
//  📚 SCAN API FOLDER
// ============================================================
const CATEGORY_LABELS = {
  'ai': 'AI', 'ai-image': 'AI Image', 'downloader': 'Downloader', 'game': 'Game',
  'informasi': 'Informasi', 'maker': 'Maker', 'random': 'Random', 'search': 'Search',
  'tools': 'Tools', 'uploader': 'Uploader', 'videystream': 'Video Stream'
};

function scanApiFolder() {
  const result = [];
  if (!fs.existsSync(API_DIR)) return result;

  fs.readdirSync(API_DIR).filter(f => {
    try { return fs.statSync(path.join(API_DIR, f)).isDirectory(); } catch { return false; }
  }).forEach(cat => {
    const catPath = path.join(API_DIR, cat);
    fs.readdirSync(catPath).filter(f => /\.(php|js)$/i.test(f)).forEach(file => {
      const name = file.replace(/\.(php|js)$/i, '');
      const fullPath = path.join(catPath, file);
      let params = [], method = 'GET', description = '', outputType = 'json';

      try {
        const c = fs.readFileSync(fullPath, 'utf-8');
        const dm = c.match(/\/\/\s*Deskripsi\s*:\s*(.+)/i);
        if (dm) description = dm[1].trim();

        const hasPost = /\$_POST\s*\[/.test(c);
        const hasFiles = /\$_FILES\s*\[/.test(c);
        const hasGet = /\$_GET\s*\[/.test(c);
        if (hasFiles || hasPost) method = 'POST';
        else if (hasGet) method = 'GET';

        if (/header\s*\(\s*['"]Content-Type:\s*image\//i.test(c)) outputType = 'image';
        else if (/header\s*\(\s*['"]Content-Type:\s*audio\//i.test(c)) outputType = 'audio';
        else if (/header\s*\(\s*['"]Content-Type:\s*text\/html/i.test(c)) outputType = 'html';

        const getM = [...c.matchAll(/\$_GET\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);
        const postM = [...c.matchAll(/\$_POST\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);
        const fileM = [...c.matchAll(/\$_FILES\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);

        const blacklist = ['apikey', 'api_key', 'key', 'token', 'creator'];
        const paramOptions = {};
        let pm;
        const paramRx = /@param\s+(\w+)\s*\(([^)]+)\)/g;
        while ((pm = paramRx.exec(c)) !== null) {
          const opts = pm[2].split('|').map(s => s.trim()).filter(Boolean);
          if (opts.length) paramOptions[pm[1]] = opts;
        }

        params = [...new Set([...getM, ...postM])]
          .filter(p => !blacklist.includes(p.toLowerCase()))
          .map(p => ({ name: p, placeholder: `Masukkan ${p}...`, options: paramOptions[p] || null, type: 'text' }));

        fileM.forEach(fn => {
          if (!params.find(p => p.name === fn))
            params.push({ name: fn, placeholder: `Upload ${fn}...`, options: null, type: 'file' });
        });
      } catch {}

      result.push({
        category: CATEGORY_LABELS[cat] || cat,
        categoryRaw: cat,
        name: name.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        method, path: `/api/${cat}/${name}`, params, description, outputType,
        ext: path.extname(file).toLowerCase()
      });
    });
  });
  return result;
}

// ============================================================
//  📊 ROUTES DOCS
// ============================================================
app.get('/api/config', (req, res) => res.json(scanApiFolder()));
app.get('/api/stats', (req, res) => {
  const d = scanApiFolder();
  res.json({
    requests: Math.floor(Math.random() * 9000) + 1000,
    latency: '45ms',
    endpoints: d.length,
    categories: [...new Set(d.map(x => x.category))].length
  });
});

// ============================================================
//  🎵 PROXY → AUDIOVAULT
// ============================================================
function proxyToAudiovault(targetPath) {
  return (req, res) => {
    const q = new URLSearchParams(req.query).toString();
    const url = `${AUDIOVAULT_API}${targetPath}${q ? '?' + q : ''}`;
    const lib = url.startsWith('https') ? https : http;
    const proxyReq = lib.get(url, r => {
      res.writeHead(r.statusCode || 200, {
        'Content-Type': r.headers['content-type'] || 'application/json',
        'Access-Control-Allow-Origin': '*'
      });
      r.pipe(res);
    });
    proxyReq.on('error', err => {
      res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ error: 'Audiovault not reachable', detail: err.message }));
    });
    proxyReq.setTimeout(120000, () => proxyReq.destroy());
  };
}
app.get('/api/audiovault/download', proxyToAudiovault('/api/download'));
app.get('/api/audiovault/search',   proxyToAudiovault('/api/search'));
app.get('/api/audiovault/health',   proxyToAudiovault('/health'));

// ============================================================
//  🚀 DYNAMIC API ROUTER (JS + PHP)
// ============================================================
app.all('/api/:category/:name', async (req, res) => {
  const { category, name } = req.params;
  if (category === 'audiovault') return;

  const jsPath = path.join(API_DIR, category, `${name}.js`);
  const phpPath = path.join(API_DIR, category, `${name}.php`);

  if (fs.existsSync(jsPath)) {
    try {
      delete require.cache[require.resolve(jsPath)];
      let h = require(jsPath);
      if (h.default) h = h.default;
      if (typeof h !== 'function') return res.status(500).json({ error: 'Handler not function' });
      return await h(req, res);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  if (fs.existsSync(phpPath)) {
    const query = new URLSearchParams(req.query).toString();
    let phpBin = process.env.PHP_BIN;
    if (!phpBin) {
      if (commandExists('php-cgi')) phpBin = 'php-cgi';
      else if (commandExists('php')) phpBin = 'php';
      else phpBin = 'php-cgi';
    }

    const env = {
      ...process.env,
      REQUEST_METHOD: req.method,
      SCRIPT_FILENAME: phpPath,
      SCRIPT_NAME: `/api/${category}/${name}`,
      QUERY_STRING: query,
      CONTENT_TYPE: req.headers['content-type'] || '',
      CONTENT_LENGTH: req.headers['content-length'] || '',
      REMOTE_ADDR: req.ip || '127.0.0.1',
      SERVER_PROTOCOL: 'HTTP/1.1',
      GATEWAY_INTERFACE: 'CGI/1.1',
      REDIRECT_STATUS: '1'
    };

    const child = spawn(phpBin, [], { env });
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      if (chunks.length) child.stdin.write(Buffer.concat(chunks));
      child.stdin.end();
    });

    let stdout = Buffer.alloc(0), stderr = '';
    child.stdout.on('data', d => stdout = Buffer.concat([stdout, d]));
    child.stderr.on('data', d => stderr += d.toString());

    child.on('close', code => {
      if (code !== 0 && !stdout.length) return res.status(500).json({ error: 'PHP error', detail: stderr });
      const sep = stdout.indexOf('\r\n\r\n') >= 0 ? stdout.indexOf('\r\n\r\n') : stdout.indexOf('\n\n');
      let headers = '', body = stdout;
      if (sep >= 0) {
        headers = stdout.slice(0, sep).toString('utf-8');
        body = stdout.slice(sep + (stdout.indexOf('\r\n\r\n') >= 0 ? 4 : 2));
      }
      headers.split(/\r?\n/).forEach(line => {
        const i = line.indexOf(':');
        if (i > 0) {
          const k = line.slice(0, i).trim();
          const v = line.slice(i + 1).trim().replace(/[\r\n\t\v\f\0]/g, ' ').trim();
          if (!k || !v || /^status$/i.test(k) || /^content-disposition$/i.test(k)) return;
          try { res.setHeader(k, v); } catch {}
        }
      });
      if (!res.getHeader('Content-Type')) res.setHeader('Content-Type', 'application/json');
      res.status(200).send(body);
    });

    child.on('error', err => {
      res.status(500).json({
        error: 'PHP binary not found',
        detail: err.message,
        phpBin
      });
    });
    return;
  }

  return res.status(404).json({ error: 'Endpoint not found', path: `/api/${category}/${name}` });
});

// ============================================================
//  🎯 ROUTES
// ============================================================
app.get('/', (req, res) => {
  const music = path.join(PUBLIC_DIR, 'music.html');
  if (fs.existsSync(music)) return res.sendFile(music);
  const idx = path.join(PUBLIC_DIR, 'index.html');
  if (fs.existsSync(idx)) return res.sendFile(idx);
  res.status(404).send('Landing page tidak ditemukan');
});

app.get('/home', (req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));
app.get('/docs', redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(TOOLS_DIR, 'docs.html')));
app.get('/alltools', redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(ALLTOOLS_DIR, 'alltools.html')));
app.get('/tools-Am-Premium', redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(TOOLS_DIR, 'tools-Am-Premium.html')));
app.get('/tools-tiktok', redirectIfNotLoggedIn, (req, res) => res.sendFile(path.join(TOOLS_DIR, 'tiktok.html')));

// Static
app.use(express.static(PUBLIC_DIR, {
  index: false,
  setHeaders: (res, fp) => {
    const b = path.basename(fp).toLowerCase();
    if (b === 'index.html' || b === 'music.html') res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  }
}));
app.use(express.static(TOOLS_DIR, { index: false }));
app.use(express.static(ALLTOOLS_DIR, { index: false }));

// ============================================================
//  🔄 PROXY API LUAR
// ============================================================
function proxyRequest(targetPath) {
  return (req, res) => {
    const body = JSON.stringify(req.body || {});
    const opt = {
      hostname: TARGET_HOST,
      port: 443,
      path: targetPath,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': TARGET_API_KEY,
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': 'GunzProxy/1.0'
      }
    };
    const proxyReq = https.request(opt, proxyRes => {
      let data = '';
      proxyRes.on('data', c => data += c);
      proxyRes.on('end', () => {
        res.writeHead(proxyRes.statusCode || 200, {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*'
        });
        res.end(data);
      });
    });
    proxyReq.on('error', err => {
      res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ error: 'Proxy error: ' + err.message }));
    });
    if (body) proxyReq.write(body);
    proxyReq.end();
  };
}
app.post('/api/send', proxyRequest('/api/send'));
app.post('/api/verif', proxyRequest('/api/verif'));
app.post('/api/bulk', proxyRequest('/api/bulk'));

// ============================================================
//  🚀 JALANKAN
// ============================================================
app.listen(PORT, () => {
  console.log(`🚀 Gunz Server : http://localhost:${PORT}`);
  console.log(`🎵 Audiovault  : ${AUDIOVAULT_API}`);
});