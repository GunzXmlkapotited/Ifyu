<?php
error_reporting(0);
ini_set('display_errors', '0');
// Deskripsi: Spotify Play (preview langsung dari CDN Spotify, tanpa pihak ketiga)
// Contoh: {"q": "multo"}

set_time_limit(120);

// ========== CORS ==========
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: *');
header('Access-Control-Expose-Headers: Content-Length, Content-Range, Accept-Ranges');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$query = $_GET['q'] ?? '';

// ========== CREDIT ==========
$credit = ['creator' => 'Gunz'];

// ========== METADATA PARAMETER ==========
$parameters = [
    [
        'name' => 'q',
        'type' => 'text',
        'required' => true,
        'placeholder' => 'Masukkan judul lagu...',
        'description' => 'Kata kunci pencarian lagu'
    ]
];

// ========== VALIDASI QUERY ==========
if (empty($query)) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => 'Parameter q wajib diisi',
        'parameters' => $parameters
    ]), JSON_PRETTY_PRINT);
    exit;
}

define('SECRET', '376136387538459893883312310911992847112448894410210511297108');
define('VERSION', 61);
define('CLIENT_VERSION', '1.2.88.61.ge172202b');
define('UA', 'Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.34 Mobile Safari/537.36');

function generateUUID() {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function generateTOTP($tsms) {
    $counter = floor(($tsms / 1000) / 30);
    $buffer = pack('J', $counter);
    $hmac = hash_hmac('sha1', $buffer, SECRET, true);
    $offset = ord($hmac[strlen($hmac) - 1]) & 0xf;
    $code = (unpack('N', substr($hmac, $offset, 4))[1] & 0x7fffffff) % 1000000;
    return str_pad($code, 6, '0', STR_PAD_LEFT);
}

function curlSpotify($url, $method = 'GET', $body = null, $headers = []) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);

    $allHeaders = array_merge([
        'User-Agent: ' . UA,
        'Referer: https://open.spotify.com/',
        'Origin: https://open.spotify.com',
        'Accept: application/json'
    ], $headers);

    curl_setopt($ch, CURLOPT_HTTPHEADER, $allHeaders);

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        if (!in_array('Content-Type: application/json', $allHeaders)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge($allHeaders, ['Content-Type: application/json']));
        }
    }

    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function getToken() {
    $sts = time();
    $totp = generateTOTP(time() * 1000);
    $totpServer = generateTOTP($sts * 1000);

    $token = curlSpotify(
        "https://open.spotify.com/api/token?reason=init&productType=web-player&totp={$totp}&totpServer={$totpServer}&totpVer=" . VERSION
    );

    if (empty($token['accessToken'])) return null;

    $client = curlSpotify(
        'https://clienttoken.spotify.com/v1/clienttoken',
        'POST',
        [
            'client_data' => [
                'client_version' => CLIENT_VERSION,
                'client_id' => $token['clientId'],
                'js_sdk_data' => [
                    'device_brand' => 'unknown',
                    'device_model' => 'unknown',
                    'os' => 'linux',
                    'os_version' => '24.04',
                    'device_id' => generateUUID(),
                    'device_type' => 'computer'
                ]
            ]
        ]
    );

    return [
        'accessToken' => $token['accessToken'],
        'clientToken' => $client['granted_token']['token'] ?? ''
    ];
}

function searchSpotify($query, $token) {
    return curlSpotify(
        'https://api-partner.spotify.com/pathfinder/v2/query',
        'POST',
        [
            'variables' => [
                'searchTerm' => $query,
                'offset' => 0,
                'limit' => 10,
                'numberOfTopResults' => 5,
                'includeAudiobooks' => true,
                'includeArtistHasConcertsField' => false,
                'includePreReleases' => true,
                'includeAuthors' => false,
                'includeEpisodeContentRatingsV2' => false
            ],
            'operationName' => 'searchDesktop',
            'extensions' => [
                'persistedQuery' => [
                    'version' => 1,
                    'sha256Hash' => '21b3fe49546912ba782db5c47e9ef5a7dbd20329520ba0c7d0fcfadee671d24e'
                ]
            ]
        ],
        [
            'Accept-Language: en',
            'App-Platform: WebPlayer',
            'Authorization: Bearer ' . $token['accessToken'],
            'Client-Token: ' . $token['clientToken'],
            'Spotify-App-Version: ' . CLIENT_VERSION
        ]
    );
}

function getLink($uri) {
    if (!$uri) return ['uri' => null, 'id' => null, 'url' => null];
    $p = explode(':', $uri);
    return [
        'uri' => $uri,
        'id' => $p[2] ?? null,
        'url' => $p[2] ? "https://open.spotify.com/{$p[1]}/{$p[2]}" : null
    ];
}

function getImg($obj) {
    return array_map(function($s) {
        return [
            'url' => $s['url'] ?? '',
            'width' => $s['width'] ?? $s['maxWidth'] ?? null,
            'height' => $s['height'] ?? $s['maxHeight'] ?? null
        ];
    }, $obj['sources'] ?? []);
}

// 🔥 Ambil preview dari data track hasil search (tanpa request tambahan)
function extractPreview($trackData) {
    if (empty($trackData) || !is_array($trackData)) return null;

    // Coba berbagai lokasi field preview
    if (!empty($trackData['audioPreview']['url'])) return $trackData['audioPreview']['url'];
    if (!empty($trackData['preview']['url']))     return $trackData['preview']['url'];
    if (!empty($trackData['previewUrl']))         return $trackData['previewUrl'];

    // Coba dari audio items
    if (!empty($trackData['audio']['items']) && is_array($trackData['audio']['items'])) {
        foreach ($trackData['audio']['items'] as $it) {
            if (!empty($it['url'])) return $it['url'];
        }
    }

    // Coba dari previews array
    if (!empty($trackData['previews']['audioPreviews']['items'])) {
        foreach ($trackData['previews']['audioPreviews']['items'] as $it) {
            if (!empty($it['url'])) return $it['url'];
        }
    }

    // Coba dari audioPreview langsung (string)
    if (!empty($trackData['audioPreview']) && is_string($trackData['audioPreview'])) {
        return $trackData['audioPreview'];
    }

    return null;
}

// Fallback: endpoint getTrack (kalau search gak ngehasilin preview)
function getSpotifyPreview($trackId, $token) {
    if (!$trackId) return null;

    $res = curlSpotify(
        'https://api-partner.spotify.com/pathfinder/v2/query',
        'POST',
        [
            'variables' => ['uri' => "spotify:track:{$trackId}"],
            'operationName' => 'getTrack',
            'extensions' => [
                'persistedQuery' => [
                    'version' => 1,
                    'sha256Hash' => '612585ae06ba435ad26369870deaae23b5c8800a256cd8a57e0d2d6a78c5f5f4'
                ]
            ]
        ],
        [
            'Accept-Language: en',
            'App-Platform: WebPlayer',
            'Authorization: Bearer ' . $token['accessToken'],
            'Client-Token: ' . $token['clientToken'],
            'Spotify-App-Version: ' . CLIENT_VERSION
        ]
    );

    $trackData = $res['data']['trackUnion'] ?? $res['data']['track'] ?? null;
    if (!$trackData) return null;

    return extractPreview($trackData);
}

// 🔥 Stream file dengan support Range + Content-Length
function streamFile($url, $filename) {
    // 1. HEAD request dulu — cek ukuran & mime
    $head = curl_init($url);
    curl_setopt_array($head, [
        CURLOPT_NOBODY => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_USERAGENT => UA,
        CURLOPT_TIMEOUT => 15
    ]);
    curl_exec($head);
    $size = curl_getinfo($head, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
    $mime = curl_getinfo($head, CURLINFO_CONTENT_TYPE) ?: 'audio/mpeg';
    curl_close($head);

    // 2. Handle Range request (biar bisa seek)
    $range = $_SERVER['HTTP_RANGE'] ?? '';
    $start = 0;
    $end   = $size > 0 ? $size - 1 : '';

    if ($range && preg_match('/bytes=(\d+)-(\d*)/', $range, $m)) {
        $start = intval($m[1]);
        $end   = $m[2] !== '' ? intval($m[2]) : ($size > 0 ? $size - 1 : '');
        http_response_code(206);
        if ($size > 0) {
            header("Content-Range: bytes {$start}-{$end}/{$size}");
        }
    }

    // 3. Kirim header
    header('Content-Type: ' . $mime);
    header('Content-Disposition: inline; filename="' . $filename . '"');
    header('Accept-Ranges: bytes');
    if ($size > 0) {
        $len = ($end === '' ? $size - 1 : $end) - $start + 1;
        header('Content-Length: ' . $len);
    }
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');

    // 4. Stream body
    $ch = curl_init($url);
    $headers = ['User-Agent: ' . UA];
    if ($range) $headers[] = "Range: bytes={$start}-{$end}";

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 120,
        CURLOPT_HEADER => false,
        CURLOPT_HTTPHEADER => $headers
    ]);

    // Matikan output buffering biar streaming realtime
    while (ob_get_level()) ob_end_clean();

    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($ch, $data) {
        echo $data;
        return strlen($data);
    });

    curl_exec($ch);
    curl_close($ch);
}

try {
    $token = getToken();
    if (!$token) throw new Exception('Gagal mendapatkan token Spotify');

    $searchResult = searchSpotify($query, $token);
    $searchData = $searchResult['data']['searchV2'] ?? [];

    $trackItems = $searchData['tracksV2']['items'] ?? [];
    if (empty($trackItems)) {
        $topItems = $searchData['topResultsV2']['itemsV2'] ?? [];
        foreach ($topItems as $item) {
            if (($item['item']['__typename'] ?? '') === 'TrackResponseWrapper') {
                $trackItems[] = $item;
            }
        }
    }

    if (empty($trackItems)) throw new Exception('Lagu tidak ditemukan');

    // Parse tracks
    $tracks = [];
    foreach ($trackItems as $item) {
        $t = $item['item']['data'] ?? $item['data'] ?? $item;

        // 🔥 Simpan raw data biar bisa extract preview
        $rawData = $t;

        $link = getLink($t['uri'] ?? '');
        $tracks[] = [
            'id' => $link['id'],
            'title' => $t['name'] ?? '',
            'url' => $link['url'],
            'preview_url' => extractPreview($rawData),
            'duration_ms' => $t['duration']['totalMilliseconds'] ?? 0,
            'explicit' => ($t['contentRating']['label'] ?? '') === 'EXPLICIT',
            'artists' => array_map(function($a) {
                $link = getLink($a['uri'] ?? '');
                return [
                    'name' => $a['profile']['name'] ?? '',
                    'url' => $link['url']
                ];
            }, $t['artists']['items'] ?? []),
            'album' => [
                'name' => $t['albumOfTrack']['name'] ?? '',
                'url' => getLink($t['albumOfTrack']['uri'] ?? '')['url'],
                'images' => getImg($t['albumOfTrack']['coverArt'] ?? [])
            ]
        ];
    }

    $topTrack = $tracks[0] ?? null;
    if (!$topTrack || empty($topTrack['id'])) throw new Exception('Track teratas tidak valid');

    // 🔥 Prioritas 1: dari search response
    $previewUrl = $topTrack['preview_url'] ?? null;

    // 🔥 Prioritas 2: fallback ke endpoint getTrack
    if (!$previewUrl) {
        $previewUrl = getSpotifyPreview($topTrack['id'], $token);
    }

    if (!$previewUrl) {
        throw new Exception('Preview tidak tersedia untuk track ini (region-locked atau tidak punya preview). Coba lagu lain.');
    }

    // Stream
    $artistName = $topTrack['artists'][0]['name'] ?? '';
    $filename = trim(($artistName ? $artistName . ' - ' : '') . $topTrack['title']) . '.mp3';
    $filename = preg_replace('/[^\w\s\-\.\(\)&,]/u', '', $filename);
    streamFile($previewUrl, $filename);
    exit;

} catch (Exception $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => $e->getMessage(),
        'parameters' => $parameters
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
?>