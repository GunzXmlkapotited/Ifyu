<?php
error_reporting(0);
ini_set('display_errors', '0');
// Deskripsi: Spotify Play (top result) - Tunggu MP3 selesai download, baru tampilkan
// Contoh: {"q": "multo"}

set_time_limit(600); // perbesar, karena nunggu download MusicFab

// ========== CORS ==========
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: *');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$query = $_GET['q'] ?? '';

// ========== CREDIT ==========
$credit = ['creator' => 'Gunz'];

// ========== METADATA PARAMETER ==========
$parameters = [
    [
        'name' => 'q',
        'type' => 'text',
        'required' => true,
        'placeholder' => 'Masukkan judul lagu...',
        'description' => 'Kata kunci pencarian lagu'
    ]
];

// ========== VALIDASI ==========
if (empty($query)) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => 'Parameter q wajib diisi',
        'parameters' => $parameters
    ]), JSON_PRETTY_PRINT);
    exit;
}

// ========== KONFIG ==========
define('CACHE_DIR', __DIR__ . '/cache_mp3');
define('CACHE_TTL', 86400); // 1 hari

define('SECRET', '376136387538459893883312310911992847112448894410210511297108');
define('VERSION', 61);
define('CLIENT_VERSION', '1.2.88.61.ge172202b');
define('UA', 'Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.34 Mobile Safari/537.36');
define('UA_DL', 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36');

// ========== SPOTIFY HELPERS ==========
function generateUUID() {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function generateTOTP($tsms) {
    $counter = floor(($tsms / 1000) / 30);
    $buffer = pack('J', $counter);
    $hmac = hash_hmac('sha1', $buffer, SECRET, true);
    $offset = ord($hmac[strlen($hmac) - 1]) & 0xf;
    $code = (unpack('N', substr($hmac, $offset, 4))[1] & 0x7fffffff) % 1000000;
    return str_pad($code, 6, '0', STR_PAD_LEFT);
}

function curlSpotify($url, $method = 'GET', $body = null, $headers = []) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);

    $allHeaders = array_merge([
        'User-Agent: ' . UA,
        'Referer: https://open.spotify.com/',
        'Origin: https://open.spotify.com',
        'Accept: application/json'
    ], $headers);

    curl_setopt($ch, CURLOPT_HTTPHEADER, $allHeaders);

    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
        if (!in_array('Content-Type: application/json', $allHeaders)) {
            curl_setopt($ch, CURLOPT_HTTPHEADER, array_merge($allHeaders, ['Content-Type: application/json']));
        }
    }

    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

function getToken() {
    $sts = time();
    $totp = generateTOTP(time() * 1000);
    $totpServer = generateTOTP($sts * 1000);

    $token = curlSpotify(
        "https://open.spotify.com/api/token?reason=init&productType=web-player&totp={$totp}&totpServer={$totpServer}&totpVer=" . VERSION
    );

    if (empty($token['accessToken'])) return null;

    $client = curlSpotify(
        'https://clienttoken.spotify.com/v1/clienttoken',
        'POST',
        [
            'client_data' => [
                'client_version' => CLIENT_VERSION,
                'client_id' => $token['clientId'],
                'js_sdk_data' => [
                    'device_brand' => 'unknown',
                    'device_model' => 'unknown',
                    'os' => 'linux',
                    'os_version' => '24.04',
                    'device_id' => generateUUID(),
                    'device_type' => 'computer'
                ]
            ]
        ]
    );

    return [
        'accessToken' => $token['accessToken'],
        'clientToken' => $client['granted_token']['token'] ?? ''
    ];
}

function searchSpotify($query, $token) {
    return curlSpotify(
        'https://api-partner.spotify.com/pathfinder/v2/query',
        'POST',
        [
            'variables' => [
                'searchTerm' => $query,
                'offset' => 0,
                'limit' => 10,
                'numberOfTopResults' => 5,
                'includeAudiobooks' => true,
                'includeArtistHasConcertsField' => false,
                'includePreReleases' => true,
                'includeAuthors' => false,
                'includeEpisodeContentRatingsV2' => false
            ],
            'operationName' => 'searchDesktop',
            'extensions' => [
                'persistedQuery' => [
                    'version' => 1,
                    'sha256Hash' => '21b3fe49546912ba782db5c47e9ef5a7dbd20329520ba0c7d0fcfadee671d24e'
                ]
            ]
        ],
        [
            'Accept-Language: en',
            'App-Platform: WebPlayer',
            'Authorization: Bearer ' . $token['accessToken'],
            'Client-Token: ' . $token['clientToken'],
            'Spotify-App-Version: ' . CLIENT_VERSION
        ]
    );
}

function getLink($uri) {
    if (!$uri) return ['uri' => null, 'id' => null, 'url' => null];
    $p = explode(':', $uri);
    return [
        'uri' => $uri,
        'id' => $p[2] ?? null,
        'url' => $p[2] ? "https://open.spotify.com/{$p[1]}/{$p[2]}" : null
    ];
}

function getImg($obj) {
    return array_map(function($s) {
        return [
            'url' => $s['url'] ?? '',
            'width' => $s['width'] ?? $s['maxWidth'] ?? null,
            'height' => $s['height'] ?? $s['maxHeight'] ?? null
        ];
    }, $obj['sources'] ?? []);
}

// ========== MUSICFAB ==========
function musicfabGetDownload($spotifyUrl) {
    $ch = curl_init('https://musicfab.io/api/spotify');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['url' => $spotifyUrl]),
        CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_HTTPHEADER => [
            'User-Agent: ' . UA_DL,
            'Accept: */*',
            'Content-Type: application/json',
            'Origin: https://musicfab.io',
            'Referer: https://musicfab.io/',
            'Accept-Language: id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
        ]
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    $result = json_decode($res, true);
    $metadata = $result['data']['metadata'] ?? null;

    if (!$metadata || empty($metadata['download'])) {
        return null;
    }

    return [
        'download_url' => $metadata['download'],
        'name' => $metadata['name'] ?? 'track',
        'artist' => $metadata['artist'] ?? ''
    ];
}

// ========== DOWNLOAD KE CACHE (TUNGGU SAMPAI SELESAI) ==========
function downloadToCache($url, $cacheFile) {
    $tmp = $cacheFile . '.part';
    $fp = fopen($tmp, 'w+b');
    if (!$fp) return false;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_FILE           => $fp,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT        => 600,
        CURLOPT_CONNECTTIMEOUT => 30,
        CURLOPT_USERAGENT      => UA_DL,
        CURLOPT_FAILONERROR    => true,
    ]);
    $ok = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    fclose($fp);

    if (!$ok || $code < 200 || $code >= 300 || filesize($tmp) < 1024) {
        @unlink($tmp);
        return false;
    }

    // Atomic rename supaya file cache tidak korup kalau request barengan
    if (!@rename($tmp, $cacheFile)) {
        @unlink($tmp);
        return false;
    }
    return true;
}

// ========== STREAM FILE LOKAL (SUPPORT RANGE) ==========
function streamLocalFile($path, $filename) {
    $size  = filesize($path);
    $start = 0;
    $end   = $size - 1;
    $isRange = false;

    if (isset($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d+)-(\d*)/', $_SERVER['HTTP_RANGE'], $m)) {
        $start = (int)$m[1];
        if ($m[2] !== '') $end = (int)$m[2];
        if ($end >= $size) $end = $size - 1;
        $isRange = true;
    }

    http_response_code($isRange ? 206 : 200);
    header('Content-Type: audio/mpeg');
    header('Content-Disposition: inline; filename="' . $filename . '"');
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . ($end - $start + 1));
    if ($isRange) {
        header("Content-Range: bytes {$start}-{$end}/{$size}");
    }
    header('Cache-Control: public, max-age=3600');

    while (ob_get_level()) ob_end_clean();

    $fp = fopen($path, 'rb');
    if (!$fp) return;
    fseek($fp, $start);
    $remaining = $end - $start + 1;
    $chunkSize = 8192;

    while ($remaining > 0 && !feof($fp) && connection_status() === CONNECTION_NORMAL) {
        $read = ($remaining > $chunkSize) ? $chunkSize : $remaining;
        echo fread($fp, $read);
        flush();
        $remaining -= $read;
    }
    fclose($fp);
}

// ========== MAIN ==========
try {
    // Pastikan folder cache ada
    if (!is_dir(CACHE_DIR)) @mkdir(CACHE_DIR, 0755, true);

    // ---- 1. Search Spotify ----
    $token = getToken();
    if (!$token) throw new Exception('Gagal mendapatkan token');

    $searchResult = searchSpotify($query, $token);
    $searchData = $searchResult['data']['searchV2'] ?? [];

    $trackItems = $searchData['tracksV2']['items'] ?? [];
    if (empty($trackItems)) {
        $topItems = $searchData['topResultsV2']['itemsV2'] ?? [];
        foreach ($topItems as $item) {
            if (($item['item']['__typename'] ?? '') === 'TrackResponseWrapper') {
                $trackItems[] = $item;
            }
        }
    }

    if (empty($trackItems)) throw new Exception('Lagu tidak ditemukan');

    $t = $trackItems[0]['item']['data'] ?? $trackItems[0]['data'] ?? $trackItems[0];
    $link = getLink($t['uri'] ?? '');
    $topTrack = [
        'id'    => $link['id'],
        'title' => $t['name'] ?? '',
        'url'   => $link['url'],
    ];

    if (empty($topTrack['url'])) throw new Exception('Track teratas tidak valid');

    // ---- 2. Cek cache ----
    $cacheKey  = md5($topTrack['url']);
    $cacheFile = CACHE_DIR . '/' . $cacheKey . '.mp3';
    $metaFile  = CACHE_DIR . '/' . $cacheKey . '.json';

    $needDownload = true;
    if (file_exists($cacheFile) && filesize($cacheFile) > 1024) {
        if (file_exists($metaFile) && (time() - filemtime($cacheFile)) < CACHE_TTL) {
            $needDownload = false;
        }
    }

    // ---- 3. Kalau belum ada / expired → download full dulu ----
    if ($needDownload) {
        @unlink($cacheFile);
        @unlink($metaFile);

        $dl = musicfabGetDownload($topTrack['url']);
        if (!$dl || empty($dl['download_url'])) {
            throw new Exception('Gagal mendapatkan link download');
        }

        // Tunggu sampai file benar-benar selesai di-download
        if (!downloadToCache($dl['download_url'], $cacheFile)) {
            throw new Exception('Gagal download file MP3');
        }

        // Simpan metadata
        file_put_contents($metaFile, json_encode([
            'name'   => $dl['name'],
            'artist' => $dl['artist'],
            'title'  => $topTrack['title'],
            'time'   => time(),
        ]));

    } else {
        // Ambil metadata dari cache
        $meta = json_decode(@file_get_contents($metaFile), true) ?: [];
        $dl = [
            'name'   => $meta['name']   ?? $topTrack['title'],
            'artist' => $meta['artist'] ?? '',
        ];
    }

    // ---- 4. Baru tampilkan (stream dari file lokal) ----
    $filename = trim(($dl['artist'] ? $dl['artist'] . ' - ' : '') . ($dl['name'] ?: $topTrack['title'])) . '.mp3';
    $filename = preg_replace('/[^\w\s\-\.\(\)&,]/u', '', $filename);

    streamLocalFile($cacheFile, $filename);
    exit;

} catch (Exception $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge($credit, [
        'status' => false,
        'message' => $e->getMessage(),
        'parameters' => $parameters
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
?>