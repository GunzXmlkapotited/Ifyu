<?php
error_reporting(0);
ini_set('display_errors', '0');
// Deskripsi: Portal Berita Indonesia - Multi Source
// Contoh: {"source":"antara"}
// JANGAN HAPUS CONTOH DIATAS - ITU FORMAT PARAMETER YANG BENAR
// @param source (antara|cnn|news|sindonews) Sumber Berita

header('Content-Type: application/json; charset=utf-8');

// ========== CREDIT ==========
$credit = [
    'creator' => 'Gunz'
];

set_time_limit(15);

$source = $_GET['source'] ?? 'antara';
$source = strtolower(trim($source));

$endpoints = [
    'antara'    => 'https://www.antaranews.com/rss/terkini.xml',
    'cnn'       => 'https://www.cnnindonesia.com/rss',
    'news'      => 'https://news.google.com/rss?hl=id&gl=ID&ceid=ID:id',
    'sindonews' => 'https://www.sindonews.com/feed',
];

if (!isset($endpoints[$source])) {
    $data = array_merge($credit, ['status' => false, 'message' => 'Sumber tidak valid']);
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $data = removeKeysRecursive($data, $keysToRemove);
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$ch = curl_init($endpoints[$source]);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT => 15,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_ENCODING => '',
    CURLOPT_HTTPHEADER => [
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept: application/rss+xml, application/xml, text/xml, */*'
    ]
]);

$response = curl_exec($ch);
curl_close($ch);

// ==== PARSE RSS (XML), bukan JSON ====
libxml_use_internal_errors(true);
$rss = simplexml_load_string($response);

if (!$rss) {
    $data = array_merge($credit, [
        'status' => false,
        'message' => 'Gagal ambil berita'
    ]);
    $keysToRemove = ['creator', 'Creator', 'author', 'Author'];
    $data = removeKeysRecursive($data, $keysToRemove);
    echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    exit;
}

$items = isset($rss->channel->item) ? $rss->channel->item : ($rss->entry ?? []);

$result = [];
foreach ($items as $item) {
    $link = isset($item->link['href']) ? (string)$item->link['href'] : (string)$item->link;
    $result[] = [
        'title' => trim((string)$item->title),
        'link'  => $link,
        'date'  => (string)($item->pubDate ?? $item->published ?? ''),
    ];
}

$data = array_merge($credit, [
    'status' => !empty($result),
    'source' => $source,
    'result' => $result
]);

$keysToRemove = ['creator', 'Creator', 'author', 'Author'];
$data = removeKeysRecursive($data, $keysToRemove);

echo json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

function removeKeysRecursive($array, $keysToRemove) {
    if (!is_array($array)) return $array;
    foreach ($keysToRemove as $key) unset($array[$key]);
    foreach ($array as &$value) {
        if (is_array($value)) $value = removeKeysRecursive($value, $keysToRemove);
    }
    return $array;
}
?>