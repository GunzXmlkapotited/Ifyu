// Jalankan dengan: npm run cluster
// Memanfaatkan semua core CPU → throughput naik ~N×
const cluster = require('cluster');
const os = require('os');

if (cluster.isPrimary) {
  const cpus = os.cpus().length;
  console.log(`🚀 Master ${process.pid} spawning ${cpus} workers...`);

  for (let i = 0; i < cpus; i++) cluster.fork();

  cluster.on('exit', (worker, code, signal) => {
    console.warn(`⚠️  Worker ${worker.process.pid} died (${signal || code}), restarting...`);
    cluster.fork();
  });
} else {
  require('./server.js');
}