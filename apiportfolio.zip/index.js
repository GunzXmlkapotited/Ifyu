const express = require('express');
const fs = require('fs');
const path = require('path');
const { spawn, execSync } = require('child_process');

const app = express();
const PORT = process.env.PORT || 8833;
const API_DIR = path.join(__dirname, 'api');

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

function commandExists(cmd) {
  try { execSync(`command -v ${cmd}`, { stdio: 'ignore' }); return true; }
  catch { return false; }
}

function getPhpBin() {
  if (process.env.PHP_BIN) return process.env.PHP_BIN;
  if (commandExists('php-cgi')) return 'php-cgi';
  if (commandExists('php')) return 'php';
  return null;
}

// Route dinamis: /api/<kategori>/<nama>
app.all('/api/:category/:name', (req, res) => {
  const { category, name } = req.params;
  const phpPath = path.join(API_DIR, category, `${name}.php`);

  if (!fs.existsSync(phpPath)) {
    return res.status(404).json({ error: 'Endpoint not found', path: `/api/${category}/${name}` });
  }

  const phpBin = getPhpBin();
  if (!phpBin) {
    return res.status(500).json({
      error: 'PHP binary not found',
      hint: 'Install: pkg install php (Termux) / sudo apt install php-cgi (Linux)'
    });
  }

  const query = new URLSearchParams(req.query).toString();

  const env = {
    ...process.env,
    PHPRC: __dirname,                    // ← arahkan ke php.ini di root
    REQUEST_METHOD: req.method,
    SCRIPT_FILENAME: phpPath,
    SCRIPT_NAME: `/api/${category}/${name}`,
    QUERY_STRING: query,
    CONTENT_TYPE: req.headers['content-type'] || '',
    CONTENT_LENGTH: req.headers['content-length'] || '',
    REMOTE_ADDR: req.ip || '127.0.0.1',
    SERVER_PROTOCOL: 'HTTP/1.1',
    GATEWAY_INTERFACE: 'CGI/1.1',
    REDIRECT_STATUS: '1'
  };

  const child = spawn(phpBin, [], { env });

  // Pipe body request ke stdin PHP
  req.pipe(child.stdin);

  let stdout = Buffer.alloc(0);
  let stderr = '';
  child.stdout.on('data', d => { stdout = Buffer.concat([stdout, d]); });
  child.stderr.on('data', d => { stderr += d.toString(); });

  child.on('close', (code) => {
    if (code !== 0 && !stdout.length) {
      return res.status(500).json({ error: 'PHP error', detail: stderr });
    }

    // Pisahkan header vs body
    const sepCRLF = stdout.indexOf('\r\n\r\n');
    const sepLF   = stdout.indexOf('\n\n');
    const sep     = sepCRLF >= 0 ? sepCRLF : sepLF;
    const skip    = sepCRLF >= 0 ? 4 : 2;

    let headers = '';
    let body = stdout;
    if (sep >= 0) {
      headers = stdout.slice(0, sep).toString('utf-8');
      body    = stdout.slice(sep + skip);
    }

    headers.split(/\r?\n/).forEach(line => {
      const i = line.indexOf(':');
      if (i > 0) {
        const k = line.slice(0, i).trim();
        const v = line.slice(i + 1).trim();
        if (k && !/^status$/i.test(k)) res.setHeader(k, v);
      }
    });

    if (!res.getHeader('Content-Type')) res.setHeader('Content-Type', 'application/json');
    res.status(200).send(body);
  });

  child.on('error', (err) => {
    res.status(500).json({ error: 'Spawn failed', detail: err.message, phpBin });
  });
});

// Root sederhana (opsional)
app.get('/', (req, res) => res.json({ status: 'ok', php: getPhpBin() }));

app.listen(PORT, () => {
  console.log(`🚀 http://localhost:${PORT}`);
  console.log(`🐘 PHP bin: ${getPhpBin() || 'NOT FOUND'}`);
});