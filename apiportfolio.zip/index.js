const express = require('express');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');
const { spawn, execSync } = require('child_process');

// ============================================================
//  📦 AUTO-INSTALL NODE_MODULES
// ============================================================
if (!fs.existsSync(path.join(__dirname, 'node_modules'))) {
  console.log('📦 node_modules belum ada, installing dependencies...');
  try {
    execSync('npm install', { stdio: 'inherit', cwd: __dirname });
    console.log('✅ Dependencies installed');
  } catch (err) {
    console.log('❌ npm install gagal:', err.message);
    process.exit(1);
  }
}

// ============================================================
//  🔧 AUTO-INSTALL PHP
// ============================================================
function commandExists(cmd) {
  try {
    execSync(`command -v ${cmd}`, { stdio: 'ignore' });
    return true;
  } catch { return false; }
}

function detectPlatform() {
  const platform = os.platform();
  if (platform === 'android' || process.env.PREFIX?.includes('com.termux')) return 'termux';
  if (platform === 'linux') return 'linux';
  if (platform === 'darwin') return 'macos';
  if (platform === 'win32') return 'windows';
  return 'unknown';
}

function autoInstallPHP() {
  if (commandExists('php-cgi')) {
    console.log('✅ PHP-CGI sudah terinstall');
    return true;
  }
  if (commandExists('php')) {
    console.log('✅ PHP sudah terinstall (pakai php CLI)');
    return true;
  }

  const platform = detectPlatform();
  console.log(`⚙️  PHP belum terinstall. Mencoba auto-install untuk: ${platform}...`);

  try {
    if (platform === 'termux') {
      execSync('pkg update -y && pkg install -y php', { stdio: 'inherit' });
    } else if (platform === 'linux') {
      let distro = '';
      try {
        const release = fs.readFileSync('/etc/os-release', 'utf-8');
        if (/ubuntu|debian/i.test(release)) distro = 'debian';
        else if (/alpine/i.test(release)) distro = 'alpine';
        else if (/centos|rhel|fedora/i.test(release)) distro = 'redhat';
        else if (/arch/i.test(release)) distro = 'arch';
      } catch {}

      if (distro === 'debian') {
        execSync('sudo apt update && sudo apt install -y php-cgi php-cli php-curl php-mbstring', { stdio: 'inherit' });
      } else if (distro === 'alpine') {
        execSync('apk add --no-cache php82 php82-cgi php82-curl php82-mbstring php82-openssl', { stdio: 'inherit' });
      } else if (distro === 'redhat') {
        execSync('sudo dnf install -y php-cli php-curl php-mbstring', { stdio: 'inherit' });
      } else if (distro === 'arch') {
        execSync('sudo pacman -S --noconfirm php php-cgi', { stdio: 'inherit' });
      } else {
        console.log('⚠️  Distro tidak dikenali. Install manual: sudo apt install php-cgi');
        return false;
      }
    } else if (platform === 'macos') {
      if (!commandExists('brew')) {
        console.log('⚠️  Homebrew tidak ada. Install manual: brew install php');
        return false;
      }
      execSync('brew install php', { stdio: 'inherit' });
    } else if (platform === 'windows') {
      console.log('⚠️  Windows: install PHP manual dari https://windows.php.net/download/');
      return false;
    } else {
      console.log('⚠️  Platform tidak dikenali. Install PHP manual.');
      return false;
    }

    console.log('✅ PHP berhasil diinstall!');
    return true;
  } catch (err) {
    console.log('❌ Auto-install PHP gagal:', err.message);
    console.log('💡 Install manual: pkg install php (Termux) / sudo apt install php-cgi (Linux)');
    return false;
  }
}

autoInstallPHP();

// ============================================================
//  🚀 EXPRESS SETUP
// ============================================================
const app = express();
const PORT = process.env.PORT || 8833;

// ============================================================
//  KONFIGURASI
// ============================================================
const SECRET_KEY = 'GunzSecure2025!@#';
const TARGET_HOST = 'am.dapjisync.my.id';
const TARGET_API_KEY = 'FREE';

const PUBLIC_DIR   = path.join(__dirname, 'public');
const TOOLS_DIR    = path.join(__dirname, 'tools');
const ALLTOOLS_DIR = path.join(__dirname, 'alltools');
const API_DIR      = path.join(__dirname, 'api');

// ============================================================
//  🔒 TOKEN SEKALI PAKAI
// ============================================================
const validTokens = new Map();
const LINKS_TO_REWRITE = [
  'alltools.html', 'alltools', '/alltools',
  'tools-Am-Premium.html', 'tools-Am-Premium', '/tools-Am-Premium',
  'tools-tiktok', '/tools-tiktok', 'docs', '/docs'
];
const TOKEN_TTL = 10 * 60 * 1000;

function createToken() {
  const token = crypto.randomBytes(16).toString('hex');
  validTokens.set(token, { expires: Date.now() + TOKEN_TTL, used: false });
  return token;
}

function validateAndConsumeToken(token) {
  if (!token) return false;
  const data = validTokens.get(token);
  if (!data || data.used || Date.now() > data.expires) {
    validTokens.delete(token);
    return false;
  }
  validTokens.delete(token);
  return true;
}

setInterval(() => {
  const now = Date.now();
  for (const [token, data] of validTokens.entries()) {
    if (now > data.expires) validTokens.delete(token);
  }
}, 5 * 60 * 1000);

// ============================================================
//  🔧 HELPER
// ============================================================
function linkToRegex(link) {
  const cleanLink = link.replace(/^\//, '');
  const escaped = cleanLink.replace(/\./g, '\\.');
  return new RegExp(`href="(\\/?)${escaped}(\\?[^"]*)?"`, 'g');
}

function injectTokenToHtml(html, token) {
  let result = html;
  const seen = new Set();
  LINKS_TO_REWRITE.forEach(link => {
    const cleanLink = link.replace(/^\//, '');
    if (seen.has(cleanLink)) return;
    seen.add(cleanLink);
    result = result.replace(linkToRegex(cleanLink), (m, slash) => {
      return `href="${slash}${cleanLink}?access=${token}"`;
    });
  });
  return result;
}

function redirectIfNotLoggedIn(req, res, next) {
  if (!validateAndConsumeToken(req.query.access)) return res.redirect('/');
  next();
}

function injectTokenMiddleware(req, res, next) {
  const originalSendFile = res.sendFile.bind(res);
  res.sendFile = function (filePath, options, callback) {
    fs.readFile(filePath, 'utf-8', (err, html) => {
      if (err) return originalSendFile(filePath, options, callback);
      const hasProtectedLink = LINKS_TO_REWRITE.some(link => {
        const cleanLink = link.replace(/^\//, '');
        return new RegExp(`href="(\\/?)${cleanLink.replace(/\./g, '\\.')}(\\?[^"]*)?"`).test(html);
      });
      if (!hasProtectedLink) return originalSendFile(filePath, options, callback);
      const newToken = createToken();
      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.type('html').send(injectTokenToHtml(html, newToken));
    });
  };
  next();
}

app.use(injectTokenMiddleware);
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// ============================================================
//  🛡️ PROTEKSI FILE HTML DARI AKSES LANGSUNG
// ============================================================
const PROTECTED_HTML = [
  'alltools.html',
  'tools-Am-Premium.html',
  'tools-tiktok.html',
  'tiktok.html',
  'docs.html'
];

app.use((req, res, next) => {
  const fileName = path.basename(req.path).toLowerCase();
  if (PROTECTED_HTML.map(f => f.toLowerCase()).includes(fileName)) {
    return redirectIfNotLoggedIn(req, res, next);
  }
  next();
});

// ============================================================
//  📚 AUTO-DETECT API DOCS (PHP + JS)
// ============================================================
const CATEGORY_LABELS = {
  'ai': 'AI',
  'ai-image': 'AI Image',
  'downloader': 'Downloader',
  'game': 'Game',
  'informasi': 'Informasi',
  'maker': 'Maker',
  'random': 'Random',
  'search': 'Search',
  'tools': 'Tools',
  'uploader': 'Uploader',
  'videystream': 'Video Stream'
};

function scanApiFolder() {
  const result = [];
  if (!fs.existsSync(API_DIR)) return result;

  const categories = fs.readdirSync(API_DIR).filter(f => {
    try {
      return fs.statSync(path.join(API_DIR, f)).isDirectory();
    } catch { return false; }
  });

  categories.forEach(cat => {
    const catPath = path.join(API_DIR, cat);
    const files = fs.readdirSync(catPath).filter(f => /\.(php|js)$/i.test(f));

    files.forEach(file => {
      const name = file.replace(/\.(php|js)$/i, '');
      const fullPath = path.join(catPath, file);
      const ext = path.extname(file).toLowerCase();

      let params = [];
      let method = 'GET';
      let description = '';
      let outputType = 'json';

      try {
        const content = fs.readFileSync(fullPath, 'utf-8');

        const descMatch = content.match(/\/\/\s*Deskripsi\s*:\s*(.+)/i);
        if (descMatch) description = descMatch[1].trim();

        const hasPost  = /\$_POST\s*\[/.test(content);
        const hasFiles = /\$_FILES\s*\[/.test(content);
        const hasGet   = /\$_GET\s*\[/.test(content);
        if (hasFiles || hasPost) method = 'POST';
        else if (hasGet)         method = 'GET';

        if (/header\s*\(\s*['"]Content-Type:\s*image\//i.test(content)) outputType = 'image';
        else if (/header\s*\(\s*['"]Content-Type:\s*audio\//i.test(content)) outputType = 'audio';
        else if (/header\s*\(\s*['"]Content-Type:\s*text\/html/i.test(content)) outputType = 'html';
        else outputType = 'json';

        const getMatches  = [...content.matchAll(/\$_GET\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);
        const postMatches = [...content.matchAll(/\$_POST\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);
        const fileMatches = [...content.matchAll(/\$_FILES\s*\[\s*['"]([^'"]+)['"]\s*\]/g)].map(m => m[1]);

        const allParams = [...new Set([...getMatches, ...postMatches])];
        const blacklist = ['apikey', 'api_key', 'key', 'token', 'creator'];

        const paramOptions = {};
        const paramBlockRegex = /@param\s+(\w+)\s*\(([^)]+)\)/g;
        let pm;
        while ((pm = paramBlockRegex.exec(content)) !== null) {
          const pName = pm[1];
          const opts = pm[2].split('|').map(s => s.trim()).filter(Boolean);
          if (opts.length) paramOptions[pName] = opts;
        }

        params = allParams
          .filter(p => !blacklist.includes(p.toLowerCase()))
          .map(p => ({
            name: p,
            placeholder: `Masukkan ${p}...`,
            options: paramOptions[p] || null,
            type: 'text'
          }));

        fileMatches.forEach(fname => {
          if (!params.find(p => p.name === fname)) {
            params.push({
              name: fname,
              placeholder: `Upload ${fname}...`,
              options: null,
              type: 'file'
            });
          }
        });
      } catch (err) {}

      result.push({
        category: CATEGORY_LABELS[cat] || cat,
        categoryRaw: cat,
        name: name.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        method,
        path: `/api/${cat}/${name}`,
        params,
        description,
        outputType,
        ext
      });
    });
  });

  return result;
}

// ============================================================
//  📊 ROUTE DOCS
// ============================================================
app.get('/api/config', (req, res) => {
  res.json(scanApiFolder());
});

app.get('/api/stats', (req, res) => {
  const data = scanApiFolder();
  res.json({
    requests: Math.floor(Math.random() * 9000) + 1000,
    latency: '45ms',
    endpoints: data.length,
    categories: [...new Set(data.map(d => d.category))].length
  });
});

// ============================================================
//  🚀 DYNAMIC API ROUTER (JS + PHP)
// ============================================================
app.all('/api/:category/:name', async (req, res) => {
  const { category, name } = req.params;

  const jsPath  = path.join(API_DIR, category, `${name}.js`);
  const phpPath = path.join(API_DIR, category, `${name}.php`);

  if (fs.existsSync(jsPath)) {
    try {
      delete require.cache[require.resolve(jsPath)];
      let handler = require(jsPath);
      if (handler.default) handler = handler.default;
      if (typeof handler !== 'function') return res.status(500).json({ error: 'Handler is not a function' });
      return await handler(req, res);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  if (fs.existsSync(phpPath)) {
    const query = new URLSearchParams(req.query).toString();

    let phpBin = process.env.PHP_BIN;
    if (!phpBin) {
      if (commandExists('php-cgi')) phpBin = 'php-cgi';
      else if (commandExists('php')) phpBin = 'php';
      else phpBin = 'php-cgi';
    }

    const env = {
      ...process.env,
      REQUEST_METHOD: req.method,
      SCRIPT_FILENAME: phpPath,
      SCRIPT_NAME: `/api/${category}/${name}`,
      QUERY_STRING: query,
      CONTENT_TYPE: req.headers['content-type'] || '',
      CONTENT_LENGTH: req.headers['content-length'] || '',
      REMOTE_ADDR: req.ip || '127.0.0.1',
      SERVER_PROTOCOL: 'HTTP/1.1',
      GATEWAY_INTERFACE: 'CGI/1.1',
      REDIRECT_STATUS: '1'
    };

    const child = spawn(phpBin, [], { env });

    let bodyChunks = [];
    req.on('data', c => bodyChunks.push(c));
    req.on('end', () => {
      if (bodyChunks.length) child.stdin.write(Buffer.concat(bodyChunks));
      child.stdin.end();
    });

    let stdout = Buffer.alloc(0);
    let stderr = '';
    child.stdout.on('data', d => { stdout = Buffer.concat([stdout, d]); });
    child.stderr.on('data', d => { stderr += d.toString(); });

    child.on('close', (code) => {
      if (code !== 0 && !stdout.length) {
        return res.status(500).json({ error: 'PHP error', detail: stderr });
      }

      const sep = stdout.indexOf('\r\n\r\n') >= 0
        ? stdout.indexOf('\r\n\r\n')
        : stdout.indexOf('\n\n');

      let headers = '';
      let body = stdout;
      if (sep >= 0) {
        headers = stdout.slice(0, sep).toString('utf-8');
        body = stdout.slice(sep + (stdout.indexOf('\r\n\r\n') >= 0 ? 4 : 2));
      }

      headers.split(/\r?\n/).forEach(line => {
        const idx = line.indexOf(':');
        if (idx > 0) {
          const k = line.slice(0, idx).trim();
          const v = line.slice(idx + 1).trim();
          if (k && !/^status$/i.test(k)) res.setHeader(k, v);
        }
      });

      if (!res.getHeader('Content-Type')) res.setHeader('Content-Type', 'application/json');
      res.status(200).send(body);
    });

    child.on('error', (err) => {
      res.status(500).json({
        error: 'PHP binary not found',
        detail: err.message,
        hint: 'Install PHP: pkg install php (Termux) / sudo apt install php-cgi (Linux)',
        phpBin
      });
    });
    return;
  }

  return res.status(404).json({
    error: 'Endpoint not found',
    path: `/api/${category}/${name}`,
    tried: [jsPath, phpPath]
  });
});

// ============================================================
//  🎯 ROUTES
// ============================================================
app.get('/', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// 🔒 DOCS IKUT TERPROTEKSI
app.get('/docs', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'docs.html'));
});

app.get('/alltools', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(ALLTOOLS_DIR, 'alltools.html'));
});

app.get('/tools-Am-Premium', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'tools-Am-Premium.html'));
});

app.get('/tools-tiktok', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'tiktok.html'));
});

// ============================================================
//  🖼️ STATIC FILES
// ============================================================
app.use(express.static(PUBLIC_DIR, { index: false }));
app.use(express.static(TOOLS_DIR, { index: false }));
app.use(express.static(ALLTOOLS_DIR, { index: false }));

// ============================================================
//  🔄 PROXY API
// ============================================================
function proxyRequest(targetPath) {
  return (req, res) => {
    const body = JSON.stringify(req.body || {});
    const options = {
      hostname: TARGET_HOST,
      port: 443,
      path: targetPath,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': TARGET_API_KEY,
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': 'GunzProxy/1.0'
      }
    };

    const proxyReq = https.request(options, proxyRes => {
      let data = '';
      proxyRes.on('data', chunk => { data += chunk; });
      proxyRes.on('end', () => {
        res.writeHead(proxyRes.statusCode || 200, {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'POST, OPTIONS',
          'Access-Control-Allow-Headers': 'Content-Type, X-API-Key'
        });
        res.end(data);
      });
    });

    proxyReq.on('error', err => {
      res.writeHead(502, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(JSON.stringify({ error: 'Proxy error: ' + err.message }));
    });

    if (body) proxyReq.write(body);
    proxyReq.end();
  };
}

app.post('/api/send', proxyRequest('/api/send'));
app.post('/api/verif', proxyRequest('/api/verif'));
app.post('/api/bulk', proxyRequest('/api/bulk'));

// ============================================================
//  🚀 JALANKAN
// ============================================================
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║   🚀 Server Gunz (Express): http://localhost:${PORT}           ║
║   📁 public | tools | alltools | api                          ║
║   📚 Docs: http://localhost:${PORT}/docs                        ║
║   🔒 Token SEKALI PAKAI (semua halaman terproteksi)           ║
╚══════════════════════════════════════════════════════════════╝
  `);
});