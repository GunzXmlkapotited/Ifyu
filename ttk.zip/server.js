// ============================================
// FILE: server.js
// Akses langsung tanpa tombol
// ============================================

const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.static('public'));

// ============================================
// ROUTE LANGSUNG UNTUK ZS4a2pGD4
// ============================================

// Ketika akses http://localhost:3000/ZS4a2pGD4
// Langsung tampilkan halaman tanpa klik apapun
app.get('/ZS4a2pGD4/', (req, res) => {
    const htmlPath = path.join(__dirname, 'public', 'index.html');
    
    fs.readFile(htmlPath, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Error membaca file');
        }
        
        res.send(data);
        
        console.log(`✅ Akses langsung: ZS4a2pGD4`);
        console.log(`📱 IP: ${req.ip}`);
        console.log(`⏰ Waktu: ${new Date().toLocaleString()}`);
        console.log(`🌐 User-Agent: ${req.get('User-Agent')}`);
        console.log('---');
    });
});

// ============================================
// ROUTE UTAMA
// ============================================

app.get('/', (req, res) => {
    // Redirect langsung ke ZS4a2pGD4
    res.redirect('/ZS4a2pGD4/');
});

// ============================================
// START SERVER
// ============================================

app.listen(PORT, () => {
    console.log(`\n✅ Server berjalan di http://localhost:${PORT}`);
    console.log(`🔑 Akses langsung: http://localhost:${PORT}/ZS4a2pGD4`);
    console.log(`🔄 Redirect: http://localhost:${PORT} -> /ZS4a2pGD4`);
    console.log(`🛑 Tekan CTRL+C untuk berhenti\n`);
});

// ============================================
// ERROR HANDLING
// ============================================

app.use((err, req, res, next) => {
    console.error('❌ Error:', err.message);
    res.status(500).send('Terjadi kesalahan pada server');
});