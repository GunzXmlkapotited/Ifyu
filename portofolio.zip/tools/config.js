          
          
          
          
          window.API_URL = "https://portofolio_gunz.xonepanel.qzz.io";