<?php
error_reporting(0);
ini_set('display_errors', '0');

/**
 * ───「 FEATURE AUTHOR 」───
 * 👤 Author     : Lynx Decode
 * 📞 Contact    : +62 882-5804-1396
 * 📢 Channel    : https://whatsapp.com/channel/0029VbAnuii6GcGCu73oep1i
 * ⚠️ Note       : Keep credit to respect the creator!
 * ─────────────────────────
 * 📝 Plugin: Alight Motion Apply Premium
 * 📌 Dikonversi ke PHP oleh Gunz
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { 
    http_response_code(200); 
    exit; 
}

// ========== CREDIT ==========
$credit = ['creator' => 'Gunz', 'original' => 'Lynx Decode'];

// Ambil parameter email
$email = trim($_GET['email'] ?? $_POST['email'] ?? '');

// Validasi email
if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => false, 
        'creator' => 'Gunz', 
        'msg' => "┌˚₊ ๑│ A P P L Y   P R E M I U M │๑˚₊ ⚠️\n" .
                 "┇ \n" .
                 "│ ❌ Email tidak valid atau kosong!\n" .
                 "│ \n" .
                 "│ 📌 Cara pakai:\n" .
                 "│ GET/POST ?email=example@gmail.com\n" .
                 "│ \n" .
                 "│ 💡 Tips: Masukkan email yang valid untuk mengaktifkan premium.\n" .
                 "┇ \n" .
                 "└˚₊ ๑ ────────────── ๑˚₊\n" .
                 "> © ERINE-AI"
    ]);
    exit;
}

// Fungsi untuk memanggil API applyPremium
function applyPremium($email) {
    $url = 'https://api.kyzznekoo.my.id/api/alightmotion/v3/applyPremium?email=' . urlencode($email);
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/json'
        ]
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 && $response) {
        return json_decode($response, true);
    }
    
    return null;
}

// Panggil API applyPremium
$response = applyPremium($email);

if (!$response) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => false,
        'creator' => 'Gunz',
        'msg' => 'Gagal menghubungi server API',
        'email' => $email
    ]);
    exit;
}

// Cek status response
if (!isset($response['status']) || !$response['status']) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => false,
        'creator' => 'Gunz',
        'msg' => $response['message'] ?? 'Gagal mengaktifkan premium',
        'email' => $email
    ]);
    exit;
}

// Kirim response sukses
header('Content-Type: application/json');
echo json_encode([
    'status' => true,
    'creator' => 'Gunz',
    'data' => [
        'email' => $email,
        'premium_status' => 'activated',
        'message' => $response['message'] ?? 'Premium berhasil diaktifkan',
        'premium_data' => $response['data'] ?? $response
    ]
], JSON_PRETTY_PRINT);
?>
