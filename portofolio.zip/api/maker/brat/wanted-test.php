<?php
/*
=========================================
MOST WANTED - PHOTO COSTUME GENERATOR
=========================================
Fitur: Menempatkan foto costume di kotak tengah template
Dengan efek "cover" (foto otomatis dipotong agar pas)
=========================================
Cara pakai:
?image_url=https://domain.com/foto.jpg
*/

error_reporting(0);
ini_set('display_errors', '0');

// ========== 1. PARAMETER ==========
// Ambil URL foto dari parameter 'image_url'
$imageUrl = $_GET['image_url'] ?? null;

if (!$imageUrl) {
    // Jika tidak ada URL, tampilkan error
    header('Content-Type: application/json');
    echo json_encode([
        'status' => false,
        'message' => 'Parameter image_url wajib diisi! Contoh: ?image_url=https://example.com/foto.jpg'
    ], JSON_PRETTY_PRINT);
    exit;
}

// ========== 2. URL TEMPLATE ==========
define('TEMPLATE_URL', 'https://c.termai.cc/i168/VJjK.jpg');

// ========== 3. KONFIGURASI ==========
$CANVAS = [
    'width' => 800,   // Ukuran template (sesuaikan jika perlu)
    'height' => 1000
];

// ========== 4. AREA KOTAK TENGAH (TEMPAT FOTO) ==========
// Koordinat ini harus disesuaikan dengan template asli
$PHOTO_BOX = [
    'x' => 100,   // Posisi X kiri
    'y' => 250,   // Posisi Y atas
    'w' => 600,   // Lebar kotak
    'h' => 500    // Tinggi kotak
];

// ========== 5. FUNGSI DOWNLOAD ==========
function downloadBuffer($url) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => 'Mozilla/5.0'
    ]);
    $data = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if (!$data || $httpCode !== 200) {
        throw new Exception('Gagal download: ' . $url . ' (HTTP ' . $httpCode . ')');
    }
    return $data;
}

// ========== 6. PROSES UTAMA ==========
try {
    // 6a. Download template
    $templateBuffer = downloadBuffer(TEMPLATE_URL);
    $template = imagecreatefromstring($templateBuffer);
    if (!$template) throw new Exception('Gagal memuat template');
    
    // 6b. Buat canvas dengan ukuran template
    $templateWidth = imagesx($template);
    $templateHeight = imagesy($template);
    $canvas = imagecreatetruecolor($templateWidth, $templateHeight);
    
    // Copy template ke canvas
    imagecopy($canvas, $template, 0, 0, 0, 0, $templateWidth, $templateHeight);
    imagedestroy($template);
    
    // 6c. Download foto costume
    $photoBuffer = downloadBuffer($imageUrl);
    $photo = imagecreatefromstring($photoBuffer);
    if (!$photo) throw new Exception('Gagal memuat foto. Pastikan URL foto valid (JPG/PNG).');
    
    // 6d. Dapatkan ukuran foto asli
    $photoWidth = imagesx($photo);
    $photoHeight = imagesy($photo);
    
    // 6e. Hitung skala "cover" (seperti object-fit: cover)
    $boxW = $PHOTO_BOX['w'];
    $boxH = $PHOTO_BOX['h'];
    $boxX = $PHOTO_BOX['x'];
    $boxY = $PHOTO_BOX['y'];
    
    // Skala agar foto menutupi seluruh kotak
    $scaleX = $boxW / $photoWidth;
    $scaleY = $boxH / $photoHeight;
    $scale = max($scaleX, $scaleY); // Pakai yang terbesar agar menutupi
    
    // Ukuran foto setelah di-skala
    $newWidth = (int)($photoWidth * $scale);
    $newHeight = (int)($photoHeight * $scale);
    
    // Posisi crop (ambil bagian tengah foto)
    $cropX = (int)(($newWidth - $boxW) / 2);
    $cropY = (int)(($newHeight - $boxH) / 2);
    
    // Buat gambar sementara dengan ukuran baru
    $resizedPhoto = imagecreatetruecolor($newWidth, $newHeight);
    imagecopyresampled(
        $resizedPhoto, $photo,
        0, 0, 0, 0,
        $newWidth, $newHeight,
        $photoWidth, $photoHeight
    );
    imagedestroy($photo);
    
    // 6f. Tempelkan foto ke canvas (hanya bagian tengah yang muat di kotak)
    imagecopy(
        $canvas,
        $resizedPhoto,
        $boxX, $boxY,           // Target: posisi kotak
        $cropX, $cropY,         // Source: mulai dari crop
        $boxW, $boxH            // Ukuran yang ditempel
    );
    imagedestroy($resizedPhoto);
    
    // ========== 7. OUTPUT ==========
    header('Content-Type: image/png');
    imagepng($canvas);
    
    imagedestroy($canvas);
    
} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => false,
        'message' => $e->getMessage()
    ], JSON_PRETTY_PRINT);
}
?>
