// ============================================================
//  🚀 GUNZ SERVER — Express (Node.js only, NO PHP, NO CORS)
//  🎵 ROOT → music.html (Landing Page)
// ============================================================

const express = require('express');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');

// ============================================================
//  📦 AUTO-INSTALL NODE_MODULES
// ============================================================
if (!fs.existsSync(path.join(__dirname, 'node_modules'))) {
  console.log('📦 node_modules belum ada, installing dependencies...');
  try {
    execSync('npm install', { stdio: 'inherit', cwd: __dirname });
    console.log('✅ Dependencies installed');
  } catch (err) {
    console.log('❌ npm install gagal:', err.message);
    process.exit(1);
  }
}

// ============================================================
//  🚀 EXPRESS SETUP
// ============================================================
const app = express();
const PORT = process.env.PORT || 3000;

// ============================================================
//  KONFIGURASI
// ============================================================
const SECRET_KEY = 'GunzSecure2025!@#';
const TARGET_HOST = 'am.dapjisync.my.id';
const TARGET_API_KEY = 'FREE';

const PUBLIC_DIR   = path.join(__dirname, 'public');
const TOOLS_DIR    = path.join(__dirname, 'tools');
const ALLTOOLS_DIR = path.join(__dirname, 'alltools');
const API_DIR      = path.join(__dirname, 'api');

// ============================================================
//  🔒 TOKEN SEKALI PAKAI
// ============================================================
const validTokens = new Map();
const LINKS_TO_REWRITE = [
  'alltools.html', 'alltools', '/alltools',
  'tools-Am-Premium.html', 'tools-Am-Premium', '/tools-Am-Premium',
  'tools-tiktok', '/tools-tiktok', 'docs', '/docs'
];
const TOKEN_TTL = 10 * 60 * 1000;

function createToken() {
  const token = crypto.randomBytes(16).toString('hex');
  validTokens.set(token, { expires: Date.now() + TOKEN_TTL, used: false });
  return token;
}

function validateAndConsumeToken(token) {
  if (!token) return false;
  const data = validTokens.get(token);
  if (!data || data.used || Date.now() > data.expires) {
    validTokens.delete(token);
    return false;
  }
  validTokens.delete(token);
  return true;
}

setInterval(() => {
  const now = Date.now();
  for (const [token, data] of validTokens.entries()) {
    if (now > data.expires) validTokens.delete(token);
  }
}, 5 * 60 * 1000);

// ============================================================
//  🔧 HELPER
// ============================================================
function linkToRegex(link) {
  const cleanLink = link.replace(/^\//, '');
  const escaped = cleanLink.replace(/\./g, '\\.');
  return new RegExp(`href="(\\/?)${escaped}(\\?[^"]*)?"`, 'g');
}

function injectTokenToHtml(html, token) {
  let result = html;
  const seen = new Set();
  LINKS_TO_REWRITE.forEach(link => {
    const cleanLink = link.replace(/^\//, '');
    if (seen.has(cleanLink)) return;
    seen.add(cleanLink);
    result = result.replace(linkToRegex(cleanLink), (m, slash) => {
      return `href="${slash}${cleanLink}?access=${token}"`;
    });
  });
  return result;
}

function redirectIfNotLoggedIn(req, res, next) {
  if (!validateAndConsumeToken(req.query.access)) return res.redirect('/');
  next();
}

function injectTokenMiddleware(req, res, next) {
  const originalSendFile = res.sendFile.bind(res);
  res.sendFile = function (filePath, options, callback) {
    fs.readFile(filePath, 'utf-8', (err, html) => {
      if (err) return originalSendFile(filePath, options, callback);
      const hasProtectedLink = LINKS_TO_REWRITE.some(link => {
        const cleanLink = link.replace(/^\//, '');
        return new RegExp(`href="(\\/?)${cleanLink.replace(/\./g, '\\.')}(\\?[^"]*)?"`).test(html);
      });
      if (!hasProtectedLink) return originalSendFile(filePath, options, callback);
      const newToken = createToken();
      res.set('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.type('html').send(injectTokenToHtml(html, newToken));
    });
  };
  next();
}

app.use(injectTokenMiddleware);
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// ============================================================
//  🛡️ PROTEKSI FILE HTML DARI AKSES LANGSUNG
// ============================================================
const PROTECTED_HTML = [
  'alltools.html',
  'tools-Am-Premium.html',
  'tools-tiktok.html',
  'tiktok.html',
  'docs.html'
];

app.use((req, res, next) => {
  const fileName = path.basename(req.path).toLowerCase();
  if (PROTECTED_HTML.map(f => f.toLowerCase()).includes(fileName)) {
    return redirectIfNotLoggedIn(req, res, next);
  }
  next();
});

// ============================================================
//  📚 AUTO-DETECT API DOCS (JS ONLY)
// ============================================================
const CATEGORY_LABELS = {
  'ai': 'AI',
  'ai-image': 'AI Image',
  'downloader': 'Downloader',
  'game': 'Game',
  'informasi': 'Informasi',
  'maker': 'Maker',
  'random': 'Random',
  'search': 'Search',
  'tools': 'Tools',
  'uploader': 'Uploader',
  'videystream': 'Video Stream'
};

function scanApiFolder() {
  const result = [];
  if (!fs.existsSync(API_DIR)) return result;

  const categories = fs.readdirSync(API_DIR).filter(f => {
    try {
      return fs.statSync(path.join(API_DIR, f)).isDirectory();
    } catch { return false; }
  });

  categories.forEach(cat => {
    const catPath = path.join(API_DIR, cat);
    const files = fs.readdirSync(catPath).filter(f => /\.js$/i.test(f));

    files.forEach(file => {
      const name = file.replace(/\.js$/i, '');
      const fullPath = path.join(catPath, file);

      let params = [];
      let method = 'GET';
      let description = '';
      let outputType = 'json';

      try {
        const content = fs.readFileSync(fullPath, 'utf-8');

        const descMatch = content.match(/\/\/\s*Deskripsi\s*:\s*(.+)/i);
        if (descMatch) description = descMatch[1].trim();

        const hasBody = /req\.body/.test(content);
        const hasQuery = /req\.query/.test(content);
        if (hasBody) method = 'POST';
        else if (hasQuery) method = 'GET';

        if (/res\.type\s*\(\s*['"]image\//i.test(content) || /res\.setHeader\s*\(\s*['"]Content-Type['"]\s*,\s*['"]image\//i.test(content)) outputType = 'image';
        else if (/res\.type\s*\(\s*['"]audio\//i.test(content)) outputType = 'audio';
        else if (/res\.sendFile/.test(content) || /res\.type\s*\(\s*['"]text\/html/i.test(content)) outputType = 'html';
        else outputType = 'json';

        const queryMatches = [...content.matchAll(/req\.query\s*[\.\[]\s*['"]?([a-zA-Z_][a-zA-Z0-9_]*)['"]?\s*\]?/g)].map(m => m[1]);
        const bodyMatches  = [...content.matchAll(/req\.body\s*[\.\[]\s*['"]?([a-zA-Z_][a-zA-Z0-9_]*)['"]?\s*\]?/g)].map(m => m[1]);

        const allParams = [...new Set([...queryMatches, ...bodyMatches])];
        const blacklist = ['apikey', 'api_key', 'key', 'token', 'creator'];

        const paramOptions = {};
        const paramBlockRegex = /@param\s+(\w+)\s*\(([^)]+)\)/g;
        let pm;
        while ((pm = paramBlockRegex.exec(content)) !== null) {
          const pName = pm[1];
          const opts = pm[2].split('|').map(s => s.trim()).filter(Boolean);
          if (opts.length) paramOptions[pName] = opts;
        }

        params = allParams
          .filter(p => !blacklist.includes(p.toLowerCase()))
          .map(p => ({
            name: p,
            placeholder: `Masukkan ${p}...`,
            options: paramOptions[p] || null,
            type: 'text'
          }));
      } catch (err) {}

      result.push({
        category: CATEGORY_LABELS[cat] || cat,
        categoryRaw: cat,
        name: name.replace(/[-_]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        method,
        path: `/api/${cat}/${name}`,
        params,
        description,
        outputType,
        ext: 'js'
      });
    });
  });

  return result;
}

// ============================================================
//  📊 ROUTE DOCS
// ============================================================
app.get('/api/config', (req, res) => {
  res.json(scanApiFolder());
});

app.get('/api/stats', (req, res) => {
  const data = scanApiFolder();
  res.json({
    requests: Math.floor(Math.random() * 9000) + 1000,
    latency: '45ms',
    endpoints: data.length,
    categories: [...new Set(data.map(d => d.category))].length
  });
});

// ============================================================
//  🚀 DYNAMIC API ROUTER (JS ONLY)
// ============================================================
app.all('/api/:category/:name', async (req, res) => {
  const { category, name } = req.params;
  const jsPath = path.join(API_DIR, category, `${name}.js`);

  if (fs.existsSync(jsPath)) {
    try {
      delete require.cache[require.resolve(jsPath)];
      let handler = require(jsPath);
      if (handler.default) handler = handler.default;
      if (typeof handler !== 'function') {
        return res.status(500).json({ error: 'Handler is not a function' });
      }
      return await handler(req, res);
    } catch (err) {
      return res.status(500).json({ error: err.message });
    }
  }

  return res.status(404).json({
    error: 'Endpoint not found',
    path: `/api/${category}/${name}`,
    tried: [jsPath]
  });
});

// ============================================================
//  🎯 ROUTES
// ============================================================

// 🎵 ROOT → music.html (landing page utama)
app.get('/', (req, res) => {
  const musicPath = path.join(PUBLIC_DIR, 'music.html');
  if (fs.existsSync(musicPath)) {
    return res.sendFile(musicPath);
  }
  const indexPath = path.join(PUBLIC_DIR, 'index.html');
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  res.status(404).send('Landing page (music.html) tidak ditemukan.');
});

// 🏠 Portfolio asli (index.html lama) — akses via /home
app.get('/home', (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'index.html'));
});

// 📄 Halaman terproteksi (butuh token sekali pakai)
app.get('/docs', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'docs.html'));
});

app.get('/alltools', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(ALLTOOLS_DIR, 'alltools.html'));
});

app.get('/tools-Am-Premium', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'tools-Am-Premium.html'));
});

app.get('/tools-tiktok', redirectIfNotLoggedIn, (req, res) => {
  res.sendFile(path.join(TOOLS_DIR, 'tiktok.html'));
});

// ============================================================
//  🖼️ STATIC FILES
// ============================================================
app.use(express.static(PUBLIC_DIR, {
  index: false,
  setHeaders: (res, filePath) => {
    const base = path.basename(filePath).toLowerCase();
    if (base === 'index.html' || base === 'music.html') {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    }
  }
}));
app.use(express.static(TOOLS_DIR, { index: false }));
app.use(express.static(ALLTOOLS_DIR, { index: false }));

// ============================================================
//  🔄 PROXY API
// ============================================================
function proxyRequest(targetPath) {
  return (req, res) => {
    const body = JSON.stringify(req.body || {});
    const options = {
      hostname: TARGET_HOST,
      port: 443,
      path: targetPath,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': TARGET_API_KEY,
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': 'GunzProxy/1.0'
      }
    };

    const proxyReq = https.request(options, proxyRes => {
      let data = '';
      proxyRes.on('data', chunk => { data += chunk; });
      proxyRes.on('end', () => {
        res.writeHead(proxyRes.statusCode || 200, {
          'Content-Type': 'application/json'
        });
        res.end(data);
      });
    });

    proxyReq.on('error', err => {
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Proxy error: ' + err.message }));
    });

    if (body) proxyReq.write(body);
    proxyReq.end();
  };
}

app.post('/api/send', proxyRequest('/api/send'));
app.post('/api/verif', proxyRequest('/api/verif'));
app.post('/api/bulk', proxyRequest('/api/bulk'));

// ============================================================
//  🚀 JALANKAN
// ============================================================
app.listen(PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════════════╗
║   🚀 Server Gunz (Express, Node.js only): http://localhost:${PORT}
║   🎵 Root /        → music.html (Landing Page)
║   🏠 /home         → index.html (Portfolio)
║   📁 public | tools | alltools | api
║   📚 Docs: http://localhost:${PORT}/docs
║   🔒 Token SEKALI PAKAI (halaman terproteksi)
║   ⚡ API: Node.js (.js) only — NO PHP
║   🚫 CORS: DISABLED
╚══════════════════════════════════════════════════════════════╝
  `);
});