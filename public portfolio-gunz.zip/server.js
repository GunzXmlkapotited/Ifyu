const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

// ===== MIDDLEWARE =====
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Logger sederhana
app.use((req, res, next) => {
    const time = new Date().toISOString();
    console.log(`[${time}] ${req.method} ${req.url}`);
    next();
});

// ===== SERVE STATIC FILES (music.mp3, dll) =====
app.use(express.static(__dirname, {
    extensions: ['html', 'htm'],
    setHeaders: (res, filePath) => {
        // Header khusus untuk file audio (support streaming/range)
        if (filePath.endsWith('.mp3')) {
            res.setHeader('Accept-Ranges', 'bytes');
            res.setHeader('Cache-Control', 'public, max-age=86400');
        }
    }
}));

// ===== ROUTE UTAMA =====
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'api', 'index.html'));
});

// ===== HEALTH CHECK =====
app.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        port: PORT,
        uptime: process.uptime(),
        timestamp: new Date().toISOString()
    });
});

// ===== 404 HANDLER =====
app.use((req, res) => {
    res.status(404).send(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>404 - Not Found</title>
            <style>
                body {
                    background: #0a0a0a;
                    color: #22d3ee;
                    font-family: 'Segoe UI', sans-serif;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    height: 100vh;
                    margin: 0;
                    text-align: center;
                }
                h1 { font-size: 72px; margin: 0; }
                p { color: #fff; }
                a { color: #67e8f9; text-decoration: none; }
                a:hover { text-decoration: underline; }
            </style>
        </head>
        <body>
            <div>
                <h1>404</h1>
                <p>Halaman <code>${req.url}</code> tidak ditemukan.</p>
                <p><a href="/">← Kembali ke Music Player</a></p>
            </div>
        </body>
        </html>
    `);
});

// ===== ERROR HANDLER =====
app.use((err, req, res, next) => {
    console.error('Error:', err.stack);
    res.status(500).json({
        error: 'Internal Server Error',
        message: err.message
    });
});

// ===== START SERVER =====
app.listen(PORT, HOST, () => {
    console.log('');
    console.log('╔══════════════════════════════════════════════╗');
    console.log('║       🎵  MUSIC PLAYER SERVER  🎵            ║');
    console.log('╠══════════════════════════════════════════════╣');
    console.log(`║  Status   : ✅ ONLINE                        ║`);
    console.log(`║  Local    : http://localhost:${PORT}           ║`);
    console.log(`║  Network  : http://${HOST}:${PORT}              ║`);
    console.log('╚══════════════════════════════════════════════╝');
    console.log('');
    console.log('Tekan CTRL + C untuk menghentikan server.');
    console.log('');
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\n\n🛑 Server dihentikan. Sampai jumpa!');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('\n🛑 Server terminated.');
    process.exit(0);
});